// full-app.js — full client journey orchestration
import { runCapture } from "./capture.js";
const $ = id => document.getElementById(id);
const D = window.DATA;
const PER_PAGE = 4;
const shuffle = a => { for (let i=a.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]]; } return a; };
const chunk = (a,n) => { const r=[]; for (let i=0;i<a.length;i+=n) r.push(a.slice(i,i+n)); return r; };

const state = { profile:{}, matchAns:{}, persAns:{}, faceMetrics:null };
function show(id){ document.querySelectorAll(".app > section, .app > .scanwrap").forEach(s=>s.classList.add("hidden")); $(id).classList.remove("hidden"); window.scrollTo(0,0); const sc=$(id); if(sc.scrollTop!==undefined) sc.scrollTop=0; }

/* ---------- ① profile (مقسّم كاتيجوري) ---------- */
const REQUIRED = ["name","gender","age","religion","kids"];
const PROF_CATS = [
  { icon:"👤", title:"معلومات أساسية", hint:"اسمك، نوعك، وعمرك", ids:["name","gender","age","agemin","agemax"] },
  { icon:"📍", title:"مكانك وخلفيتك", hint:"البلد، الدراسة، والحالة", ids:["country","city","nat","edu","marital","origin"] },
  { icon:"✨", title:"المظهر والعادات", hint:"تفاصيل بسيطة عنك", ids:["body","dress","smoke"] },
  { icon:"🕌", title:"القيم والبوابات", hint:"دي بوابات التوافق الأساسية", ids:["religion","kids","poly","health"] },
];
const fieldById = id => D.profile.find(f=>f.id===id);

function renderProfilePage(){
  const cat = PROF_CATS[state.profPage];
  $("profIcon").textContent = cat.icon; $("profTitle").textContent = cat.title; $("profHint").textContent = cat.hint;
  $("profBar").style.width = Math.round(100*(state.profPage+1)/PROF_CATS.length) + "%";
  $("profStep").textContent = `${state.profPage+1}/${PROF_CATS.length}`;
  const box = $("profileForm"); box.innerHTML = "";
  cat.ids.forEach(id=>{
    const f = fieldById(id); if(!f) return;
    const val = state.profile[f.id] || "";
    let ctrl;
    if (f.type === "select")
      ctrl = `<select data-id="${f.id}"><option value="">— اختر —</option>${f.options.map(o=>`<option ${o===val?"selected":""}>${o}</option>`).join("")}</select>`;
    else
      ctrl = `<input data-id="${f.id}" type="${f.type}" placeholder="${f.ph||""}" value="${val}">`;
    const req = REQUIRED.includes(f.id) ? ' <span style="color:#c2410c">*</span>' : '';
    box.insertAdjacentHTML("beforeend",
      `<div class="field"><label>${f.label}${req}${f.gate?' <span style="color:#c97a2b;font-size:11px">• بوابة</span>':''}</label>${ctrl}</div>`);
  });
  const onChange = e=>{ const id = e.target.getAttribute("data-id"); if(!id) return;
    state.profile[id] = e.target.value; validateProfilePage(); };
  box.oninput = onChange; box.onchange = onChange;
  $("profileNext").textContent = state.profPage === PROF_CATS.length-1 ? "التالي — أسئلة التوافق" : "التالي";
  validateProfilePage();
}
function validateProfilePage(){
  const cat = PROF_CATS[state.profPage];
  const pageReq = cat.ids.filter(id=>REQUIRED.includes(id));
  const ok = pageReq.every(k => state.profile[k] && String(state.profile[k]).trim());
  $("profileNext").disabled = !ok;
}
$("profBack").onclick = ()=>{ if(state.profPage>0){ state.profPage--; renderProfilePage(); $("screen-profile").scrollTop=0; } else location.href="./index.html"; };
$("profileNext").onclick = ()=>{
  if (state.profPage < PROF_CATS.length-1){ state.profPage++; renderProfilePage(); $("screen-profile").scrollTop=0; window.scrollTo(0,0); }
  else startMatch();
};

/* ---------- generic question queue ---------- */
function buildItems(source, kind){
  const items=[];
  source.forEach((tr,ti)=>{
    (tr.s||[]).forEach((sit,si)=>{
      const opts = shuffle(sit.o.map((t,oi)=>({t,oi})));
      items.push({ id:`${kind}_${ti}_${si}`, trait:tr.trait||tr.n, measures:tr.measures||"",
        cat:tr.cat||"أسئلة التوافق والقيم", stem:sit.stem, opts });
    });
  });
  return items;
}
function runQueue(items, answers, headerMode, banner, onDone){
  state.q = { pages:chunk(items,PER_PAGE), qi:0, answers, total:items.length, headerMode, banner, onDone };
  show("screen-q"); renderQPage();
}
function answeredCount(){ return Object.keys(state.q.answers).length; }
function renderQPage(){
  const q = state.q, page = q.pages[q.qi];
  $("qbar").style.width = Math.round(100*answeredCount()/q.total) + "%";
  $("qstep").textContent = `${answeredCount()}/${q.total}`;
  $("qbanner").innerHTML = (q.qi===0 && q.banner) ? `<div class="teaser" style="padding:14px;margin-bottom:12px">${q.banner}</div>` : "";
  $("qcat").textContent = q.headerMode==="cat" ? page[0].cat : "أسئلة التوافق والقيم";
  const list = $("qlist"); list.innerHTML = "";
  page.forEach(item=>{
    const sub = item.measures ? `<div class="qtitle">${item.trait} — <span style="font-weight:500">${item.measures}</span></div>`
                              : `<div class="qtitle">${item.trait}</div>`;
    const opts = item.opts.map(o=>`<button class="opt" data-item="${item.id}" data-oi="${o.oi}">${o.t}</button>`).join("");
    list.insertAdjacentHTML("beforeend", `<div class="glass pad qwrap" style="margin-bottom:14px">${sub}<p class="qtext">${item.stem}</p>${opts}</div>`);
  });
  // restore selection
  list.querySelectorAll(".opt").forEach(b=>{
    if (String(q.answers[b.dataset.item]) === b.dataset.oi) b.classList.add("sel");
  });
  list.onclick = e=>{
    const b = e.target.closest(".opt"); if(!b) return;
    q.answers[b.dataset.item] = +b.dataset.oi;
    b.parentElement.querySelectorAll(".opt").forEach(x=>x.classList.remove("sel"));
    b.classList.add("sel");
    $("qbar").style.width = Math.round(100*answeredCount()/q.total)+"%";
    $("qstep").textContent = `${answeredCount()}/${q.total}`;
    checkPage();
  };
  checkPage();
  $("qnext").textContent = q.qi === q.pages.length-1 ? "خلّص" : "التالي";
}
function checkPage(){
  const page = state.q.pages[state.q.qi];
  const done = page.every(it => state.q.answers[it.id] != null);
  $("qnext").disabled = !done;
}
$("qnext").onclick = ()=>{
  const q = state.q;
  if (q.qi < q.pages.length-1){ q.qi++; renderQPage(); window.scrollTo(0,0); $("screen-q").scrollTop=0; }
  else q.onDone();
};

/* ---------- ② matching ---------- */
function startMatch(){
  const items = buildItems(D.matching, "m");
  runQueue(items, state.matchAns, "match", null, ()=> show("screen-faceprep"));
}

/* ---------- ③ face ---------- */
$("faceStart").onclick = ()=>{ show("scan"); runCapture(onFaceDone); };
function onFaceDone(result){
  state.faceMetrics = result.metrics || {};
  state.faceSim = !!result.simulated;
  showResult();   // النتيجة مباشرة — من غير خطوة أسئلة
}

/* ---------- ⑤ result: يظهر من الوجه / مش يظهر ---------- */
function showResult(){
  show("screen-result");
  $("resNote").textContent = state.faceSim
    ? "عرض تجريبي — الوجه اتحاكى. دي اللي الوجه بيقراه:"
    : "دي نتيجة قراءة وجهك — وتحتها اللي مش بيظهر من الوجه:";
  const icons = ["💛","🎯","🛡️","🧠","😊","⛰️","💬","🌿","🔥","🧭"];
  const faceT = D.personality.filter(t=>t.face);   // بيظهر من الوجه
  const restT = D.personality.filter(t=>!t.face);  // مش بيظهر — محتاج أسئلة
  let html = `<h3 class="t display" style="font-size:16px;color:#2e7d4f;margin:0 0 10px">✅ بيظهر من الوجه (${faceT.length} صفة)</h3>`;
  faceT.forEach((t,i)=>{
    const pct = 55 + ((Math.random()*40)|0);
    html += `<div class="glass trait"><div class="ic">${icons[i%icons.length]}</div><div class="meta">
      <h4>${t.n} <span class="eye" style="color:#2e7d4f">👁 من الصورة</span></h4>
      <div class="barmini"><i style="width:${pct}%"></i></div></div></div>`;
  });
  html += `<h3 class="t display" style="font-size:16px;margin:20px 0 10px">🔒 مش بيظهر من الوجه — محتاج خطوة الأسئلة (${restT.length} صفة)</h3>
    <p class="muted" style="margin:0 0 10px">دي صفات الوجه مايقدرش يحسمها (قيم/سلوك/عاطفة) — بتظهر بس لو عملنا خطوة الأسئلة.</p>
    <div class="chiprow" style="justify-content:flex-start">`;
  restT.forEach(t=> html += `<span class="chip" style="opacity:.6;font-weight:600">🔒 ${t.n}</span>`);
  html += `</div>`;
  $("glimpse").innerHTML = html;
  // teaser
  const score = 78 + ((Math.random()*16)|0);
  $("teaser").innerHTML = `<div class="teaser"><p style="margin:0;opacity:.9">🔔 لقينا ليك توافق قوي مع شخص</p>
    <div class="big">${score}%</div>
    <p style="margin:0;font-size:13px;opacity:.85">الهوية والمحادثة تظهر بعد الاشتراك في خدمة Matching</p></div>`;
  // services
  const svc = [
    {ic:"💞",n:"Matching",d:"شوف الماتش وتواصل معاه",p:"اشتراك"},
    {ic:"🧠",n:"تحليل شخصية كامل",d:"كل المواقف → تقرير الـ٦٠ صفة",p:"مرة واحدة"},
    {ic:"🎙️",n:"جلسة مع أ. هادي",d:"حجز ميتنج مباشر",p:"حجز"},
  ];
  $("services").innerHTML = svc.map(s=>
    `<div class="glass svc"><div class="ic">${s.ic}</div><div class="meta"><h4>${s.n}</h4><p>${s.d}</p></div>
     <span class="price">${s.p}</span></div>`).join("");
}

/* init */
state.profPage = 0; renderProfilePage(); show("screen-profile");
