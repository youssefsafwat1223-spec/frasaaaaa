// capture.js — live cinematic 3-angle face capture (VIDEO mode) + analysis.
import { FilesetResolver, FaceLandmarker }
  from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

const $ = id => document.getElementById(id);
let videoLm = null, stream = null, raf = null;

async function initVideoLm() {
  if (videoLm) return;
  const vision = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm");
  videoLm = await FaceLandmarker.createFromOptions(vision, {
    baseOptions: { modelAssetPath: "./models/face_landmarker.task" },
    runningMode: "VIDEO", numFaces: 1,
    minFaceDetectionConfidence: .3, minFacePresenceConfidence: .3, minTrackingConfidence: .3,
  });
}

function snapshot(video) {
  const w = video.videoWidth, h = video.videoHeight;
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  c.getContext("2d").drawImage(video, 0, 0, w, h);
  return c;
}

// steps: front -> right -> left
const STEPS = [
  { k:"front", icon:"😐", label:"أمامي", msg:"بُص للكاميرا مباشرة", ok:p => Math.abs(p.yaw) <= 11 && Math.abs(p.roll) <= 14 },
  { k:"right", icon:"➡️", label:"يمين",  msg:"لِفّ وشّك لليمين بهدوء", ok:p => p.yaw <= -26 && p.yaw >= -70 },
  { k:"left",  icon:"⬅️", label:"يسار",  msg:"لِفّ وشّك لليسار بهدوء", ok:p => p.yaw >= 26 && p.yaw <= 70 },
];

export async function runCapture(onDone) {
  const vid = $("vid"), oval = $("oval"), hud = $("hud"), proc = $("proc");
  const scanH = $("scanH"), scanP = $("scanP"), thumbs = $("thumbs"), steps3 = $("steps3");
  const shots = {}; let idx = 0, holdStart = 0;

  // render step chips
  steps3.innerHTML = STEPS.map((s,i)=>`<div class="step3" data-i="${i}"><div class="dot">${s.icon}</div><span>${s.label}</span></div>`).join("");
  const paintSteps = () => STEPS.forEach((s,i)=>{ const el = steps3.querySelector(`[data-i="${i}"]`);
    el.className = "step3 " + (shots[s.k] ? "done" : i===idx ? "cur" : ""); });
  paintSteps();

  function fail(msg) {
    scanH.textContent = "الكاميرا مش متاحة"; scanP.textContent = msg || "اسمح بالكاميرا وجرّب تاني";
    // graceful demo fallback: simulate metrics so the flow never dead-ends
    const skip = document.createElement("button");
    skip.className = "btn btn-ghost"; skip.style.margin = "14px auto 0"; skip.style.maxWidth = "70%";
    skip.textContent = "تخطّي بمحاكاة الوجه";
    skip.onclick = () => { cleanup(); onDone(simulated()); };
    $("scan").querySelector(".scanui").appendChild(skip);
  }

  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: 640, height: 480 }, audio: false });
    vid.srcObject = stream; await vid.play();
  } catch (e) { return fail("لازم تسمح للكاميرا في المتصفّح."); }

  try { await initVideoLm(); }
  catch (e) { return fail("تعذّر تحميل نموذج التحليل (محتاج إنترنت)."); }

  const loop = () => {
    if (idx >= STEPS.length) return;
    const step = STEPS[idx];
    scanH.textContent = step.msg;
    let pose = null;
    if (vid.videoWidth) {
      const res = videoLm.detectForVideo(vid, performance.now());
      if (res.faceLandmarks && res.faceLandmarks[0] && window.Face) {
        pose = window.Face.poseFromLandmarks(res.faceLandmarks[0]);
      }
    }
    if (pose) {
      hud.textContent = `yaw ${pose.yaw}°`;
      const ok = step.ok(pose);
      oval.classList.toggle("ok", ok);
      scanP.textContent = ok ? "ثابت كده… بنلتقط" : "وفّق وشّك مع الإطار";
      if (ok) {
        if (!holdStart) holdStart = performance.now();
        else if (performance.now() - holdStart > 550) {
          shots[step.k] = snapshot(vid);
          addThumb(thumbs, shots[step.k]);
          idx++; holdStart = 0; oval.classList.remove("ok"); paintSteps();
          if (idx >= STEPS.length) return finish();
        }
      } else holdStart = 0;
    } else { hud.textContent = "بدوّر على وش…"; scanP.textContent = "قرّب وشّك للكاميرا"; holdStart = 0; }
    raf = requestAnimationFrame(loop);
  };

  // manual capture
  $("shotBtn").classList.remove("hidden");
  $("shotBtn").onclick = () => {
    if (idx >= STEPS.length || !vid.videoWidth) return;
    const step = STEPS[idx]; shots[step.k] = snapshot(vid); addThumb(thumbs, shots[step.k]);
    idx++; paintSteps(); if (idx >= STEPS.length) finish();
  };

  async function finish() {
    cancelAnimationFrame(raf); $("shotBtn").classList.add("hidden");
    proc.classList.add("show");
    let result = null;
    try {
      await window.Face.init();
      if (window.Face.analyzeMultiAngle) {
        const imgs = {};
        for (const k of ["front","left","right"]) if (shots[k]) imgs[k] = shots[k];
        result = await window.Face.analyzeMultiAngle({ front: shots.front, left: shots.left, right: shots.right });
      }
      if (!result || !result.metrics) result = await window.Face.analyzeImageElement(shots.front);
    } catch (e) { result = simulated(); }
    cleanup();
    onDone(result || simulated());
  }

  function cleanup() {
    cancelAnimationFrame(raf);
    if (stream) stream.getTracks().forEach(t => t.stop());
  }
  raf = requestAnimationFrame(loop);
}

function addThumb(box, canvas) {
  const img = document.createElement("img");
  img.src = canvas.toDataURL("image/jpeg", .7); box.appendChild(img);
}
function simulated() {
  // believable-ish random metrics around mid values
  const m = {}; ["jaw_width_ratio","chin_width_ratio","forehead_width_ratio","mouth_width_ratio",
    "eye_spacing_ratio","brow_density","cheek_fullness","nose_width_ratio","mouth_height_ratio",
    "lower_lip_ratio","brow_arch","jaw_angle_sharpness"].forEach(k => m[k] = +(0.2 + Math.random()*0.4).toFixed(3));
  return { metrics: m, simulated: true };
}
