// full-app.js — full client journey orchestration
import { runCapture } from "./capture.js";
const $ = id => document.getElementById(id);
const D = window.DATA;
const PER_PAGE = 4;
const shuffle = a => { for (let i=a.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]]; } return a; };
const chunk = (a,n) => { const r=[]; for (let i=0;i<a.length;i+=n) r.push(a.slice(i,i+n)); return r; };

const state = { profile:{}, matchAns:{}, persAns:{}, faceMetrics:null };
function show(id){ document.querySelectorAll(".app > section, .app > .scanwrap").forEach(s=>s.classList.add("hidden")); $(id).classList.remove("hidden"); window.scrollTo(0,0); const sc=$(id); if(sc.scrollTop!==undefined) sc.scrollTop=0; }

/* ---------- ① profile ---------- */
const REQUIRED = ["name","gender","age","religion","kids"];
function renderProfile(){
  const box = $("profileForm"); box.innerHTML = "";
  D.profile.forEach(f=>{
    let ctrl;
    if (f.type === "select")
      ctrl = `<select data-id="${f.id}"><option value="">— اختر —</option>${f.options.map(o=>`<option>${o}</option>`).join("")}</select>`;
    else
      ctrl = `<input data-id="${f.id}" type="${f.type}" placeholder="${f.ph||""}">`;
    box.insertAdjacentHTML("beforeend",
      `<div class="field"><label>${f.label}${f.gate?' <span style="color:#c97a2b">• بوابة</span>':''}</label>${ctrl}</div>`);
  });
  box.addEventListener("input", e=>{
    const id = e.target.getAttribute("data-id"); if(!id) return;
    state.profile[id] = e.target.value; validateProfile();
  });
  box.addEventListener("change", e=>{
    const id = e.target.getAttribute("data-id"); if(!id) return;
    state.profile[id] = e.target.value; validateProfile();
  });
}
function validateProfile(){
  const ok = REQUIRED.every(k => state.profile[k] && String(state.profile[k]).trim());
  $("profileNext").disabled = !ok;
}
$("profileNext").onclick = ()=> startMatch();

/* ---------- generic question queue ---------- */
function buildItems(source, kind){
  const items=[];
  source.forEach((tr,ti)=>{
    (tr.s||[]).forEach((sit,si)=>{
      const opts = shuffle(sit.o.map((t,oi)=>({t,oi})));
      items.push({ id:`${kind}_${ti}_${si}`, trait:tr.trait||tr.n, measures:tr.measures||"",
        cat:tr.cat||"أسئلة التوافق والقيم", stem:sit.stem, opts });
    });
  });
  return items;
}
function runQueue(items, answers, headerMode, banner, onDone){
  state.q = { pages:chunk(items,PER_PAGE), qi:0, answers, total:items.length, headerMode, banner, onDone };
  show("screen-q"); renderQPage();
}
function answeredCount(){ return Object.keys(state.q.answers).length; }
function renderQPage(){
  const q = state.q, page = q.pages[q.qi];
  $("qbar").style.width = Math.round(100*answeredCount()/q.total) + "%";
  $("qstep").textContent = `${answeredCount()}/${q.total}`;
  $("qbanner").innerHTML = (q.qi===0 && q.banner) ? `<div class="teaser" style="padding:14px;margin-bottom:12px">${q.banner}</div>` : "";
  $("qcat").textContent = q.headerMode==="cat" ? page[0].cat : "أسئلة التوافق والقيم";
  const list = $("qlist"); list.innerHTML = "";
  page.forEach(item=>{
    const sub = item.measures ? `<div class="qtitle">${item.trait} — <span style="font-weight:500">${item.measures}</span></div>`
                              : `<div class="qtitle">${item.trait}</div>`;
    const opts = item.opts.map(o=>`<button class="opt" data-item="${item.id}" data-oi="${o.oi}">${o.t}</button>`).join("");
    list.insertAdjacentHTML("beforeend", `<div class="glass pad qwrap" style="margin-bottom:14px">${sub}<p class="qtext">${item.stem}</p>${opts}</div>`);
  });
  // restore selection
  list.querySelectorAll(".opt").forEach(b=>{
    if (String(q.answers[b.dataset.item]) === b.dataset.oi) b.classList.add("sel");
  });
  list.onclick = e=>{
    const b = e.target.closest(".opt"); if(!b) return;
    q.answers[b.dataset.item] = +b.dataset.oi;
    b.parentElement.querySelectorAll(".opt").forEach(x=>x.classList.remove("sel"));
    b.classList.add("sel");
    $("qbar").style.width = Math.round(100*answeredCount()/q.total)+"%";
    $("qstep").textContent = `${answeredCount()}/${q.total}`;
    checkPage();
  };
  checkPage();
  $("qnext").textContent = q.qi === q.pages.length-1 ? "خلّص" : "التالي";
}
function checkPage(){
  const page = state.q.pages[state.q.qi];
  const done = page.every(it => state.q.answers[it.id] != null);
  $("qnext").disabled = !done;
}
$("qnext").onclick = ()=>{
  const q = state.q;
  if (q.qi < q.pages.length-1){ q.qi++; renderQPage(); window.scrollTo(0,0); $("screen-q").scrollTop=0; }
  else q.onDone();
};

/* ---------- ② matching ---------- */
function startMatch(){
  const items = buildItems(D.matching, "m");
  runQueue(items, state.matchAns, "match", null, ()=> show("screen-faceprep"));
}

/* ---------- ③ face ---------- */
$("faceStart").onclick = ()=>{ show("scan"); runCapture(onFaceDone); };
function onFaceDone(result){
  state.faceMetrics = result.metrics || {};
  state.faceSim = !!result.simulated;
  startPers();
}

/* ---------- ④ personality (adaptive) ---------- */
function startPers(){
  const faceReadable = D.personality.filter(t=>t.face);
  const skipped = faceReadable.length;
  const asked = D.personality.filter(t=>!t.face);
  const items = buildItems(asked, "p");
  const banner = `🤖 الصورة كانت واثقة من <b>${skipped}</b> صفة فاتخطّيناها — بنسألك <b>${asked.length}</b> صفة بس بدل ٦٠، مقسّمة على فئات.`;
  runQueue(items, state.persAns, "cat", banner, showResult);
}

/* ---------- ⑤ result ---------- */
function showResult(){
  show("screen-result");
  $("resNote").textContent = state.faceSim
    ? "عرض تجريبي — الوجه اتحاكى. دي أبرز سماتك:"
    : "دمجنا قراءة وجهك مع إجاباتك. دي أبرز سماتك:";
  // glimpse: prefer face-readable traits (marked 👁) then a few answered
  const faceT = D.personality.filter(t=>t.face).slice(0,4);
  const otherT = shuffle(D.personality.filter(t=>!t.face)).slice(0,2);
  const icons = ["💛","🎯","🛡️","🧠","😊","⛰️","💬","🌿"];
  const g = $("glimpse"); g.innerHTML = "";
  [...faceT.map(t=>({t,face:true})), ...otherT.map(t=>({t,face:false}))].forEach((x,i)=>{
    const pct = 55 + ((Math.random()*40)|0);
    g.insertAdjacentHTML("beforeend",
      `<div class="glass trait"><div class="ic">${icons[i%icons.length]}</div><div class="meta">
        <h4>${x.t.n} ${x.face?'<span class="eye">👁 الصورة + الأسئلة</span>':''}</h4>
        <div class="barmini"><i style="width:${pct}%"></i></div></div></div>`);
  });
  // teaser
  const score = 78 + ((Math.random()*16)|0);
  $("teaser").innerHTML = `<div class="teaser"><p style="margin:0;opacity:.9">🔔 لقينا ليك توافق قوي مع شخص</p>
    <div class="big">${score}%</div>
    <p style="margin:0;font-size:13px;opacity:.85">الهوية والمحادثة تظهر بعد الاشتراك في خدمة Matching</p></div>`;
  // services
  const svc = [
    {ic:"💞",n:"Matching",d:"شوف الماتش وتواصل معاه",p:"اشتراك"},
    {ic:"🧠",n:"تحليل شخصية كامل",d:"كل المواقف → تقرير الـ٦٠ صفة",p:"مرة واحدة"},
    {ic:"🎙️",n:"جلسة مع أ. هادي",d:"حجز ميتنج مباشر",p:"حجز"},
  ];
  $("services").innerHTML = svc.map(s=>
    `<div class="glass svc"><div class="ic">${s.ic}</div><div class="meta"><h4>${s.n}</h4><p>${s.d}</p></div>
     <span class="price">${s.p}</span></div>`).join("");
}

/* init */
renderProfile(); show("screen-profile");
