
// ====== src/icons.jsx ======
// Curated SVG icon set — lightweight, consistent stroke
const Icon = ({ name, size = 20, className = "", stroke = 1.6, fill = "none" }) => {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill, stroke: "currentColor", strokeWidth: stroke, strokeLinecap: "round", strokeLinejoin: "round", className };
  const P = {
    logo: <svg {...common}><path d="M4 18c4-1 6-4 8-9 2 5 4 8 8 9"/><path d="M12 9v9"/></svg>,
    home: <svg {...common}><path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/></svg>,
    heart: <svg {...common}><path d="M12 20s-7-4.5-9-9.5C2.4 7 5 4 8 4c2 0 3 1 4 2 1-1 2-2 4-2 3 0 5.6 3 5 6.5-2 5-9 9.5-9 9.5z"/></svg>,
    users: <svg {...common}><circle cx="9" cy="8" r="4"/><circle cx="17" cy="9" r="3"/><path d="M2 21c0-3.3 3.1-6 7-6s7 2.7 7 6"/><path d="M15 21c0-2.2 1.8-4 4-4s4 1.8 4 4"/></svg>,
    inbox: <svg {...common}><path d="M3 13l3-8h12l3 8"/><path d="M3 13v6h18v-6"/><path d="M8 13h2l2 2 2-2h2"/></svg>,
    chat: <svg {...common}><path d="M21 12a8 8 0 0 1-11.6 7.2L4 21l1.8-5.4A8 8 0 1 1 21 12z"/></svg>,
    user: <svg {...common}><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"/></svg>,
    bell: <svg {...common}><path d="M6 17V11a6 6 0 1 1 12 0v6"/><path d="M4 17h16"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>,
    moon: <svg {...common}><path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/></svg>,
    sun: <svg {...common}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/></svg>,
    settings: <svg {...common}><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.8a7 7 0 0 0-2-1.2L14 3h-4l-.6 2.5a7 7 0 0 0-2 1.2L5 6l-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.8a7 7 0 0 0 2 1.2L10 21h4l.6-2.5a7 7 0 0 0 2-1.2l2.3.8 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z"/></svg>,
    logout: <svg {...common}><path d="M15 4h4v16h-4"/><path d="M10 17l-5-5 5-5"/><path d="M5 12h12"/></svg>,
    check: <svg {...common}><path d="M5 12l5 5L20 7"/></svg>,
    checkCircle: <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg>,
    x: <svg {...common}><path d="M6 6l12 12M18 6L6 18"/></svg>,
    chevronLeft: <svg {...common}><path d="M15 6l-6 6 6 6"/></svg>,
    chevronRight: <svg {...common}><path d="M9 6l6 6-6 6"/></svg>,
    chevronDown: <svg {...common}><path d="M6 9l6 6 6-6"/></svg>,
    arrowLeft: <svg {...common}><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>,
    arrowRight: <svg {...common}><path d="M5 12h14"/><path d="M12 5l7 7-7 7"/></svg>,
    plus: <svg {...common}><path d="M12 5v14M5 12h14"/></svg>,
    minus: <svg {...common}><path d="M5 12h14"/></svg>,
    search: <svg {...common}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>,
    filter: <svg {...common}><path d="M3 5h18M6 12h12M10 19h4"/></svg>,
    camera: <svg {...common}><path d="M3 8h4l2-2h6l2 2h4v12H3z"/><circle cx="12" cy="14" r="4"/></svg>,
    eye: <svg {...common}><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>,
    eyeOff: <svg {...common}><path d="M1 1l22 22"/><path d="M9.5 9.5a3 3 0 0 0 4.2 4.2"/><path d="M6.7 6.7C3.6 8.6 1 12 1 12s4 7 11 7c2 0 3.8-.5 5.3-1.3"/><path d="M14.1 5.2A11 11 0 0 1 23 12s-1 1.7-3 3.5"/></svg>,
    lock: <svg {...common}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>,
    mail: <svg {...common}><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 7 9-7"/></svg>,
    phone: <svg {...common}><path d="M22 17v3a2 2 0 0 1-2.2 2 19 19 0 0 1-8.3-3 19 19 0 0 1-6-6A19 19 0 0 1 2.5 4.7 2 2 0 0 1 4.5 2.5h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.5 2.6a2 2 0 0 1-.5 2L8 10a16 16 0 0 0 6 6l1.2-1.5a2 2 0 0 1 2-.5c.8.2 1.7.4 2.6.5A2 2 0 0 1 22 17z"/></svg>,
    shield: <svg {...common}><path d="M12 2l8 3v6c0 5-3.5 9.5-8 11-4.5-1.5-8-6-8-11V5z"/></svg>,
    sparkles: <svg {...common}><path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z"/><path d="M19 14l.6 1.9L21.5 16.5l-1.9.6L19 19l-.6-1.9-1.9-.6 1.9-.6z"/></svg>,
    star: <svg {...common}><path d="M12 3l3 6 6.5 1-4.7 4.5L18 21l-6-3-6 3 1.2-6.5L2.5 10 9 9z"/></svg>,
    crown: <svg {...common}><path d="M3 18h18l-1.5-9-4 4L12 6l-3.5 7-4-4z"/><path d="M3 18v2h18v-2"/></svg>,
    flame: <svg {...common}><path d="M12 3s5 4 5 9a5 5 0 0 1-10 0c0-2 1-4 2.5-5C8 5 12 3 12 3z"/></svg>,
    alert: <svg {...common}><path d="M12 3l10 17H2z"/><path d="M12 10v5M12 18v.5"/></svg>,
    info: <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg>,
    edit: <svg {...common}><path d="M4 20h4l11-11-4-4L4 16z"/><path d="M14 6l4 4"/></svg>,
    trash: <svg {...common}><path d="M4 7h16"/><path d="M9 7V4h6v3"/><path d="M6 7l1 13h10l1-13"/></svg>,
    upload: <svg {...common}><path d="M12 17V4"/><path d="M6 10l6-6 6 6"/><path d="M4 20h16"/></svg>,
    download: <svg {...common}><path d="M12 4v13"/><path d="M6 11l6 6 6-6"/><path d="M4 20h16"/></svg>,
    share: <svg {...common}><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.5 10.5l7-4M8.5 13.5l7 4"/></svg>,
    grid: <svg {...common}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>,
    list: <svg {...common}><path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r=".5"/><circle cx="3.5" cy="12" r=".5"/><circle cx="3.5" cy="18" r=".5"/></svg>,
    barChart: <svg {...common}><path d="M3 21h18"/><rect x="5" y="11" width="3" height="8"/><rect x="10.5" y="6" width="3" height="13"/><rect x="16" y="14" width="3" height="5"/></svg>,
    activity: <svg {...common}><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>,
    creditCard: <svg {...common}><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>,
    calendar: <svg {...common}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>,
    clock: <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
    location: <svg {...common}><path d="M12 22s7-7.5 7-13a7 7 0 0 0-14 0c0 5.5 7 13 7 13z"/><circle cx="12" cy="9" r="2.5"/></svg>,
    book: <svg {...common}><path d="M4 4h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H4z"/><path d="M20 4h-7a3 3 0 0 0-3 3v13a2 2 0 0 1 2-2h8z"/></svg>,
    briefcase: <svg {...common}><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>,
    image: <svg {...common}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg>,
    refresh: <svg {...common}><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg>,
    send: <svg {...common}><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/></svg>,
    menu: <svg {...common}><path d="M3 6h18M3 12h18M3 18h18"/></svg>,
    moreV: <svg {...common}><circle cx="12" cy="5" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="12" cy="19" r="1"/></svg>,
    moreH: <svg {...common}><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>,
    drag: <svg {...common}><circle cx="9" cy="6" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="6" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="18" r="1"/></svg>,
    flag: <svg {...common}><path d="M4 21V4h12l-2 4 2 4H4"/></svg>,
    tag: <svg {...common}><path d="M3 12l9-9h9v9l-9 9z"/><circle cx="16" cy="8" r="1.5"/></svg>,
    bookmark: <svg {...common}><path d="M6 3h12v18l-6-4-6 4z"/></svg>,
    leaf: <svg {...common}><path d="M5 19c8 0 14-6 14-14-7 0-14 5-14 13"/><path d="M5 19c1-3 4-6 8-8"/></svg>,
    droplet: <svg {...common}><path d="M12 3s7 8 7 13a7 7 0 0 1-14 0c0-5 7-13 7-13z"/></svg>,
    male: <svg {...common}><circle cx="10" cy="14" r="6"/><path d="M14 10l6-6M14 4h6v6"/></svg>,
    female: <svg {...common}><circle cx="12" cy="9" r="6"/><path d="M12 15v6M9 19h6"/></svg>,
    ruler: <svg {...common}><rect x="3" y="10" width="18" height="6" rx="1" transform="rotate(-45 12 12)"/></svg>,
    coin: <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M14 9.5c-.5-1-1.5-1.5-2.5-1.5-1.5 0-2.5 1-2.5 2s1 1.5 2.5 2 2.5 1 2.5 2-1 2-2.5 2c-1 0-2-.5-2.5-1.5M11 6.5V8M11 16v1.5"/></svg>,
    layers: <svg {...common}><path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5M3 18l9 5 9-5"/></svg>,
    target: <svg {...common}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></svg>,
    wand: <svg {...common}><path d="M15 4l5 5L9 20l-5-5z"/><path d="M14 5l5 5"/></svg>,
    qr: <svg {...common}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM20 14v3M14 20h3v1M20 20h1"/></svg>,
    play: <svg {...common}><path d="M6 4l14 8-14 8z"/></svg>,
    pause: <svg {...common}><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
    smile: <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9.5h0M15 9.5h0"/></svg>,
    sad: <svg {...common}><circle cx="12" cy="12" r="9"/><path d="M16 16s-1.5-2-4-2-4 2-4 2"/><path d="M9 9.5h0M15 9.5h0"/></svg>,
    mosque: <svg {...common}><path d="M3 21V12c0-3 4-4 9-4s9 1 9 4v9"/><path d="M12 8V4M10 4h4"/><path d="M3 21h18M9 21v-5a3 3 0 0 1 6 0v5"/></svg>,
    diamond: <svg {...common}><path d="M6 3h12l4 7-10 11L2 10z"/><path d="M2 10h20"/></svg>,
    handshake: <svg {...common}><path d="M3 12l4-4 3 2 3-3 4 4 3-1 1 4-7 6-4-2-3 2z"/></svg>,
  };
  return P[name] || P.info;
};
window.Icon = Icon;


// ====== src/components.jsx ======
// =============== Shared UI Components ===============
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ---- Button primitives ----
const GoldButton = ({ children, onClick, disabled, size = "md", className = "", icon, iconLeft, type="button", as: As="button", ...rest }) => {
  const sizes = { sm: "px-4 py-2 text-sm", md: "px-5 py-3 text-[15px]", lg: "px-6 py-3.5 text-base" };
  return (
    <As type={type} onClick={onClick} disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 rounded-xl bg-gold text-white font-medium tracking-wide transition-all duration-300 hover:bg-[#a48652] active:scale-[.98] disabled:bg-line disabled:text-ink-3 disabled:cursor-not-allowed shadow-[0_8px_24px_-12px_rgba(184,151,90,.55)] ${sizes[size]} ${className}`}
      {...rest}>
      {iconLeft}
      <span>{children}</span>
      {icon}
    </As>
  );
};
const OutlineButton = ({ children, onClick, size="md", className="", icon, iconLeft, ...rest }) => {
  const sizes = { sm: "px-4 py-2 text-sm", md: "px-5 py-3 text-[15px]", lg: "px-6 py-3.5 text-base" };
  return (
    <button onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded-xl border border-line dark:border-edge text-ink dark:text-fog font-medium transition-all hover:bg-paper-2 dark:hover:bg-night-2 ${sizes[size]} ${className}`}
      {...rest}>
      {iconLeft}<span>{children}</span>{icon}
    </button>
  );
};
const GhostButton = ({ children, onClick, className="", ...rest }) => (
  <button onClick={onClick}
    className={`inline-flex items-center justify-center gap-2 rounded-xl text-ink-2 dark:text-fog-2 font-medium hover:text-gold transition-all px-3 py-2 ${className}`} {...rest}>{children}</button>
);
const GreenButton = ({ children, onClick, size="md", className="", icon, ...rest }) => {
  const sizes = { sm: "px-4 py-2 text-sm", md: "px-5 py-3 text-[15px]", lg: "px-6 py-3.5 text-base" };
  return <button onClick={onClick} className={`inline-flex items-center justify-center gap-2 rounded-xl bg-green text-white font-medium hover:bg-green-light active:scale-[.98] shadow-[0_8px_24px_-12px_rgba(44,95,74,.55)] transition-all ${sizes[size]} ${className}`} {...rest}>{children}{icon}</button>;
};

// ---- Card ----
const Card = ({ children, className = "", padded = true, ...rest }) => (
  <div className={`bg-paper-card dark:bg-night-2 border border-line dark:border-edge rounded-2xl ${padded ? "p-5" : ""} ${className}`} {...rest}>{children}</div>
);

// ---- Badge / Pill ----
const Badge = ({ children, tone="neutral", className="" }) => {
  const tones = {
    neutral: "bg-paper-2 dark:bg-night-3 text-ink-2 dark:text-fog-2 border border-line dark:border-edge",
    gold: "bg-[#FBF6E9] dark:bg-[#332a17] text-[#7d6224] dark:text-gold-light border border-[#E8D8AE] dark:border-[#5a4720]",
    green: "bg-[#E7F2EC] dark:bg-[#16302a] text-green dark:text-[#9bd2b8] border border-[#C6E0CF] dark:border-[#2a4f3f]",
    amber: "bg-amber-soft dark:bg-[#3a2d12] text-amber dark:text-[#e4b266] border border-[#EAD9B6] dark:border-[#5b4720]",
    rose:  "bg-rose-soft dark:bg-[#3a1f1f] text-rose dark:text-[#e89090] border border-[#E8C5C0] dark:border-[#5a2f2f]",
    blue:  "bg-[#E8EEF5] dark:bg-[#1a253a] text-[#2e548a] dark:text-[#8fb1e3] border border-[#CFDBEC] dark:border-[#2f3f5a]",
    dark:  "bg-night text-fog border border-edge",
  };
  return <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-medium ${tones[tone]} ${className}`}>{children}</span>;
};

// ---- Status Badge ----
const StatusBadge = ({ status }) => {
  const map = {
    pending:  { label: "قيد المراجعة", tone: "amber" },
    waiting:  { label: "في انتظار الرد", tone: "blue"  },
    accepted: { label: "تم القبول",     tone: "green"  },
    rejected: { label: "اعتذر",          tone: "neutral"},
    expired:  { label: "انتهت المدة",    tone: "neutral"},
    active:   { label: "مفعل",           tone: "green"  },
    blocked:  { label: "محظور",          tone: "rose"   },
    warned:   { label: "تحذير",          tone: "amber"  },
  };
  const s = map[status] || { label: status, tone: "neutral" };
  return <Badge tone={s.tone}>{s.label}</Badge>;
};

// ---- Progress Bar ----
const ProgressBar = ({ value = 0, max = 100, height=6, className="" }) => (
  <div className={`w-full bg-line dark:bg-edge rounded-full overflow-hidden ${className}`} style={{ height }}>
    <div className="h-full bg-gold rounded-full transition-all duration-700" style={{ width: `${Math.min(100, (value/max)*100)}%` }} />
  </div>
);

// ---- Score Ring ----
const ScoreRing = ({ value = 0, size = 120, stroke = 8, color = "#B8975A", trackColor, label, sublabel, className="" }) => {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c * (1 - value / 100);
  return (
    <div className={`relative inline-flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size/2} cy={size/2} r={r} stroke={trackColor || "currentColor"} className={trackColor ? "" : "text-line dark:text-edge"} strokeWidth={stroke} fill="none" />
        <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round" style={{ transition: "stroke-dashoffset 1.2s ease" }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-serif-en text-2xl leading-none" style={{ fontSize: size * 0.26 }}>{label ?? <>{Math.round(value)}<span className="text-[0.55em] align-top">%</span></>}</div>
        {sublabel && <div className="text-[11px] mt-1 text-ink-2 dark:text-fog-2">{sublabel}</div>}
      </div>
    </div>
  );
};

// ---- Profile Avatar ----
const ProfileAvatar = ({ name = "م", size = 48, src, online, anonymous, className = "", tone="gold" }) => {
  const initials = name.split(" ").map(s => s[0]).slice(0, 2).join("");
  const tones = {
    gold: "bg-gradient-to-br from-[#E7D9B8] to-[#B8975A] text-white",
    green: "bg-gradient-to-br from-[#A7CFBA] to-[#2C5F4A] text-white",
    stone: "bg-gradient-to-br from-[#E8E4DC] to-[#9B9B9B] text-white",
    night: "bg-gradient-to-br from-[#2A2825] to-[#0F0F0E] text-fog",
  };
  return (
    <div className={`relative inline-flex items-center justify-center rounded-full overflow-hidden ring-1 ring-line dark:ring-edge ${tones[tone]} ${className}`} style={{ width: size, height: size, fontSize: size * 0.36 }}>
      {anonymous ? <Icon name="user" size={size*0.55}/> : src ? <img src={src} alt="" className="w-full h-full object-cover"/> : <span className="font-display font-medium">{initials}</span>}
      {online && <span className="absolute bottom-0.5 left-0.5 w-2.5 h-2.5 rounded-full bg-green ring-2 ring-paper-card dark:ring-night-2"/>}
    </div>
  );
};

// ---- Modal ----
const Modal = ({ open, onClose, title, children, footer, size = "md" }) => {
  if (!open) return null;
  const widths = { sm: "max-w-sm", md: "max-w-md", lg: "max-w-2xl", xl: "max-w-4xl" };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-6 fade-in">
      <div className="absolute inset-0 bg-night/40 backdrop-blur-sm" onClick={onClose}/>
      <div className={`relative bg-paper-card dark:bg-night-2 w-full ${widths[size]} rounded-t-3xl sm:rounded-2xl shadow-card border border-line dark:border-edge slide-in`}>
        <div className="flex items-center justify-between p-5 border-b border-line dark:border-edge">
          <h3 className="font-display text-lg">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3"><Icon name="x"/></button>
        </div>
        <div className="p-5">{children}</div>
        {footer && <div className="p-5 pt-0 flex items-center justify-end gap-3">{footer}</div>}
      </div>
    </div>
  );
};

// ---- Toast ----
const Toast = ({ message, tone="green", show }) => {
  if (!show) return null;
  const tones = {
    green: "bg-green text-white",
    gold:  "bg-gold text-white",
    rose:  "bg-rose text-white",
  };
  return <div className={`fixed bottom-24 sm:bottom-8 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-card slide-in ${tones[tone]}`}>{message}</div>;
};

// ---- Inputs ----
const TextField = ({ label, hint, error, icon, type="text", className="", ...rest }) => (
  <label className={`block ${className}`}>
    {label && <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-1.5">{label}</div>}
    <div className={`flex items-center gap-2 bg-paper-card dark:bg-night-3 border ${error ? "border-rose" : "border-line dark:border-edge"} focus-within:border-gold rounded-xl px-3.5 transition-colors`}>
      {icon && <span className="text-ink-3">{icon}</span>}
      <input type={type} className="flex-1 bg-transparent py-3 outline-none text-[15px] placeholder:text-ink-3 dark:placeholder:text-fog-2/60" {...rest}/>
    </div>
    {hint && !error && <div className="text-[12px] text-ink-3 mt-1.5">{hint}</div>}
    {error && <div className="text-[12px] text-rose mt-1.5">{error}</div>}
  </label>
);

const TextArea = ({ label, maxLength, value, onChange, ...rest }) => (
  <label className="block">
    {label && <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-1.5 flex items-center justify-between"><span>{label}</span>{maxLength && <span className="text-ink-3 text-[11px] numerals">{(value||"").length}/{maxLength}</span>}</div>}
    <textarea value={value} onChange={onChange} maxLength={maxLength} rows={4} className="w-full bg-paper-card dark:bg-night-3 border border-line dark:border-edge focus:border-gold rounded-xl px-3.5 py-3 outline-none text-[15px] resize-none placeholder:text-ink-3" {...rest}/>
  </label>
);

const Select = ({ label, options=[], value, onChange, placeholder, ...rest }) => (
  <label className="block">
    {label && <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-1.5">{label}</div>}
    <div className="relative">
      <select value={value} onChange={onChange} className="w-full appearance-none bg-paper-card dark:bg-night-3 border border-line dark:border-edge focus:border-gold rounded-xl px-3.5 py-3 outline-none text-[15px] pl-9" {...rest}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(o => <option key={typeof o==="string"?o:o.value} value={typeof o==="string"?o:o.value}>{typeof o==="string"?o:o.label}</option>)}
      </select>
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-3 pointer-events-none"><Icon name="chevronDown" size={16}/></span>
    </div>
  </label>
);

const Checkbox = ({ checked, onChange, label, sub }) => (
  <label className="flex items-start gap-3 cursor-pointer group">
    <button type="button" onClick={() => onChange(!checked)} className={`check mt-0.5 ${checked ? "on" : ""}`}>
      {checked && <Icon name="check" size={14} stroke={2.6} className="text-white"/>}
    </button>
    <div className="flex-1">
      <div className="text-[15px]">{label}</div>
      {sub && <div className="text-[13px] text-ink-2 dark:text-fog-2 mt-0.5 leading-relaxed">{sub}</div>}
    </div>
  </label>
);

const Toggle = ({ checked, onChange, size="md" }) => {
  const w = size === "sm" ? 36 : 44, h = size === "sm" ? 20 : 24, d = size === "sm" ? 16 : 20;
  return (
    <button type="button" onClick={() => onChange(!checked)}
      className={`relative rounded-full transition-colors ${checked ? "bg-gold" : "bg-line dark:bg-edge"}`}
      style={{ width: w, height: h }}>
      <span className="absolute top-0.5 bg-white rounded-full transition-all shadow-sm" style={{ width: d, height: d, [checked ? "right" : "left"]: 2 }}/>
    </button>
  );
};

const RadioCard = ({ checked, onClick, children, className="" }) => (
  <button onClick={onClick} className={`w-full text-right p-4 rounded-2xl border-2 transition-all ${checked ? "border-gold bg-[#FBF6E9] dark:bg-[#2a2417]" : "border-line dark:border-edge hover:border-gold/40 bg-paper-card dark:bg-night-2"} ${className}`}>
    <div className="flex items-center gap-3">
      <span className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${checked ? "border-gold" : "border-line dark:border-edge"}`}>
        {checked && <span className="w-2.5 h-2.5 rounded-full bg-gold"/>}
      </span>
      <div className="flex-1">{children}</div>
    </div>
  </button>
);

// ---- Empty state ----
const EmptyState = ({ icon = "inbox", title, sub, action }) => (
  <div className="flex flex-col items-center justify-center text-center py-16 px-6">
    <div className="w-20 h-20 rounded-full bg-paper-2 dark:bg-night-3 flex items-center justify-center text-ink-3 mb-5"><Icon name={icon} size={32}/></div>
    <div className="font-display text-lg mb-1">{title}</div>
    {sub && <div className="text-ink-2 dark:text-fog-2 text-sm max-w-xs">{sub}</div>}
    {action && <div className="mt-5">{action}</div>}
  </div>
);

// ---- Mini logo / wordmark ----
const Logo = ({ size = 24, withWord = true, dark }) => (
  <div className="inline-flex items-center gap-2.5">
    <svg width={size*1.2} height={size*1.2} viewBox="0 0 40 40" className="text-gold">
      <path d="M8 30c5-1 8-5 12-15 4 10 7 14 12 15" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M20 15v15" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round"/>
      <circle cx="20" cy="11" r="2.4" fill="currentColor"/>
    </svg>
    {withWord && <div className="leading-none">
      <div className={`font-display text-[18px] tracking-wide ${dark ? "text-fog" : "text-ink dark:text-fog"}`}>تَوَافُق</div>
      <div className={`text-[10px] tracking-[0.2em] mt-0.5 ${dark ? "text-fog-2" : "text-ink-3"}`}>TAWAFUQ</div>
    </div>}
  </div>
);

// ---- Section heading helper ----
const SectionHead = ({ title, sub, action }) => (
  <div className="flex items-end justify-between mb-4">
    <div>
      <h2 className="font-display text-xl">{title}</h2>
      {sub && <p className="text-ink-2 dark:text-fog-2 text-sm mt-1">{sub}</p>}
    </div>
    {action}
  </div>
);

// Avatar placeholder gradient by seed
const avatarTones = ["gold","green","stone","night"];
const toneFor = (seed=0) => avatarTones[seed % avatarTones.length];

// Persisted Egyptian sample data
const sampleNames = ["أحمد محمود", "فاطمة سالم", "يوسف عمر", "نور الهدى", "هند علي", "كريم حسن", "سارة عبدالله", "محمود طارق", "ليلى يوسف", "زياد خالد"];
const sampleCities = ["القاهرة","الإسكندرية","الجيزة","المنصورة","أسيوط","طنطا","الزقازيق","المنيا","شرم الشيخ"];
const personalityTypes = ["عقلاني اجتماعي","عاطفي هادئ","مثالي مرن","عملي منظم"];

const buildMatch = (i, opts={}) => ({
  id: `m-${i}`,
  name: sampleNames[i % sampleNames.length],
  city: sampleCities[i % sampleCities.length],
  age: 24 + (i*3) % 14,
  score: 95 - (i * 4) % 27,
  type: i % 2 === 0 ? "متشابه" : "متكامل",
  reasons: [
    "اهتمام مشترك بالقراءة والمعرفة",
    "نظرة متقاربة حول العائلة",
    "نمط حياة متوافق",
  ],
  personality: personalityTypes[i % personalityTypes.length],
  anonymous: opts.anonymous ?? (i % 3 === 0),
  tone: avatarTones[i % avatarTones.length],
});

window.UI = {
  GoldButton, OutlineButton, GhostButton, GreenButton, Card, Badge, StatusBadge, ProgressBar, ScoreRing,
  ProfileAvatar, Modal, Toast, TextField, TextArea, Select, Checkbox, Toggle, RadioCard, EmptyState, Logo, SectionHead,
  sampleNames, sampleCities, personalityTypes, buildMatch, toneFor,
};
Object.assign(window, window.UI);


// ====== src/nav.jsx ======
// =============== Navigation: Sidebars, Bottom Tabs, Page Navigator ===============

// All pages, grouped, for the Page Navigator overlay
const PAGE_GROUPS = [
  { title: "العامة", color: "gold", items: [
    ["landing","P1 الصفحة الرئيسية"],["register","P2 إنشاء حساب"],["login","P3 تسجيل الدخول"],
    ["otp","P4 التحقق OTP"],["forgot","P5 نسيت كلمة المرور"],["reset","P6 إعادة تعيين"],
  ]},
  { title: "إعداد الحساب", color: "green", items: [
    ["consent","P7 الموافقة"],["profile-setup","P8 الملف الشخصي"],
    ["q-overview","P9 نظرة على الاستبيان"],["q-question","P10 سؤال"],["q-category-done","P11 نهاية القسم"],["q-all-done","P12 نهاية الاستبيان"],
    ["face-intro","P13 تحليل الوجه"],["face-liveness","P14 التحقق من النشاط"],["face-capture","P15 التقاط الصورة"],["face-processing","P16 جاري التحليل"],["face-traits","P17 الصفات"],
    ["self-physical","P18 المظهر الذاتي"],["self-prefs","P19 التفضيلات"],["onboard-done","P20 جاهز"],
  ]},
  { title: "التطبيق", color: "gold", items: [
    ["dashboard","P21 الرئيسية"],["report","P22 التقرير الشخصي"],["matches","P23 التوافقات"],["match-detail","P24 تفاصيل التوافق"],
    ["req-sent","P25 الطلبات المرسلة"],["req-received","P26 الطلبات المستلمة"],["req-detail","P27 طلب مستلم"],
    ["chats","P28 المحادثات"],["chat-room","P29 محادثة"],["notifs","P30 الإشعارات"],
  ]},
  { title: "الاشتراك", color: "gold", items: [
    ["pricing","P31 الخطط"],["payment","P32 الدفع"],["sub-success","P33 تم الاشتراك"],["sub-expired","P34 انتهت"],["settings-sub","P35 إدارة الاشتراك"],
  ]},
  { title: "الإعدادات", color: "green", items: [
    ["settings","P36 الإعدادات"],["settings-edit","P37 تعديل الملف"],["settings-password","P38 كلمة المرور"],
    ["settings-privacy","P39 الخصوصية"],["settings-notifs","P40 الإشعارات"],["settings-account","P41 الحساب"],
  ]},
  { title: "لوحة الإدارة", color: "night", items: [
    ["admin-dashboard","P42 لوحة الإدارة"],["admin-users","P43 المستخدمون"],["admin-user-detail","P44 مستخدم"],
    ["admin-questions","P45 الأسئلة"],["admin-question-edit","P46 سؤال"],["admin-weights","P47 الأوزان"],
    ["admin-traits","P48 قواعد الصفات"],["admin-requests","P49 طابور الطلبات"],["admin-flags","P50 المحادثات المعلّمة"],
    ["admin-chat-view","P51 عرض محادثة"],["admin-reports","P52 البلاغات"],["admin-report-detail","P53 بلاغ"],
    ["admin-words","P54 كلمات محظورة"],["admin-icebreakers","P55 محفّزات الحوار"],["admin-tips","P56 نصائح المحادثة"],
    ["admin-settings","P57 إعدادات المنصة"],["admin-stats","P58 الإحصائيات"],["admin-ml","P59 ML"],
    ["admin-logs","P60 سجل النشاط"],["admin-plans","P61 خطط الاشتراك"],["admin-subs","P62 المشتركون"],["admin-revenue","P63 الإيرادات"],
  ]},
  { title: "الأخطاء", color: "rose", items: [
    ["404","P64 404"],["403","P65 403"],["500","P66 500"],["session","P67 انتهت الجلسة"],["maintenance","P68 صيانة"],
  ]},
];
const ALL_PAGES = PAGE_GROUPS.flatMap(g => g.items.map(([id]) => id));

// ----- Page Navigator (always visible demo helper) -----
const PageNavigator = ({ current, onGo, dark, onToggleDark, onToggleUserType, userType }) => {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const idx = ALL_PAGES.indexOf(current);
  const next = ALL_PAGES[(idx+1) % ALL_PAGES.length];
  const prev = ALL_PAGES[(idx-1+ALL_PAGES.length) % ALL_PAGES.length];
  return (
    <>
      <div className="fixed z-40 bottom-4 left-4 flex items-center gap-2">
        <div className="flex items-center bg-night dark:bg-night-2 text-fog rounded-full shadow-card border border-edge overflow-hidden">
          <button title="السابق" onClick={() => onGo(prev)} className="p-2.5 hover:bg-night-2"><Icon name="chevronRight" size={16}/></button>
          <button onClick={() => setOpen(true)} className="px-3 py-2 text-[12px] tracking-wider numerals flex items-center gap-2 hover:bg-night-2">
            <Icon name="grid" size={14}/> <span>صفحة {idx+1}/68</span>
          </button>
          <button title="التالي" onClick={() => onGo(next)} className="p-2.5 hover:bg-night-2"><Icon name="chevronLeft" size={16}/></button>
        </div>
        <button onClick={onToggleDark} title="الوضع الداكن" className="p-2.5 bg-night dark:bg-night-2 text-fog rounded-full shadow-card border border-edge hover:bg-night-2">
          <Icon name={dark ? "sun" : "moon"} size={16}/>
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 flex fade-in">
          <div className="absolute inset-0 bg-night/60 backdrop-blur-sm" onClick={() => setOpen(false)}/>
          <div className="relative ml-auto h-full w-full sm:w-[420px] bg-paper-card dark:bg-night-2 border-l border-line dark:border-edge overflow-y-auto nice-scroll slide-in">
            <div className="sticky top-0 bg-paper-card dark:bg-night-2 border-b border-line dark:border-edge p-4 z-10">
              <div className="flex items-center justify-between mb-3">
                <div className="font-display text-lg">كل الصفحات (68)</div>
                <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3"><Icon name="x"/></button>
              </div>
              <div className="flex items-center gap-2 bg-paper-2 dark:bg-night-3 rounded-xl px-3.5 py-2.5">
                <Icon name="search" size={16} className="text-ink-3"/>
                <input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="ابحث عن صفحة…" className="flex-1 bg-transparent outline-none text-[14px]"/>
              </div>
              <div className="flex items-center gap-2 mt-3 text-[12px]">
                <span className="text-ink-3">نوع المستخدم:</span>
                {["guest","user","subscribed","admin"].map(u => (
                  <button key={u} onClick={() => onToggleUserType(u)} className={`px-2.5 py-1 rounded-full border ${userType===u ? "bg-gold text-white border-gold" : "border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>{u}</button>
                ))}
              </div>
            </div>
            <div className="p-4 space-y-5">
              {PAGE_GROUPS.map(group => {
                const items = group.items.filter(([id,label]) => !q || label.includes(q) || id.includes(q));
                if (!items.length) return null;
                return (
                  <div key={group.title}>
                    <div className="text-[11px] font-medium tracking-wider text-ink-3 uppercase mb-2">{group.title}</div>
                    <div className="grid grid-cols-1 gap-1.5">
                      {items.map(([id,label]) => (
                        <button key={id} onClick={() => { onGo(id); setOpen(false); }} className={`text-right px-3.5 py-2.5 rounded-xl border transition-all flex items-center justify-between ${current===id ? "bg-gold/10 border-gold text-gold" : "border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3"}`}>
                          <span className="text-[14px]">{label}</span>
                          {current === id && <Icon name="check" size={14}/>}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

// ----- Bottom tabs (mobile user app) -----
const BottomTabs = ({ current, onGo }) => {
  const tabs = [
    { id: "dashboard", label: "الرئيسية", icon: "home" },
    { id: "matches",   label: "التوافقات", icon: "heart" },
    { id: "req-received", label: "الطلبات", icon: "inbox" },
    { id: "chats",     label: "المحادثات", icon: "chat" },
    { id: "settings",  label: "حسابي", icon: "user" },
  ];
  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-paper-card/90 dark:bg-night-2/90 backdrop-blur-md border-t border-line dark:border-edge pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-stretch justify-around px-2 pt-2 pb-2">
        {tabs.map(t => {
          const active = t.id === current || (t.id==="req-received" && current==="req-sent") || (t.id==="settings" && current.startsWith("settings"));
          return (
            <button key={t.id} onClick={() => onGo(t.id)} className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all ${active ? "text-gold" : "text-ink-2 dark:text-fog-2"}`}>
              <Icon name={t.icon} size={22} stroke={active ? 2 : 1.6}/>
              <span className="text-[10.5px] font-medium">{t.label}</span>
              {active && <span className="w-1 h-1 rounded-full bg-gold"/>}
            </button>
          );
        })}
      </div>
    </nav>
  );
};

// ----- Desktop sidebar (user app, RTL = right) -----
const UserSidebar = ({ current, onGo, user }) => {
  const items = [
    { id: "dashboard", label: "الرئيسية", icon: "home" },
    { id: "matches", label: "التوافقات", icon: "heart" },
    { id: "req-received", label: "الطلبات", icon: "inbox" },
    { id: "chats", label: "المحادثات", icon: "chat" },
    { id: "report", label: "تقريري", icon: "activity" },
    { id: "notifs", label: "الإشعارات", icon: "bell" },
    { id: "settings", label: "الإعدادات", icon: "settings" },
  ];
  return (
    <aside className="hidden lg:flex flex-col w-72 shrink-0 border-l border-line dark:border-edge bg-paper-card dark:bg-night-2 h-screen sticky top-0">
      <div className="p-5 border-b border-line dark:border-edge"><Logo/></div>
      <div className="p-3 flex-1">
        <nav className="space-y-1">
          {items.map(it => {
            const active = it.id === current || (it.id==="settings" && current.startsWith("settings"));
            return (
              <button key={it.id} onClick={() => onGo(it.id)} className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-[14.5px] transition-all ${active ? "bg-gold/10 text-gold" : "text-ink dark:text-fog hover:bg-paper-2 dark:hover:bg-night-3"}`}>
                <Icon name={it.icon} size={18}/>
                <span>{it.label}</span>
                {active && <span className="ms-auto w-1.5 h-1.5 rounded-full bg-gold"/>}
              </button>
            );
          })}
        </nav>
      </div>
      <div className="p-3 border-t border-line dark:border-edge flex items-center gap-3">
        <ProfileAvatar name={user?.name||"أحمد محمود"} size={40}/>
        <div className="flex-1 min-w-0">
          <div className="text-[14px] truncate">{user?.name||"أحمد محمود"}</div>
          <div className="text-[12px] text-ink-2 dark:text-fog-2 truncate">{user?.email||"ahmed@tawafuq.app"}</div>
        </div>
        <button onClick={() => onGo("login")} className="p-2 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3 text-ink-3"><Icon name="logout" size={18}/></button>
      </div>
    </aside>
  );
};

// ----- App header (mobile) -----
const AppHeader = ({ title, right, onBack, sub }) => (
  <header className="sticky top-0 z-20 bg-paper/90 dark:bg-night/90 backdrop-blur-md border-b border-line dark:border-edge">
    <div className="flex items-center gap-3 px-4 h-14">
      {onBack && <button onClick={onBack} className="p-1.5 -mr-1.5 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3"><Icon name="chevronRight"/></button>}
      <div className="flex-1 min-w-0">
        <div className="font-display text-[17px] truncate">{title}</div>
        {sub && <div className="text-[12px] text-ink-2 dark:text-fog-2 truncate">{sub}</div>}
      </div>
      {right}
    </div>
  </header>
);

// ----- Admin sidebar -----
const AdminSidebar = ({ current, onGo }) => {
  const sections = [
    { title: "نظرة عامة", items: [
      ["admin-dashboard", "لوحة الإدارة", "grid"],
      ["admin-stats", "الإحصائيات", "barChart"],
      ["admin-ml", "ذكاء اصطناعي", "sparkles"],
    ]},
    { title: "المستخدمون", items: [
      ["admin-users", "المستخدمون", "users"],
      ["admin-requests", "طلبات التواصل", "inbox"],
    ]},
    { title: "المحتوى", items: [
      ["admin-questions", "الأسئلة", "list"],
      ["admin-weights", "أوزان المطابقة", "layers"],
      ["admin-traits", "قواعد الصفات", "wand"],
      ["admin-icebreakers", "محفّزات الحوار", "chat"],
      ["admin-tips", "نصائح المحادثة", "info"],
    ]},
    { title: "الأمان", items: [
      ["admin-flags", "محادثات معلّمة", "flag"],
      ["admin-reports", "البلاغات", "alert"],
      ["admin-words", "كلمات محظورة", "shield"],
    ]},
    { title: "الاشتراكات", items: [
      ["admin-plans", "الخطط", "diamond"],
      ["admin-subs", "المشتركون", "users"],
      ["admin-revenue", "الإيرادات", "coin"],
    ]},
    { title: "النظام", items: [
      ["admin-settings", "إعدادات المنصة", "settings"],
      ["admin-logs", "سجل النشاط", "clock"],
    ]},
  ];
  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 border-l border-line dark:border-edge bg-paper-card dark:bg-night-2 h-screen sticky top-0 overflow-y-auto nice-scroll">
      <div className="p-5 border-b border-line dark:border-edge flex items-center justify-between">
        <Logo/>
        <Badge tone="dark">إدارة</Badge>
      </div>
      <div className="flex-1 p-3 space-y-5">
        {sections.map(sec => (
          <div key={sec.title}>
            <div className="text-[10.5px] font-medium tracking-wider text-ink-3 uppercase px-2 mb-1.5">{sec.title}</div>
            {sec.items.map(([id, label, icon]) => {
              const active = current === id;
              return (
                <button key={id} onClick={() => onGo(id)} className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-[13.5px] transition-all ${active ? "bg-gold/10 text-gold" : "text-ink dark:text-fog hover:bg-paper-2 dark:hover:bg-night-3"}`}>
                  <Icon name={icon} size={16}/>
                  <span>{label}</span>
                </button>
              );
            })}
          </div>
        ))}
      </div>
      <div className="p-3 border-t border-line dark:border-edge flex items-center gap-3">
        <ProfileAvatar name="إدارة" size={36} tone="night"/>
        <div className="flex-1 min-w-0">
          <div className="text-[13px] truncate">عمر فؤاد</div>
          <div className="text-[11px] text-ink-2 dark:text-fog-2 truncate">Super Admin</div>
        </div>
        <button onClick={() => onGo("login")} className="p-2 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3 text-ink-3"><Icon name="logout" size={16}/></button>
      </div>
    </aside>
  );
};

// ----- Admin top bar -----
const AdminTopBar = ({ title, sub, right }) => (
  <div className="flex items-center justify-between gap-4 px-6 lg:px-8 py-5 border-b border-line dark:border-edge bg-paper dark:bg-night sticky top-0 z-10">
    <div>
      <h1 className="font-display text-2xl">{title}</h1>
      {sub && <p className="text-ink-2 dark:text-fog-2 text-sm mt-0.5">{sub}</p>}
    </div>
    <div className="flex items-center gap-2">
      {right}
      <button className="p-2.5 rounded-xl border border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3"><Icon name="bell" size={18}/></button>
    </div>
  </div>
);

// ----- Page wrapper: phone-frame on desktop, full on mobile -----
const PhoneFrame = ({ children, dark }) => (
  <div className="min-h-screen flex items-center justify-center p-0 sm:p-6">
    <div className="phone-shell relative bg-paper dark:bg-night" style={{ height: 844 }}>
      <div className="absolute top-0 inset-x-0 h-7 flex items-center justify-between px-7 text-[12px] z-50 pointer-events-none">
        <span className="font-medium">9:41</span>
        <span className="w-20 h-5 bg-night rounded-full"/>
        <span className="flex items-center gap-1"><Icon name="activity" size={12}/></span>
      </div>
      <div className="absolute inset-0 pt-7 overflow-y-auto nice-scroll">{children}</div>
    </div>
  </div>
);

window.NAV = { PAGE_GROUPS, ALL_PAGES, PageNavigator, BottomTabs, UserSidebar, AppHeader, AdminSidebar, AdminTopBar, PhoneFrame };
Object.assign(window, window.NAV);


// ====== src/pages-public.jsx ======
// =============== Public Pages: P1-P6 ===============

// ---- P1: Landing ----
const PageLanding = ({ go }) => {
  return (
    <div className="min-h-screen bg-paper dark:bg-night">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-paper/80 dark:bg-night/80 backdrop-blur-md border-b border-line/60 dark:border-edge/60">
        <div className="max-w-6xl mx-auto px-5 lg:px-8 h-16 flex items-center justify-between">
          <Logo/>
          <nav className="hidden md:flex items-center gap-7 text-[14px] text-ink-2 dark:text-fog-2">
            <a className="hover:text-gold">كيف يعمل</a>
            <a className="hover:text-gold">الخصوصية</a>
            <a className="hover:text-gold cursor-pointer" onClick={()=>go("pricing")}>الأسعار</a>
            <a className="hover:text-gold">الأسئلة الشائعة</a>
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={()=>go("login")} className="text-[14px] text-ink dark:text-fog hover:text-gold px-3 py-2">دخول</button>
            <GoldButton size="sm" onClick={()=>go("register")}>ابدأ الآن</GoldButton>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 -right-32 w-[480px] h-[480px] rounded-full bg-gold/10 blur-3xl"/>
          <div className="absolute bottom-0 -left-40 w-[420px] h-[420px] rounded-full bg-green/10 blur-3xl"/>
        </div>
        <div className="relative max-w-6xl mx-auto px-5 lg:px-8 pt-16 pb-24 lg:pt-28 lg:pb-32 text-center">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-paper-2 dark:bg-night-2 border border-line dark:border-edge text-[12.5px] text-ink-2 dark:text-fog-2 mb-7">
            <span className="w-1.5 h-1.5 rounded-full bg-gold"/> منصة جادة للزواج — ليست تطبيق تعارف
          </div>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-7xl leading-[1.15] tracking-tight max-w-3xl mx-auto">
            اكتشف <span className="text-gold">توافقك الحقيقي</span>
            <br/>قبل أن تبدأ القصة.
          </h1>
          <p className="mt-6 text-[16px] sm:text-[18px] text-ink-2 dark:text-fog-2 max-w-2xl mx-auto leading-loose">
            استبيان عميق، تحليل ذكي للملامح، ومطابقة قائمة على القيم والشخصية ونمط الحياة — لتلتقي بشخصٍ يناسبك فعلاً، لا بالصورة فقط.
          </p>
          <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-3">
            <GoldButton size="lg" onClick={()=>go("register")}>ابدأ رحلتك مجاناً</GoldButton>
            <OutlineButton size="lg" onClick={()=>go("pricing")}>تصفح الخطط</OutlineButton>
          </div>
          <div className="mt-10 flex items-center justify-center gap-8 text-[12.5px] text-ink-3">
            <span className="flex items-center gap-2"><Icon name="shield" size={14}/> خصوصية كاملة</span>
            <span className="flex items-center gap-2"><Icon name="checkCircle" size={14}/> مراجعة بشرية</span>
            <span className="flex items-center gap-2"><Icon name="mosque" size={14}/> مبادئ محترمة</span>
          </div>
        </div>
      </section>

      {/* Feature cards */}
      <section className="max-w-6xl mx-auto px-5 lg:px-8 pb-24">
        <div className="grid md:grid-cols-3 gap-5">
          {[
            { icon: "list",     title: "استبيان شخصي عميق", text: "٤٠ سؤالاً في ٤ أقسام تكشف قيمك وشخصيتك ونمط حياتك وتوقعاتك من الزواج." , badge: "١٠ دقائق"},
            { icon: "sparkles", title: "تحليل الملامح بالذكاء", text: "نموذج فراسة محترم يستخرج انطباعاً أولياً من ملامحك لإثراء التوافق — لا للحكم.", badge: "اختياري" },
            { icon: "handshake",title: "مطابقة ذكية",         text: "خوارزمية تزن القيم بـ٤٠٪، الشخصية ٢٥٪، نمط الحياة ٢٠٪، والمظهر ١٥٪.", badge: "نتائج فورية" },
          ].map(f => (
            <Card key={f.title} className="hover:shadow-card transition-shadow">
              <div className="w-12 h-12 rounded-2xl bg-gold/10 text-gold flex items-center justify-center mb-5"><Icon name={f.icon} size={22}/></div>
              <div className="flex items-center justify-between">
                <h3 className="font-display text-lg">{f.title}</h3>
                <Badge tone="gold">{f.badge}</Badge>
              </div>
              <p className="mt-2.5 text-ink-2 dark:text-fog-2 text-[14.5px] leading-loose">{f.text}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-paper-2 dark:bg-night-2 border-y border-line dark:border-edge">
        <div className="max-w-6xl mx-auto px-5 lg:px-8 py-20">
          <div className="text-center mb-12">
            <div className="text-[12px] tracking-[0.3em] text-gold mb-2 uppercase">كيف يعمل</div>
            <h2 className="font-display text-3xl lg:text-4xl">من التسجيل إلى اللقاء — أربع خطوات</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              ["أنشئ ملفك", "اسم، عمر، مدينة، هدف زواجك — بدون التزامات."],
              ["أكمل الاستبيان", "أربعون سؤالاً تستغرق عشر دقائق فقط."],
              ["حلّل ملامحك", "ثلاث صور بإضاءة جيدة، تُحلّل ثم تُحذف."],
              ["اكتشف المتوافقين", "نعرض من يناسبك فعلاً، بنسبٍ مفصّلة."],
            ].map(([t,d], i) => (
              <Card key={t} className="text-center">
                <div className="font-serif-en text-3xl text-gold/40 mb-2">0{i+1}</div>
                <div className="font-display text-lg mb-1.5">{t}</div>
                <p className="text-ink-2 dark:text-fog-2 text-[13.5px] leading-loose">{d}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing preview */}
      <section className="max-w-6xl mx-auto px-5 lg:px-8 py-20">
        <div className="text-center mb-10">
          <div className="text-[12px] tracking-[0.3em] text-gold mb-2 uppercase">خطط واضحة</div>
          <h2 className="font-display text-3xl lg:text-4xl">التحليل مجاني. نعرض المطابقات فقط عند الاشتراك.</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-5 max-w-3xl mx-auto">
          <Card>
            <Badge tone="neutral">مجاني</Badge>
            <div className="font-display text-2xl mt-3 mb-1">استكشف نفسك</div>
            <div className="numerals font-serif-en text-4xl mt-2">٠ <span className="text-base text-ink-2">ج.م</span></div>
            <ul className="mt-5 space-y-2.5 text-[14px]">
              {["استبيان كامل","تحليل ملامح","تقرير شخصي مفصّل","نسبة جاهزية للزواج"].map(l => (
                <li key={l} className="flex items-center gap-2.5 text-ink-2 dark:text-fog-2"><Icon name="check" size={14} className="text-green"/> {l}</li>
              ))}
            </ul>
            <OutlineButton className="mt-6 w-full" onClick={()=>go("register")}>ابدأ مجاناً</OutlineButton>
          </Card>
          <Card className="ring-2 ring-gold relative">
            <span className="absolute -top-3 right-5 px-3 py-1 rounded-full bg-gold text-white text-[11px]">الأكثر شعبية</span>
            <Badge tone="gold">Pro</Badge>
            <div className="font-display text-2xl mt-3 mb-1">قابل المتوافقين</div>
            <div className="numerals font-serif-en text-4xl mt-2">٩٩ <span className="text-base text-ink-2">ج.م / شهر</span></div>
            <ul className="mt-5 space-y-2.5 text-[14px]">
              {["كل ما في المجاني","عرض كل التوافقات","طلبات تواصل غير محدودة","محادثة آمنة مع تنبيهات","أولوية في المطابقة"].map(l => (
                <li key={l} className="flex items-center gap-2.5"><Icon name="check" size={14} className="text-gold"/> {l}</li>
              ))}
            </ul>
            <GoldButton className="mt-6 w-full" onClick={()=>go("pricing")}>اشترك الآن</GoldButton>
          </Card>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-paper-2 dark:bg-night-2 border-y border-line dark:border-edge">
        <div className="max-w-6xl mx-auto px-5 lg:px-8 py-20">
          <div className="text-center mb-10">
            <div className="text-[12px] tracking-[0.3em] text-gold mb-2 uppercase">تجارب حقيقية</div>
            <h2 className="font-display text-3xl">قصص بدأت بتوافق صادق</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {[
              { n: "نور و كريم", c: "القاهرة", t: "اتعرفنا عبر تَوَافُق وكان فيه احترام من أول لحظة. اتخطبنا بعد ٥ شهور.", s: 92 },
              { n: "هند و محمود", c: "الإسكندرية", t: "النسب ساعدتني أفهم نفسي قبل ما أفهم شريكي. تجربة جادة بصدق.", s: 88 },
              { n: "سارة و زياد", c: "الجيزة", t: "اللي عجبني إن مفيش ضغط — كل خطوة محترمة وفيها وقت تفكير.", s: 95 },
            ].map(s => (
              <Card key={s.n}>
                <div className="flex items-center gap-3 mb-3">
                  <ProfileAvatar name={s.n} size={48} tone="green"/>
                  <div>
                    <div className="font-medium">{s.n}</div>
                    <div className="text-[12px] text-ink-2 dark:text-fog-2 flex items-center gap-1"><Icon name="location" size={12}/> {s.c}</div>
                  </div>
                  <Badge tone="gold" className="mr-auto">{s.s}٪</Badge>
                </div>
                <p className="text-[14.5px] leading-loose text-ink dark:text-fog">"{s.t}"</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-5 lg:px-8 py-20 text-center">
        <h2 className="font-display text-3xl lg:text-5xl leading-tight">جاهز لتلتقي بمن يفهمك حقاً؟</h2>
        <p className="mt-4 text-ink-2 dark:text-fog-2 max-w-xl mx-auto">ابدأ بالتسجيل المجاني — التحليل لا يستغرق أكثر من ربع ساعة.</p>
        <div className="mt-7"><GoldButton size="lg" onClick={()=>go("register")}>ابدأ رحلتك مجاناً</GoldButton></div>
      </section>

      {/* Footer */}
      <footer className="border-t border-line dark:border-edge bg-paper-card dark:bg-night-2">
        <div className="max-w-6xl mx-auto px-5 lg:px-8 py-12 grid md:grid-cols-4 gap-8 text-[13.5px] text-ink-2 dark:text-fog-2">
          <div className="md:col-span-1">
            <Logo/>
            <p className="mt-3 leading-loose">منصة جادة للتوافق الزواجي، تجمع علم الشخصية بالذكاء الاصطناعي والاحترام لقيم مجتمعنا.</p>
          </div>
          {[
            ["المنصة", ["كيف يعمل","الأسعار","الخصوصية","الشروط"]],
            ["الشركة", ["من نحن","المدونة","الوظائف","تواصل معنا"]],
            ["الدعم", ["مركز المساعدة","الأسئلة الشائعة","التحقق من الحساب","الإبلاغ"]],
          ].map(([t, items]) => (
            <div key={t}>
              <div className="font-medium text-ink dark:text-fog mb-3">{t}</div>
              <ul className="space-y-2">{items.map(i => <li key={i}><a className="hover:text-gold">{i}</a></li>)}</ul>
            </div>
          ))}
        </div>
        <div className="border-t border-line dark:border-edge">
          <div className="max-w-6xl mx-auto px-5 lg:px-8 py-5 text-[12px] text-ink-3 flex items-center justify-between">
            <span>© ٢٠٢٦ تَوَافُق — جميع الحقوق محفوظة</span>
            <span>صُنع بعناية في القاهرة</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

// ---- Auth shell ----
const AuthShell = ({ title, sub, children, footer, go }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex flex-col">
    <div className="px-5 lg:px-8 py-5 flex items-center justify-between">
      <button onClick={()=>go("landing")} className="inline-flex"><Logo/></button>
      <button onClick={()=>go("landing")} className="text-[13px] text-ink-2 dark:text-fog-2 hover:text-gold inline-flex items-center gap-1"><Icon name="arrowRight" size={14}/> العودة للرئيسية</button>
    </div>
    <div className="flex-1 flex items-center justify-center px-5 py-10">
      <div className="w-full max-w-md">
        <h1 className="font-display text-3xl text-center">{title}</h1>
        {sub && <p className="text-center text-ink-2 dark:text-fog-2 mt-2 text-[14px]">{sub}</p>}
        <Card className="mt-8">{children}</Card>
        {footer && <div className="text-center mt-5 text-[14px] text-ink-2 dark:text-fog-2">{footer}</div>}
      </div>
    </div>
  </div>
);

// ---- P2: Register ----
const PageRegister = ({ go }) => {
  const [mode, setMode] = useState("phone");
  const [show, setShow] = useState(false);
  return (
    <AuthShell go={go} title="إنشاء حساب جديد" sub="ابدأ رحلتك في خطوات بسيطة"
      footer={<>لديك حساب؟ <a onClick={()=>go("login")} className="text-gold cursor-pointer">سجل دخول</a></>}>
      <div className="flex bg-paper-2 dark:bg-night-3 p-1 rounded-xl text-[13px] mb-5">
        {[["phone","رقم الجوال","phone"],["email","البريد الإلكتروني","mail"]].map(([id,lbl,icn]) => (
          <button key={id} onClick={()=>setMode(id)} className={`flex-1 py-2 rounded-lg inline-flex items-center justify-center gap-2 transition ${mode===id?"bg-paper-card dark:bg-night-2 text-ink dark:text-fog shadow-soft":"text-ink-2 dark:text-fog-2"}`}>
            <Icon name={icn} size={14}/> {lbl}
          </button>
        ))}
      </div>

      <div className="space-y-3.5">
        {mode==="phone" ? (
          <TextField label="رقم الجوال" placeholder="١٠٠ ١٢٣ ٤٥٦٧" icon={<span className="text-[13px] text-ink-2">+٢٠</span>}/>
        ) : (
          <TextField label="البريد الإلكتروني" placeholder="you@example.com" icon={<Icon name="mail" size={16}/>} type="email"/>
        )}
        <TextField label="كلمة المرور" type={show?"text":"password"} placeholder="٨ أحرف على الأقل" icon={<Icon name="lock" size={16}/>}/>
        <TextField label="تأكيد كلمة المرور" type={show?"text":"password"} placeholder="أعد كتابتها" icon={<Icon name="lock" size={16}/>}/>
        <button type="button" onClick={()=>setShow(!show)} className="text-[12.5px] text-ink-2 dark:text-fog-2 inline-flex items-center gap-1.5 hover:text-gold">
          <Icon name={show?"eyeOff":"eye"} size={14}/> {show?"إخفاء":"إظهار"} كلمة المرور
        </button>
        <GoldButton className="w-full mt-2" onClick={()=>go("otp")}>إنشاء الحساب</GoldButton>
        <div className="text-[12px] text-ink-3 text-center leading-loose mt-2">
          بإنشاء حسابك فإنك توافق على <a className="text-gold">الشروط</a> و<a className="text-gold">سياسة الخصوصية</a>
        </div>
      </div>
    </AuthShell>
  );
};

// ---- P3: Login ----
const PageLogin = ({ go }) => {
  const [show, setShow] = useState(false);
  return (
    <AuthShell go={go} title="مرحباً بعودتك" sub="سجل دخولك لمتابعة رحلتك"
      footer={<>ليس لديك حساب؟ <a onClick={()=>go("register")} className="text-gold cursor-pointer">أنشئ حساباً</a></>}>
      <div className="space-y-3.5">
        <TextField label="البريد أو رقم الجوال" placeholder="you@example.com" icon={<Icon name="user" size={16}/>}/>
        <TextField label="كلمة المرور" type={show?"text":"password"} placeholder="••••••••" icon={<Icon name="lock" size={16}/>}/>
        <div className="flex items-center justify-between text-[13px]">
          <Checkbox checked={true} onChange={()=>{}} label="تذكرني"/>
          <a onClick={()=>go("forgot")} className="text-gold cursor-pointer">نسيت كلمة المرور؟</a>
        </div>
        <GoldButton className="w-full mt-2" onClick={()=>go("dashboard")}>تسجيل الدخول</GoldButton>
        <div className="relative my-4 text-center">
          <span className="text-[12px] text-ink-3 bg-paper-card dark:bg-night-2 px-3 relative z-10">أو</span>
          <span className="absolute top-1/2 inset-x-0 h-px bg-line dark:bg-edge"/>
        </div>
        <button className="w-full py-3 rounded-xl border border-line dark:border-edge text-[14px] hover:bg-paper-2 dark:hover:bg-night-3 inline-flex items-center justify-center gap-2"><Icon name="phone" size={16}/> الدخول برمز OTP</button>
      </div>
    </AuthShell>
  );
};

// ---- P4: OTP ----
const PageOTP = ({ go }) => {
  const [digits, setDigits] = useState(["","","","","",""]);
  const [seconds, setSeconds] = useState(54);
  const refs = useRef([]);
  useEffect(() => { if (seconds <= 0) return; const t = setTimeout(() => setSeconds(s=>s-1), 1000); return () => clearTimeout(t); }, [seconds]);
  const setD = (i, v) => {
    if (v && !/^\d$/.test(v)) return;
    const arr = [...digits]; arr[i] = v; setDigits(arr);
    if (v && i < 5) refs.current[i+1]?.focus();
  };
  const filled = digits.every(d => d);
  return (
    <AuthShell go={go} title="التحقق من حسابك" sub="أدخل الرمز المُرسل إلى ٠١٠٠ ٠٠٠ ••٤٧">
      <div className="text-center mb-5">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-gold/10 text-gold flex items-center justify-center"><Icon name="shield" size={28}/></div>
      </div>
      <div dir="ltr" className="flex items-center justify-center gap-2.5 mb-6">
        {digits.map((d, i) => (
          <input key={i} ref={el => refs.current[i] = el} value={d} onChange={e=>setD(i, e.target.value.slice(-1))}
            onKeyDown={e => { if (e.key==="Backspace" && !digits[i] && i>0) refs.current[i-1]?.focus(); }}
            maxLength={1} inputMode="numeric"
            className={`w-12 h-14 rounded-xl border-2 bg-paper-card dark:bg-night-3 text-center font-serif-en text-2xl outline-none transition-all ${d?"border-gold":"border-line dark:border-edge"} focus:border-gold`}/>
        ))}
      </div>
      <div className="text-center text-[13px] text-ink-2 dark:text-fog-2 mb-5 numerals">
        {seconds > 0 ? <>إعادة الإرسال خلال <span className="text-gold">{String(seconds).padStart(2,"0")}</span> ث</> : <a className="text-gold cursor-pointer">إعادة الإرسال</a>}
      </div>
      <GoldButton className="w-full" disabled={!filled} onClick={()=>go("consent")}>تأكيد</GoldButton>
      <div className="text-center mt-4 text-[13px] text-ink-2 dark:text-fog-2"><a onClick={()=>go("register")} className="text-gold cursor-pointer">تعديل رقم الجوال</a></div>
    </AuthShell>
  );
};

// ---- P5: Forgot Password ----
const PageForgot = ({ go }) => (
  <AuthShell go={go} title="نسيت كلمة المرور" sub="سنرسل لك رابطاً لإعادة التعيين"
    footer={<a onClick={()=>go("login")} className="text-gold cursor-pointer">العودة لتسجيل الدخول</a>}>
    <div className="space-y-4">
      <TextField label="البريد أو رقم الجوال" placeholder="you@example.com" icon={<Icon name="mail" size={16}/>}/>
      <GoldButton className="w-full" onClick={()=>go("reset")}>إرسال الرابط</GoldButton>
    </div>
  </AuthShell>
);

// ---- P6: Reset Password ----
const PageReset = ({ go }) => (
  <AuthShell go={go} title="كلمة مرور جديدة" sub="اختر كلمة مرور قوية تتذكرها">
    <div className="space-y-3.5">
      <TextField label="كلمة المرور الجديدة" type="password" icon={<Icon name="lock" size={16}/>}/>
      <TextField label="تأكيد كلمة المرور" type="password" icon={<Icon name="lock" size={16}/>}/>
      <div className="bg-paper-2 dark:bg-night-3 rounded-xl p-3 text-[12.5px] text-ink-2 dark:text-fog-2 space-y-1.5">
        <div className="flex items-center gap-1.5"><Icon name="check" size={12} className="text-green"/> ٨ أحرف على الأقل</div>
        <div className="flex items-center gap-1.5"><Icon name="check" size={12} className="text-green"/> حرف كبير وصغير</div>
        <div className="flex items-center gap-1.5"><Icon name="x" size={12} className="text-ink-3"/> رقم واحد على الأقل</div>
      </div>
      <GoldButton className="w-full" onClick={()=>go("login")}>حفظ كلمة المرور</GoldButton>
    </div>
  </AuthShell>
);

window.PagesPublic = { PageLanding, PageRegister, PageLogin, PageOTP, PageForgot, PageReset };
Object.assign(window, window.PagesPublic);


// ====== src/pages-onboarding.jsx ======
// =============== Onboarding Pages: P7-P20 ===============

const ONBOARD_STEPS = [
  { id: 1, label: "الموافقة" },
  { id: 2, label: "الملف الشخصي" },
  { id: 3, label: "الاستبيان" },
  { id: 4, label: "تحليل الوجه" },
  { id: 5, label: "جاهز" },
];

const Stepper = ({ active = 1 }) => (
  <div className="bg-paper-card dark:bg-night-2 border-b border-line dark:border-edge">
    <div className="max-w-3xl mx-auto px-5 lg:px-8 py-4">
      <div className="flex items-center justify-between gap-2 relative">
        {ONBOARD_STEPS.map((s, i) => {
          const done = s.id < active, current = s.id === active;
          return (
            <React.Fragment key={s.id}>
              <div className="flex flex-col items-center gap-1.5 z-10">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-serif-en text-[14px] transition-all ${done ? "bg-green text-white" : current ? "bg-gold text-white ring-4 ring-gold/15" : "bg-paper-2 dark:bg-night-3 text-ink-3 border border-line dark:border-edge"}`}>
                  {done ? <Icon name="check" size={14} stroke={2.6}/> : s.id}
                </div>
                <div className={`text-[11.5px] ${current ? "text-gold" : done ? "text-green" : "text-ink-3"}`}>{s.label}</div>
              </div>
              {i < ONBOARD_STEPS.length - 1 && (
                <div className="flex-1 h-px bg-line dark:bg-edge -mt-4 relative">
                  <div className={`absolute inset-y-0 right-0 ${s.id < active ? "bg-green w-full" : "bg-transparent"}`}/>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  </div>
);

const OnboardShell = ({ step, title, sub, children, footer, onBack }) => (
  <div className="min-h-screen bg-paper dark:bg-night">
    <header className="px-5 lg:px-8 py-4 flex items-center justify-between border-b border-line/60 dark:border-edge/60">
      <Logo/>
      <div className="text-[12px] text-ink-3">احفظ التقدم تلقائياً</div>
    </header>
    <Stepper active={step}/>
    <div className="max-w-3xl mx-auto px-5 lg:px-8 py-8 pb-32">
      {onBack && <button onClick={onBack} className="mb-4 inline-flex items-center gap-1.5 text-[13.5px] text-ink-2 dark:text-fog-2 hover:text-gold"><Icon name="arrowRight" size={14}/> السابق</button>}
      <h1 className="font-display text-3xl">{title}</h1>
      {sub && <p className="text-ink-2 dark:text-fog-2 mt-2 text-[15px] leading-loose">{sub}</p>}
      <div className="mt-8">{children}</div>
    </div>
    {footer && (
      <div className="fixed bottom-0 inset-x-0 bg-paper-card/95 dark:bg-night-2/95 backdrop-blur-md border-t border-line dark:border-edge">
        <div className="max-w-3xl mx-auto px-5 lg:px-8 py-4">{footer}</div>
      </div>
    )}
  </div>
);

// ---- P7: Consent ----
const PageConsent = ({ go }) => {
  const items = [
    ["استخدام صورك في التحليل", "نُحلّل ٣ صور لاستخراج انطباع أولي من ملامحك. الصور تبقى في خصوصيتك ولا تظهر علناً."],
    ["استخدام بياناتك في المطابقة", "تُستخدم إجاباتك ونتائج التحليل في حساب نِسب التوافق مع المستخدمين الآخرين فقط."],
    ["النتائج تقديرية", "أفهم أن نتائج التحليل تقديرية وليست علمية بنسبة ١٠٠٪، وأنها أداة استرشادية."],
    ["الشروط والأحكام", "أوافق على الشروط والأحكام وسياسة الخصوصية وأتعهد بصدق المعلومات المُقدّمة."],
  ];
  const [checked, setChecked] = useState([false,false,false,false]);
  const allOk = checked.every(Boolean);
  return (
    <OnboardShell step={1} title="أهلاً بك في تَوَافُق"
      sub="قبل أن نبدأ، نحتاج موافقتك على بضع نقاط أساسية. اقرأها بهدوء — رحلتك تستحق ذلك."
      footer={<GoldButton className="w-full" disabled={!allOk} onClick={()=>go("profile-setup")}>متابعة</GoldButton>}>
      <Card className="space-y-5">
        {items.map(([t,d], i) => (
          <div key={i} className="pb-5 border-b last:border-0 border-line dark:border-edge last:pb-0">
            <Checkbox checked={checked[i]} onChange={v => setChecked(c => c.map((x,idx)=>idx===i?v:x))} label={t} sub={d}/>
          </div>
        ))}
      </Card>
      <div className="mt-5 flex items-center gap-2 text-[12.5px] text-ink-3"><Icon name="shield" size={14}/> ملفك خاص. لا نشارك بياناتك مع أي طرف خارجي.</div>
    </OnboardShell>
  );
};

// ---- P8: Profile Setup ----
const PageProfileSetup = ({ go }) => {
  const [gender, setGender] = useState("male");
  const [goal, setGoal] = useState("marriage");
  const [anon, setAnon] = useState(true);
  const [bio, setBio] = useState("");
  return (
    <OnboardShell step={2} title="عرّفنا بك" sub="معلومات أساسية تساعدنا في تحضير ملفك. تستطيع تعديلها لاحقاً."
      footer={<GoldButton className="w-full" onClick={()=>go("q-overview")}>حفظ ومتابعة</GoldButton>}>
      <div className="space-y-5">
        <Card>
          <div className="grid sm:grid-cols-2 gap-4">
            <TextField label="الاسم المعروض" placeholder="مثال: أحمد م." defaultValue="أحمد محمود"/>
            <TextField label="العمر" type="number" min={18} max={60} defaultValue="28" placeholder="٢٨"/>
          </div>
          <div className="mt-4">
            <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-2">النوع</div>
            <div className="grid grid-cols-2 gap-3">
              {[["male","ذكر","male"],["female","أنثى","female"]].map(([id,lbl,icn]) => (
                <button key={id} onClick={()=>setGender(id)} className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${gender===id?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417]":"border-line dark:border-edge"}`}>
                  <Icon name={icn} size={28} className={gender===id?"text-gold":"text-ink-3"}/>
                  <span className="text-[14px]">{lbl}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4 mt-4">
            <Select label="المدينة" placeholder="اختر مدينتك" options={sampleCities}/>
            <Select label="المؤهل" placeholder="اختر مؤهلك" options={["ثانوي","دبلوم","بكالوريوس","ماجستير","دكتوراه"]}/>
          </div>
          <div className="mt-4"><TextField label="المهنة" placeholder="مثال: مهندس برمجيات"/></div>
        </Card>

        <Card>
          <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-3">هدفك من تَوَافُق</div>
          <div className="grid sm:grid-cols-2 gap-3">
            {[["marriage","الزواج","تبحث عن شريك حياة"],["serious","علاقة جادة","تبحث عن تعارف بنيّة الزواج"]].map(([id,t,d]) => (
              <button key={id} onClick={()=>setGoal(id)} className={`p-4 rounded-2xl border-2 text-right transition-all ${goal===id?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417]":"border-line dark:border-edge"}`}>
                <div className="flex items-center justify-between mb-1.5">
                  <Icon name={id==="marriage"?"diamond":"handshake"} size={20} className="text-gold"/>
                  {goal===id && <Icon name="check" size={16} className="text-gold"/>}
                </div>
                <div className="font-medium">{t}</div>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-1">{d}</div>
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <TextArea label="نبذة قصيرة (اختياري)" maxLength={150} value={bio} onChange={e=>setBio(e.target.value)} placeholder="عرّف عن نفسك في سطرين…"/>
          <div className="mt-5 flex items-start justify-between gap-4 pt-5 border-t border-line dark:border-edge">
            <div>
              <div className="font-medium text-[15px]">الوضع المجهول</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2 mt-1 leading-loose">اسمك وصورتك مخفيان للمتوافقين حتى يتم قبول طلب التواصل بينكما.</div>
            </div>
            <Toggle checked={anon} onChange={setAnon}/>
          </div>
        </Card>
      </div>
    </OnboardShell>
  );
};

// ---- P9: Questionnaire Overview ----
const PageQuestionnaireOverview = ({ go }) => {
  const cats = [
    { id: 1, name: "القيم والدين", icon: "mosque", count: 10, done: 10, status: "done" },
    { id: 2, name: "الشخصية",     icon: "smile",  count: 10, done: 6,  status: "progress" },
    { id: 3, name: "نمط الحياة",  icon: "leaf",   count: 10, done: 0,  status: "new" },
    { id: 4, name: "توقعات الزواج", icon: "diamond", count: 10, done: 0, status: "new" },
  ];
  const totalDone = cats.reduce((a,c)=>a+c.done,0);
  return (
    <OnboardShell step={3} title="الاستبيان الشخصي" sub="٤٠ سؤال في ٤ أقسام — ما يقارب ١٠ دقائق. تستطيع التوقف والعودة في أي وقت.">
      <Card className="mb-5">
        <div className="flex items-center justify-between mb-3">
          <div className="text-[14px]">التقدم الإجمالي</div>
          <div className="numerals text-[14px] text-gold"><span className="font-serif-en">{totalDone}</span>/40</div>
        </div>
        <ProgressBar value={totalDone} max={40}/>
      </Card>
      <div className="space-y-3">
        {cats.map(c => {
          const pct = c.done/c.count;
          const status = c.status==="done" ? <Badge tone="green">مكتمل</Badge> : c.status==="progress" ? <Badge tone="amber">قيد التقدم</Badge> : <Badge tone="neutral">لم يبدأ</Badge>;
          return (
            <Card key={c.id} className="hover:shadow-soft">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${c.status==="done" ? "bg-green/10 text-green" : "bg-gold/10 text-gold"}`}><Icon name={c.icon} size={22}/></div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="font-display text-[17px]">{c.name}</div>
                    {status}
                  </div>
                  <div className="numerals text-[12.5px] text-ink-2 dark:text-fog-2 mb-2"><span className="font-serif-en">{c.done}</span> من {c.count} أسئلة</div>
                  <ProgressBar value={pct*100}/>
                </div>
                <button onClick={()=>go("q-question")} className="px-4 py-2.5 rounded-xl bg-gold text-white text-[13px] shrink-0">
                  {c.status==="done" ? "مراجعة" : c.status==="progress" ? "متابعة" : "ابدأ"}
                </button>
              </div>
            </Card>
          );
        })}
      </div>
      <div className="mt-7 flex justify-end">
        <GoldButton onClick={()=>go("q-all-done")} disabled={totalDone < 40} icon={<Icon name="arrowLeft" size={16}/>}>إنهاء الاستبيان</GoldButton>
      </div>
    </OnboardShell>
  );
};

// ---- P10: Single Question ----
const PageQuestion = ({ go }) => {
  const total = 10, current = 3;
  const [answer, setAnswer] = useState("");
  const options = [
    { id: "a", text: "أرى أن الالتزام الديني أساس مهم جداً في الحياة الزوجية", weight: 5 },
    { id: "b", text: "الالتزام الديني مهم لكن مع مرونة في التفاصيل", weight: 4 },
    { id: "c", text: "أؤمن بالقيم العامة دون التمسك بكل التفاصيل الشكلية", weight: 3 },
    { id: "d", text: "أؤمن بالأخلاق أكثر من الطقوس الدينية", weight: 2 },
  ];
  return (
    <OnboardShell step={3} title=" " onBack={()=>go("q-overview")}>
      <div className="-mt-6">
        <div className="flex items-center justify-between mb-2 text-[12.5px] text-ink-2 dark:text-fog-2">
          <span className="inline-flex items-center gap-2"><Icon name="mosque" size={14} className="text-gold"/> القيم والدين</span>
          <span className="numerals">سؤال <span className="font-serif-en text-gold">{current}</span> من {total}</span>
        </div>
        <ProgressBar value={(current/total)*100} className="mb-8"/>

        <h2 className="font-display text-2xl leading-relaxed mb-6 page-enter">إلى أي مدى يؤثر الالتزام الديني في اختيارك لشريك الحياة؟</h2>

        <div className="space-y-3 page-enter">
          {options.map(o => (
            <RadioCard key={o.id} checked={answer===o.id} onClick={()=>setAnswer(o.id)}>
              <div className="text-[15.5px] leading-relaxed">{o.text}</div>
            </RadioCard>
          ))}
        </div>

        <div className="mt-10 flex items-center justify-between">
          <OutlineButton onClick={()=>go("q-overview")} iconLeft={<Icon name="arrowRight" size={16}/>}>السابق</OutlineButton>
          <GoldButton disabled={!answer} onClick={()=>go("q-category-done")} icon={<Icon name="arrowLeft" size={16}/>}>التالي</GoldButton>
        </div>

        <div className="mt-10">
          <div className="text-[12px] text-ink-3 mb-3">أمثلة على أنواع الأسئلة الأخرى</div>
          <div className="grid sm:grid-cols-2 gap-3">
            <Card padded={false} className="p-4">
              <div className="text-[12px] text-ink-2 dark:text-fog-2 mb-2">سؤال تقييمي ١-٥</div>
              <div className="text-[14px] mb-3">ما مدى أهمية العائلة الممتدة لك؟</div>
              <div className="flex items-center justify-between gap-1.5">
                {[1,2,3,4,5].map(n => (
                  <button key={n} className={`flex-1 aspect-square rounded-full border-2 font-serif-en flex items-center justify-center transition ${n===4?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417] text-gold":"border-line dark:border-edge text-ink-3"}`}>{n}</button>
                ))}
              </div>
              <div className="flex justify-between text-[11px] text-ink-3 mt-2"><span>غير مهمة</span><span>مهمة جداً</span></div>
            </Card>
            <Card padded={false} className="p-4">
              <div className="text-[12px] text-ink-2 dark:text-fog-2 mb-2">سؤال متعدد الاختيارات</div>
              <div className="text-[14px] mb-3">ما هواياتك المفضلة؟</div>
              <div className="flex flex-wrap gap-2">
                {["القراءة","الرياضة","الطبخ","السفر","الموسيقى","الزراعة"].map((t,i) => (
                  <span key={t} className={`px-3 py-1.5 rounded-full text-[12.5px] border ${i<3?"bg-gold/10 border-gold text-gold":"border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>{t}</span>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </OnboardShell>
  );
};

// ---- P11: Category Complete ----
const PageCategoryDone = ({ go }) => {
  return (
    <OnboardShell step={3} title=" ">
      <div className="-mt-6 text-center max-w-xl mx-auto py-8">
        <div className="w-24 h-24 mx-auto rounded-full bg-green/10 text-green flex items-center justify-center mb-6 page-enter">
          <Icon name="check" size={48} stroke={2.4}/>
        </div>
        <h2 className="font-display text-3xl mb-3">أحسنت!</h2>
        <p className="text-ink-2 dark:text-fog-2 text-[15px] leading-loose mb-8">أكملت قسم "القيم والدين" بنجاح. إجاباتك تساعدنا في فهم أعمق لما يهمك.</p>

        <Card className="text-right mb-7">
          <div className="font-display text-[15px] mb-3">ملخص إجاباتك</div>
          <div className="space-y-2.5 text-[13.5px]">
            {[
              ["الالتزام الديني","مهم جداً مع مرونة"],
              ["الصلاة","منتظم"],
              ["العائلة الممتدة","مهمة جداً (٤/٥)"],
              ["تربية الأبناء","تربية محافظة منفتحة"],
            ].map(([k,v]) => (
              <div key={k} className="flex items-center justify-between py-2 border-b last:border-0 border-line dark:border-edge">
                <span className="text-ink-2 dark:text-fog-2">{k}</span>
                <span className="font-medium">{v}</span>
              </div>
            ))}
          </div>
        </Card>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <OutlineButton onClick={()=>go("q-overview")}>العودة للأقسام</OutlineButton>
          <GoldButton onClick={()=>go("q-question")} icon={<Icon name="arrowLeft" size={16}/>}>القسم التالي</GoldButton>
        </div>
      </div>
    </OnboardShell>
  );
};

// ---- P12: All Done ----
const PageQuestionnaireDone = ({ go }) => {
  return (
    <OnboardShell step={3} title=" ">
      <div className="-mt-6 text-center max-w-xl mx-auto py-6">
        <div className="relative w-32 h-32 mx-auto mb-7">
          <div className="absolute inset-0 rounded-full bg-gold/10 animate-ping"/>
          <div className="absolute inset-3 rounded-full bg-gold flex items-center justify-center">
            <Icon name="sparkles" size={48} className="text-white"/>
          </div>
        </div>
        <h2 className="font-display text-3xl mb-3">أكملت الاستبيان بنجاح</h2>
        <p className="text-ink-2 dark:text-fog-2 text-[15.5px] leading-loose mb-7">٤٠ سؤالاً، أربعة أقسام، صورة كاملة عنك. تبقى خطوة واحدة لاكتمال ملفك.</p>

        <div className="grid grid-cols-2 gap-3 mb-7">
          {[
            ["القيم والدين","mosque"],
            ["الشخصية","smile"],
            ["نمط الحياة","leaf"],
            ["توقعات الزواج","diamond"],
          ].map(([t,icn]) => (
            <Card key={t} className="text-center !p-4">
              <div className="w-10 h-10 mx-auto rounded-full bg-green/10 text-green flex items-center justify-center mb-2"><Icon name="check" size={18} stroke={2.4}/></div>
              <div className="text-[13.5px]">{t}</div>
            </Card>
          ))}
        </div>

        <GoldButton size="lg" onClick={()=>go("face-intro")} icon={<Icon name="arrowLeft" size={16}/>}>متابعة لتحليل الوجه</GoldButton>
      </div>
    </OnboardShell>
  );
};

// ---- P13: Face Analysis Intro ----
const PageFaceIntro = ({ go }) => {
  const steps = [
    { icon: "shield",  t: "سنتحقق من أنك شخص حقيقي", d: "خطوة بسيطة بحركات الوجه لمنع الحسابات الوهمية." },
    { icon: "camera",  t: "ستلتقط ٣ صور بسيطة",     d: "صورة من الأمام واثنتان من الجانب — دقائق فقط." },
    { icon: "lock",    t: "الخصوصية محفوظة",        d: "الصور للتحليل فقط، ولا تظهر لأي مستخدم." },
  ];
  return (
    <OnboardShell step={4} title="تحليل الوجه" sub="خطوة بسيطة لتحليل انطباعي من ملامحك — لا حُكم نهائي، فقط إثراء للتوافق.">
      <div className="space-y-3 mb-6">
        {steps.map((s,i) => (
          <Card key={i} className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gold/10 text-gold flex items-center justify-center shrink-0"><Icon name={s.icon} size={22}/></div>
            <div className="flex-1">
              <div className="font-medium text-[15.5px]">{s.t}</div>
              <div className="text-[13.5px] text-ink-2 dark:text-fog-2 leading-loose mt-1">{s.d}</div>
            </div>
            <span className="font-serif-en text-2xl text-ink-3">{i+1}</span>
          </Card>
        ))}
      </div>

      <Card className="bg-amber-soft dark:bg-[#2a2010] border-[#e9d4a8] dark:border-[#5b4720]">
        <div className="flex items-start gap-3 text-[13.5px]">
          <Icon name="info" size={18} className="text-amber shrink-0 mt-0.5"/>
          <div className="text-amber dark:text-[#e4b266] leading-loose">تأكد من <span className="font-medium">الإضاءة الجيدة</span> ووضوح وجهك في الإطار، وأن لا يوجد نظارة شمسية أو قناع.</div>
        </div>
      </Card>

      <div className="flex items-center justify-between mt-8">
        <button onClick={()=>go("self-physical")} className="text-[13px] text-ink-2 dark:text-fog-2 hover:text-gold">تخطي</button>
        <GoldButton onClick={()=>go("face-liveness")} icon={<Icon name="camera" size={16}/>}>ابدأ التحقق</GoldButton>
      </div>
    </OnboardShell>
  );
};

// ---- P14: Liveness Check ----
const PageLiveness = ({ go }) => {
  const [step, setStep] = useState(2);
  const steps = ["انظر للكاميرا","ارمش","لف يميناً","لف يساراً"];
  return (
    <OnboardShell step={4} title=" ">
      <div className="-mt-4 max-w-md mx-auto">
        <div className="flex items-center justify-center gap-2 mb-6">
          {steps.map((_, i) => (
            <div key={i} className={`w-8 h-8 rounded-full flex items-center justify-center font-serif-en text-[13px] transition ${i<step?"bg-green text-white":i===step?"bg-gold text-white ring-4 ring-gold/15":"bg-paper-2 dark:bg-night-3 text-ink-3 border border-line dark:border-edge"}`}>
              {i<step ? <Icon name="check" size={14}/> : i+1}
            </div>
          ))}
        </div>

        <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-night border border-edge mb-5">
          <div className="absolute inset-0 bg-gradient-to-b from-night-2 via-night to-night flex items-center justify-center">
            <div className="w-60 h-72 rounded-[50%] border-2 border-dashed border-gold/60 flex items-center justify-center">
              <Icon name="user" size={88} className="text-gold/30"/>
            </div>
          </div>
          <div className="absolute inset-0 ring-4 ring-inset ring-gold/0"/>
          {/* corner brackets */}
          {["top-4 right-4 border-t-2 border-r-2","top-4 left-4 border-t-2 border-l-2","bottom-4 right-4 border-b-2 border-r-2","bottom-4 left-4 border-b-2 border-l-2"].map(c => (
            <span key={c} className={`absolute w-6 h-6 border-gold ${c}`}/>
          ))}
          <div className="absolute top-4 inset-x-0 text-center">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-night/60 text-fog text-[11.5px] backdrop-blur"><span className="w-1.5 h-1.5 rounded-full bg-rose animate-pulse"/> LIVE</span>
          </div>
        </div>

        <div className="text-center mb-5">
          <div className="text-[12.5px] text-ink-3 mb-1.5">الخطوة الحالية</div>
          <div className="font-display text-3xl text-gold">{steps[step]}</div>
        </div>

        <Card className="bg-amber-soft dark:bg-[#2a2010] border-[#e9d4a8] dark:border-[#5b4720] !p-3.5">
          <div className="flex items-center gap-2.5 text-[13px] text-amber dark:text-[#e4b266]">
            <Icon name="alert" size={16}/>
            الإضاءة ضعيفة قليلاً — جرب في مكان أفضل للحصول على دقة أعلى.
          </div>
        </Card>

        <div className="flex gap-3 mt-5">
          <OutlineButton className="flex-1" onClick={()=>setStep(Math.max(0,step-1))}>إعادة</OutlineButton>
          <GoldButton className="flex-1" onClick={()=>{ if(step<3) setStep(step+1); else go("face-capture"); }}>متابعة</GoldButton>
        </div>
      </div>
    </OnboardShell>
  );
};

// ---- P15: Photo Capture ----
const PagePhotoCapture = ({ go }) => {
  const [shot, setShot] = useState(false);
  return (
    <OnboardShell step={4} title=" ">
      <div className="-mt-4 max-w-md mx-auto">
        <div className="flex items-center justify-between mb-5">
          <div className="text-[13px] text-ink-2 dark:text-fog-2">صورة <span className="font-serif-en text-gold">١</span> من <span className="font-serif-en">٣</span></div>
          <Badge tone="gold">من الأمام</Badge>
        </div>

        <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-night mb-5">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-60 h-72 rounded-[50%] border-2 border-gold flex items-center justify-center">
              <ProfileAvatar name="أحمد" size={140} tone="gold"/>
            </div>
          </div>
          {/* gold filling ring */}
          <svg className="absolute inset-0 -rotate-90 m-auto" width="100" height="100" style={{top:"calc(50% - 50px)", left:"calc(50% - 50px)"}}>
            <circle cx="50" cy="50" r="44" stroke="#ffffff20" strokeWidth="3" fill="none"/>
            <circle cx="50" cy="50" r="44" stroke="#B8975A" strokeWidth="3" fill="none" strokeDasharray="276" strokeDashoffset={shot?0:80} strokeLinecap="round" style={{transition:"all 1.5s ease"}}/>
          </svg>
          <div className="absolute bottom-4 inset-x-0 text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-night/70 text-fog text-[12px] backdrop-blur">
              <Icon name="check" size={12} className="text-green"/> الإضاءة ممتازة — لا تتحرك
            </div>
          </div>
        </div>

        <div className="text-center mb-4 text-[14px] text-ink-2 dark:text-fog-2">انظر للأمام مباشرة وأبقِ وجهك داخل الإطار</div>

        {!shot ? (
          <button onClick={()=>setShot(true)} className="mx-auto w-20 h-20 rounded-full bg-gold ring-4 ring-gold/30 flex items-center justify-center text-white shadow-card active:scale-95 transition">
            <span className="w-12 h-12 rounded-full bg-white"/>
          </button>
        ) : (
          <div className="flex gap-3">
            <OutlineButton className="flex-1" onClick={()=>setShot(false)}>إعادة</OutlineButton>
            <GoldButton className="flex-1" onClick={()=>go("face-processing")}>التالي</GoldButton>
          </div>
        )}
      </div>
    </OnboardShell>
  );
};

// ---- P16: Face Processing ----
const PageFaceProcessing = ({ go }) => {
  useEffect(() => { const t = setTimeout(() => go("face-traits"), 3500); return () => clearTimeout(t); }, []);
  return (
    <OnboardShell step={4} title=" ">
      <div className="-mt-6 text-center max-w-md mx-auto py-12">
        <div className="flex items-center justify-center gap-3 mb-7">
          {[0,1,2].map(i => (
            <div key={i} className="relative w-16 h-16 rounded-full overflow-hidden ring-2 ring-gold">
              <div className="absolute inset-0 bg-gradient-to-br from-gold/30 to-green/30 flex items-center justify-center">
                <Icon name="user" size={28} className="text-white/80"/>
              </div>
              <div className="absolute -bottom-0 -right-0 w-5 h-5 rounded-full bg-green flex items-center justify-center"><Icon name="check" size={12} className="text-white"/></div>
            </div>
          ))}
        </div>
        <div className="font-display text-2xl mb-3 inline-flex items-center gap-2">جاري تحليل ملامحك <span className="dots text-gold"><span/><span/><span/></span></div>
        <ProgressBar value={62} className="my-5"/>
        <p className="text-[13.5px] text-ink-2 dark:text-fog-2">هذا قد يستغرق لحظة. نمر على ٥ مؤشرات للملامح بدقة.</p>
        <div className="grid grid-cols-3 gap-2 mt-7 text-[11px] text-ink-3">
          {["كشف الوجه","قياس النقاط","حساب التماثل","التعبير","الانطباع"].slice(0,3).map(s => (
            <div key={s} className="bg-paper-2 dark:bg-night-3 rounded-lg py-2"><Icon name="check" size={12} className="text-green inline ms-1"/> {s}</div>
          ))}
        </div>
      </div>
    </OnboardShell>
  );
};

// ---- P17: Trait Confirmation ----
const PageTraits = ({ go }) => {
  const traitsInit = [
    { name: "اجتماعي ودود", pct: 78, ok: true },
    { name: "هادئ متأني",  pct: 65, ok: true },
    { name: "عملي منظم",   pct: 72, ok: true },
    { name: "عاطفي حساس",  pct: 54, ok: false },
    { name: "انطوائي تأملي", pct: 41, ok: true },
  ];
  const [traits, setTraits] = useState(traitsInit);
  return (
    <OnboardShell step={4} title="الانطباع الأولي من ملامحك" sub="هذا انطباع تقديري فقط — أنت من يعرف نفسه. أكّد ما يناسبك واستبعد البقية.">
      <div className="grid sm:grid-cols-2 gap-3">
        {traits.map((t,i) => (
          <Card key={t.name} className="flex items-center gap-4">
            <ScoreRing value={t.pct} size={64} stroke={6}/>
            <div className="flex-1">
              <div className="font-medium text-[15px]">{t.name}</div>
              <div className="text-[12px] text-ink-3 mt-0.5">دقة التحليل: <span className="font-serif-en">{t.pct}</span>٪</div>
              <div className="flex items-center gap-2 mt-2.5">
                <button onClick={()=>setTraits(arr=>arr.map((x,idx)=>idx===i?{...x,ok:true}:x))} className={`px-2.5 py-1 rounded-full text-[12px] border ${t.ok?"bg-green text-white border-green":"border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>مناسب</button>
                <button onClick={()=>setTraits(arr=>arr.map((x,idx)=>idx===i?{...x,ok:false}:x))} className={`px-2.5 py-1 rounded-full text-[12px] border ${!t.ok?"bg-rose text-white border-rose":"border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>غير مناسب</button>
              </div>
            </div>
          </Card>
        ))}
      </div>
      <Card className="mt-5 bg-paper-2 dark:bg-night-3 !p-4">
        <div className="flex items-start gap-2.5 text-[13px] text-ink-2 dark:text-fog-2">
          <Icon name="info" size={16} className="text-gold shrink-0 mt-0.5"/>
          <div>هذا انطباع تقديري فقط — ليس حكماً قاطعاً. ما تختاره أنت يحدد كيف نقدّمك في المطابقة.</div>
        </div>
      </Card>
      <div className="mt-7 flex justify-end">
        <GoldButton onClick={()=>go("self-physical")} icon={<Icon name="arrowLeft" size={16}/>}>متابعة</GoldButton>
      </div>
    </OnboardShell>
  );
};

// ---- P18: Self Report Physical ----
const PageSelfPhysical = ({ go }) => {
  const [height, setHeight] = useState(178);
  const [bodyType, setBodyType] = useState("athletic");
  const [skin, setSkin] = useState(2);
  return (
    <OnboardShell step={4} title="أخبرنا عن نفسك" sub="بياناتك الجسدية تساعدنا في تحسين دقة التوافق.">
      <div className="space-y-5">
        <Card>
          <div className="flex items-center justify-between mb-3">
            <div className="text-[14px]">الطول</div>
            <div className="numerals text-gold font-serif-en text-2xl">{height} <span className="text-base text-ink-2 font-body">سم</span></div>
          </div>
          <input type="range" min={140} max={210} value={height} onChange={e=>setHeight(+e.target.value)} className="w-full"/>
          <div className="flex justify-between text-[11px] text-ink-3 mt-1 numerals"><span>١٤٠</span><span>٢١٠</span></div>
        </Card>

        <Card>
          <div className="text-[14px] mb-3">بنية الجسم</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[["slim","نحيف","leaf"],["athletic","رياضي","activity"],["average","متوسط","user"],["fuller","ممتلئ","heart"]].map(([id,lbl,icn]) => (
              <button key={id} onClick={()=>setBodyType(id)} className={`p-3 rounded-2xl border-2 transition flex flex-col items-center gap-1.5 ${bodyType===id?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417]":"border-line dark:border-edge"}`}>
                <Icon name={icn} size={22} className={bodyType===id?"text-gold":"text-ink-3"}/>
                <span className="text-[13px]">{lbl}</span>
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <div className="text-[14px] mb-3">لون البشرة</div>
          <div className="flex items-center justify-around">
            {["#F1D6B2","#E0B388","#C29066","#8E6440"].map((c,i) => (
              <button key={c} onClick={()=>setSkin(i)} className={`w-14 h-14 rounded-full ring-2 transition ${skin===i?"ring-gold ring-offset-2 ring-offset-paper-card dark:ring-offset-night-2":"ring-line dark:ring-edge"}`} style={{background:c}}/>
            ))}
          </div>
        </Card>
      </div>
      <div className="mt-7 flex justify-end">
        <GoldButton onClick={()=>go("self-prefs")} icon={<Icon name="arrowLeft" size={16}/>}>التالي</GoldButton>
      </div>
    </OnboardShell>
  );
};

// ---- P19: Self Report Preferences ----
const PageSelfPrefs = ({ go }) => {
  const [bodyTypes, setBodyTypes] = useState(["athletic","average"]);
  const [heightRange, setHeightRange] = useState([155,175]);
  const [ageRange, setAgeRange] = useState([24,32]);
  const [importance, setImportance] = useState(3);
  return (
    <OnboardShell step={4} title="تفضيلاتك" sub="ما الذي يقترب من تصورك؟ تستطيع تعديلها لاحقاً.">
      <div className="space-y-5">
        <Card>
          <div className="text-[14px] mb-3">بنية الجسم المفضلة (متعدد)</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[["slim","نحيف"],["athletic","رياضي"],["average","متوسط"],["fuller","ممتلئ"]].map(([id,lbl]) => {
              const sel = bodyTypes.includes(id);
              return <button key={id} onClick={()=>setBodyTypes(b=>sel?b.filter(x=>x!==id):[...b,id])} className={`p-3 rounded-2xl border-2 text-[13px] transition ${sel?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417] text-gold":"border-line dark:border-edge"}`}>{lbl}</button>;
            })}
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between mb-3">
            <div className="text-[14px]">نطاق الطول</div>
            <div className="numerals text-gold font-serif-en">{heightRange[0]}–{heightRange[1]} <span className="text-[13px] text-ink-2 font-body">سم</span></div>
          </div>
          <div className="space-y-2">
            <input type="range" min={140} max={210} value={heightRange[0]} onChange={e=>setHeightRange([+e.target.value, heightRange[1]])} className="w-full"/>
            <input type="range" min={140} max={210} value={heightRange[1]} onChange={e=>setHeightRange([heightRange[0], +e.target.value])} className="w-full"/>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between mb-3">
            <div className="text-[14px]">نطاق العمر</div>
            <div className="numerals text-gold font-serif-en">{ageRange[0]}–{ageRange[1]} <span className="text-[13px] text-ink-2 font-body">سنة</span></div>
          </div>
          <div className="space-y-2">
            <input type="range" min={18} max={60} value={ageRange[0]} onChange={e=>setAgeRange([+e.target.value, ageRange[1]])} className="w-full"/>
            <input type="range" min={18} max={60} value={ageRange[1]} onChange={e=>setAgeRange([ageRange[0], +e.target.value])} className="w-full"/>
          </div>
        </Card>

        <Card>
          <div className="text-[14px] mb-3">أهمية المظهر لك</div>
          <div className="flex items-center justify-between gap-1.5">
            {[1,2,3,4,5].map(n => (
              <button key={n} onClick={()=>setImportance(n)} className={`flex-1 aspect-square rounded-full border-2 font-serif-en flex items-center justify-center transition ${n===importance?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417] text-gold":"border-line dark:border-edge text-ink-3"}`}>{n}</button>
            ))}
          </div>
          <div className="flex justify-between text-[11px] text-ink-3 mt-2"><span>غير مهم</span><span>مهم جداً</span></div>
        </Card>

        <Card className="bg-paper-2 dark:bg-night-3 !p-4">
          <div className="flex items-start gap-2.5 text-[13px] text-ink-2 dark:text-fog-2">
            <Icon name="info" size={16} className="text-gold shrink-0 mt-0.5"/>
            <div>التفضيلات الشكلية تمثل <span className="font-serif-en text-gold">١٥٪</span> فقط من حساب التوافق. الباقي للقيم والشخصية ونمط الحياة.</div>
          </div>
        </Card>
      </div>

      <div className="mt-7 flex justify-end">
        <GoldButton onClick={()=>go("onboard-done")} icon={<Icon name="arrowLeft" size={16}/>}>إنهاء</GoldButton>
      </div>
    </OnboardShell>
  );
};

// ---- P20: Onboarding Complete ----
const PageOnboardDone = ({ go }) => {
  return (
    <OnboardShell step={5} title=" ">
      <div className="-mt-6 text-center max-w-xl mx-auto py-6">
        <div className="relative w-32 h-32 mx-auto mb-7">
          <div className="absolute inset-0 rounded-full bg-gold/15 animate-ping"/>
          <div className="absolute inset-2 rounded-full bg-paper-card dark:bg-night-2 border-2 border-gold flex items-center justify-center">
            <Icon name="sparkles" size={56} className="text-gold"/>
          </div>
        </div>
        <h2 className="font-display text-3xl mb-2">ملفك جاهز ✨</h2>
        <p className="text-ink-2 dark:text-fog-2 text-[15px] leading-loose mb-7">عرفناك جيداً. وقت لقاء من يناسبك.</p>

        <Card className="text-right mb-6">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <div className="text-[11.5px] text-ink-3 mb-1.5">نوع الشخصية</div>
              <div className="font-display text-[15.5px]">عقلاني<br/>اجتماعي</div>
            </div>
            <div className="text-center">
              <div className="text-[11.5px] text-ink-3 mb-2">جاهزية الزواج</div>
              <ScoreRing value={84} size={92} stroke={7}/>
            </div>
            <div>
              <div className="text-[11.5px] text-ink-3 mb-1.5">الصفة الغالبة</div>
              <div className="font-display text-[15.5px]">اجتماعي<br/>ودود</div>
            </div>
          </div>
        </Card>

        <GoldButton size="lg" onClick={()=>go("dashboard")} icon={<Icon name="arrowLeft" size={16}/>}>اكتشف التوافقات</GoldButton>
        <div className="mt-3"><GhostButton onClick={()=>go("report")}>عرض التقرير الكامل</GhostButton></div>
      </div>
    </OnboardShell>
  );
};

window.PagesOnboarding = { PageConsent, PageProfileSetup, PageQuestionnaireOverview, PageQuestion, PageCategoryDone, PageQuestionnaireDone, PageFaceIntro, PageLiveness, PagePhotoCapture, PageFaceProcessing, PageTraits, PageSelfPhysical, PageSelfPrefs, PageOnboardDone };
Object.assign(window, window.PagesOnboarding);


// ====== src/pages-main.jsx ======
// =============== Main App Pages: P21-P30 ===============

// Reusable layout for the main app: sidebar on desktop, header+bottom-tabs on mobile.
const AppLayout = ({ go, current, title, sub, headerRight, children, hideBottomNav, user, fullBleed }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex flex-col lg:flex-row">
    <UserSidebar current={current} onGo={go} user={user}/>
    <main className="flex-1 min-w-0 flex flex-col">
      <div className="lg:hidden"><AppHeader title={title} sub={sub} right={headerRight}/></div>
      <div className={`hidden lg:block px-8 py-6 border-b border-line dark:border-edge sticky top-0 bg-paper/90 dark:bg-night/90 backdrop-blur-md z-10`}>
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl">{title}</h1>
            {sub && <p className="text-ink-2 dark:text-fog-2 text-sm mt-1">{sub}</p>}
          </div>
          <div className="flex items-center gap-2">{headerRight}</div>
        </div>
      </div>
      <div className={`flex-1 ${fullBleed ? "" : "px-4 lg:px-8 py-5 lg:py-7 pb-28 lg:pb-10"}`}>{children}</div>
      {!hideBottomNav && <BottomTabs current={current} onGo={go}/>}
    </main>
  </div>
);

// ---- P21: Dashboard ----
const PageDashboard = ({ go, subscribed }) => {
  return (
    <AppLayout go={go} current="dashboard" title="مرحباً، أحمد 👋" sub="إليك ملخص اليوم"
      headerRight={<button onClick={()=>go("notifs")} className="relative p-2.5 rounded-xl border border-line dark:border-edge"><Icon name="bell" size={18}/><span className="absolute -top-1 -left-1 w-2 h-2 rounded-full bg-gold"/></button>}>
      <div className="space-y-5 lg:space-y-6 max-w-5xl">
        {/* Quick stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "توافقات", value: 12, icon: "heart", tone: "gold" },
            { label: "طلبات", value: 3, icon: "inbox", tone: "green" },
            { label: "رسائل", value: 5, icon: "chat", tone: "amber" },
          ].map(s => (
            <Card key={s.label} className="!p-4">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${s.tone==="gold"?"bg-gold/10 text-gold":s.tone==="green"?"bg-green/10 text-green":"bg-amber-soft text-amber"}`}><Icon name={s.icon} size={18}/></div>
              <div className="font-serif-en text-2xl numerals">{s.value}</div>
              <div className="text-[12px] text-ink-2 dark:text-fog-2">{s.label}</div>
            </Card>
          ))}
        </div>

        {/* Personal report card */}
        <Card className="relative overflow-hidden">
          <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full bg-gold/10 blur-2xl"/>
          <div className="relative flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <ScoreRing value={84} size={108} stroke={8} sublabel="جاهزية الزواج"/>
            <div className="flex-1">
              <Badge tone="gold">تقريرك الشخصي</Badge>
              <div className="font-display text-2xl mt-2">عقلاني اجتماعي</div>
              <p className="text-ink-2 dark:text-fog-2 text-[14px] mt-1.5 leading-loose">شخصية متوازنة بين المنطق والعاطفة، تنجذب للحوار العميق والاستقرار العملي.</p>
              <div className="flex flex-wrap gap-2 mt-3">
                {["استقرار","عائلة","نمو","تواصل صريح"].map(t => <Badge key={t} tone="neutral">{t}</Badge>)}
              </div>
            </div>
            <OutlineButton onClick={()=>go("report")} icon={<Icon name="arrowLeft" size={14}/>}>عرض التقرير</OutlineButton>
          </div>
        </Card>

        {/* Latest matches */}
        <div>
          <SectionHead title="آخر التوافقات" sub={subscribed ? "نسب التوافق محدّثة الآن" : "اشترك لتشاهد من وافقوا معك"} action={<button onClick={()=>go("matches")} className="text-[13px] text-gold inline-flex items-center gap-1">عرض الكل <Icon name="arrowLeft" size={14}/></button>}/>
          <div className="grid sm:grid-cols-3 gap-3">
            {[0,1,2].map(i => {
              const m = buildMatch(i, {anonymous: !subscribed});
              const locked = !subscribed;
              return (
                <Card key={i} className={`!p-4 relative ${locked?"overflow-hidden":""}`}>
                  {locked && <div className="absolute inset-0 backdrop-blur-md bg-paper-card/60 dark:bg-night-2/60 flex flex-col items-center justify-center gap-2 z-10 rounded-2xl">
                    <Icon name="lock" size={22} className="text-gold"/>
                    <button onClick={()=>go("pricing")} className="text-[12px] text-gold underline">اشترك للعرض</button>
                  </div>}
                  <div className="flex items-center gap-3">
                    <ProfileAvatar name={m.name} anonymous={m.anonymous} size={48} tone={m.tone}/>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{m.anonymous ? "مستخدم مجهول" : m.name}</div>
                      <div className="text-[12px] text-ink-3">{m.age} • {m.city}</div>
                    </div>
                    <div className="font-serif-en text-gold text-xl numerals">{m.score}<span className="text-[11px]">٪</span></div>
                  </div>
                  <div className="mt-3 text-[12.5px] text-ink-2 dark:text-fog-2 line-clamp-1">{m.reasons[0]}</div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Profile completion / banner */}
        <Card className="bg-gradient-to-l from-[#FBF6E9] to-transparent dark:from-[#332a17] dark:to-night-2 border-gold/30">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="w-12 h-12 rounded-2xl bg-gold/15 text-gold flex items-center justify-center"><Icon name="sparkles" size={22}/></div>
            <div className="flex-1 min-w-0">
              <div className="font-display text-[16px]">اكتمل ملفك بنسبة <span className="text-gold font-serif-en">٨٤٪</span></div>
              <ProgressBar value={84} className="mt-2"/>
              <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-2">أضف صورة ملف لزيادة فرص التوافق إلى ٩٢٪.</div>
            </div>
            <OutlineButton size="sm" onClick={()=>go("settings-edit")}>إكمال الملف</OutlineButton>
          </div>
        </Card>
      </div>
    </AppLayout>
  );
};

// ---- P22: Personal Report ----
const PageReport = ({ go }) => {
  const cats = [
    { name: "القيم والدين", value: 78, icon: "mosque" },
    { name: "الشخصية", value: 65, icon: "smile" },
    { name: "نمط الحياة", value: 82, icon: "leaf" },
    { name: "توقعات الزواج", value: 71, icon: "diamond" },
  ];
  return (
    <AppLayout go={go} current="report" title="تقريرك الشخصي" sub="تحليل عميق لشخصيتك وقيمك"
      headerRight={<OutlineButton size="sm" icon={<Icon name="share" size={14}/>}>شارك</OutlineButton>}>
      <div className="space-y-5 max-w-4xl">
        <Card>
          <div className="flex items-center gap-4">
            <ProfileAvatar name="أحمد محمود" size={72}/>
            <div className="flex-1">
              <div className="font-display text-xl">أحمد محمود</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2">القاهرة • ٢٨ سنة • مهندس برمجيات</div>
              <Badge tone="gold" className="mt-2">عقلاني اجتماعي</Badge>
            </div>
            <div className="hidden sm:block text-[12px] text-ink-3 text-left">
              <div>أنشئ في</div>
              <div className="numerals">٢٠ مايو ٢٠٢٦</div>
            </div>
          </div>
        </Card>

        <div className="grid lg:grid-cols-3 gap-5">
          <Card className="lg:col-span-2">
            <div className="font-display text-lg mb-4">النسب التفصيلية</div>
            <div className="space-y-4">
              {cats.map(c => (
                <div key={c.name}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="flex items-center gap-2 text-[14px]"><Icon name={c.icon} size={16} className="text-gold"/> {c.name}</span>
                    <span className="font-serif-en text-gold numerals">{c.value}٪</span>
                  </div>
                  <ProgressBar value={c.value}/>
                </div>
              ))}
            </div>

            <div className="mt-6 pt-6 border-t border-line dark:border-edge">
              <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-2.5">القيم الغالبة</div>
              <div className="flex flex-wrap gap-2">
                {["الاستقرار","العائلة","الصراحة","النمو الذاتي","الاحترام","الصبر"].map(t => <Badge key={t} tone="gold">{t}</Badge>)}
              </div>
            </div>
          </Card>

          <Card className="text-center">
            <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-2">جاهزية الزواج</div>
            <ScoreRing value={84} size={150} stroke={10}/>
            <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-3 leading-loose">جاهزية مرتفعة — وضوح في القيم والتوقعات.</div>
          </Card>
        </div>

        <div className="grid sm:grid-cols-2 gap-5">
          <Card>
            <div className="font-display text-lg mb-3 flex items-center gap-2"><Icon name="checkCircle" size={18} className="text-green"/> نقاط قوتك</div>
            <ul className="space-y-2.5 text-[14px]">
              {["تواصل صريح ومباشر","استقرار عاطفي عالٍ","قدرة على حل الخلاف بهدوء","التزام بالقيم العائلية"].map(t => (
                <li key={t} className="flex items-start gap-2"><Icon name="check" size={16} className="text-green mt-0.5 shrink-0"/> <span>{t}</span></li>
              ))}
            </ul>
          </Card>
          <Card>
            <div className="font-display text-lg mb-3 flex items-center gap-2"><Icon name="sparkles" size={18} className="text-amber"/> فرص للنمو</div>
            <ul className="space-y-2.5 text-[14px]">
              {["العمل على المرونة في التغيير","التعبير عن العواطف بشكل أوضح","تخصيص وقت للترفيه والاهتمامات"].map(t => (
                <li key={t} className="flex items-start gap-2"><Icon name="arrowLeft" size={14} className="text-amber mt-1 shrink-0"/> <span>{t}</span></li>
              ))}
            </ul>
          </Card>
        </div>

        <Card>
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gold/10 text-gold flex items-center justify-center shrink-0"><Icon name="sparkles" size={26}/></div>
            <div className="flex-1">
              <div className="font-display text-lg mb-1">انطباع الملامح</div>
              <div className="text-[13.5px] text-ink-2 dark:text-fog-2 leading-loose">صفاتك المرئية الغالبة: اجتماعي ودود، هادئ متأن. هذه السمات تتوافق مع شريكٍ متعاطف ومنفتح.</div>
              <div className="flex flex-wrap gap-2 mt-3">
                {["اجتماعي ودود","هادئ","عملي"].map(t => <Badge key={t} tone="green">{t}</Badge>)}
              </div>
            </div>
          </div>
        </Card>
      </div>
    </AppLayout>
  );
};

// ---- P23: Matches List ----
const PageMatches = ({ go, subscribed, setUserType }) => {
  const [tab, setTab] = useState("all");
  const tabs = [["all","الكل"],["high","عالية (>٨٠٪)"],["medium","متوسطة"],["new","جديدة"]];
  const matches = Array.from({length: 8}, (_, i) => buildMatch(i));
  const filtered = tab==="high" ? matches.filter(m=>m.score>=80) : tab==="medium" ? matches.filter(m=>m.score<80) : matches;
  return (
    <AppLayout go={go} current="matches" title="التوافقات" sub={`${filtered.length} نتيجة بناءً على ملفك`}
      headerRight={<button className="p-2.5 rounded-xl border border-line dark:border-edge"><Icon name="filter" size={18}/></button>}>

      {!subscribed && (
        <Card className="mb-5 bg-gradient-to-l from-[#FBF6E9] to-transparent dark:from-[#332a17] dark:to-night-2 border-gold/40">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="w-12 h-12 rounded-2xl bg-gold text-white flex items-center justify-center"><Icon name="crown" size={22}/></div>
            <div className="flex-1 min-w-0">
              <div className="font-display text-[16px]">اشترك لتكشف من وافقوا معك</div>
              <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-0.5">١٢ توافقاً عالياً ينتظر الكشف. ابدأ بـ ٤٩ ج.م/شهر.</div>
            </div>
            <GoldButton size="sm" onClick={()=>go("pricing")}>اشترك الآن</GoldButton>
          </div>
        </Card>
      )}

      <div className="flex items-center gap-2 mb-5 overflow-x-auto nice-scroll -mx-1 px-1">
        {tabs.map(([id,lbl]) => (
          <button key={id} onClick={()=>setTab(id)} className={`shrink-0 px-3.5 py-2 rounded-full text-[13px] border transition ${tab===id?"bg-gold text-white border-gold":"border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>{lbl}</button>
        ))}
        <div className="me-auto"/>
        {!subscribed && <button onClick={()=>setUserType("subscribed")} className="shrink-0 text-[11px] text-ink-3 underline">تجربة المشترك</button>}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon="heart" title="لا توجد توافقات بعد" sub="حاول لاحقاً — نطابقك مع المنضمين الجدد يومياً."/>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((m, i) => {
            const locked = !subscribed;
            return (
              <Card key={m.id} className="relative !p-0 overflow-hidden">
                {locked && (
                  <div className="absolute inset-0 backdrop-blur-[8px] bg-paper-card/50 dark:bg-night-2/60 flex flex-col items-center justify-center gap-2 z-10 shimmer">
                    <Icon name="lock" size={28} className="text-gold"/>
                    <div className="text-[12px] text-ink-2 dark:text-fog-2">اشترك لكشف هذا التوافق</div>
                  </div>
                )}
                <div className="aspect-[4/5] bg-gradient-to-br from-paper-2 to-paper dark:from-night-3 dark:to-night flex items-center justify-center relative">
                  <ProfileAvatar name={m.name} anonymous={m.anonymous} size={120} tone={m.tone}/>
                  <div className="absolute top-3 right-3">
                    <ScoreRing value={m.score} size={58} stroke={5} trackColor="rgba(255,255,255,.25)"/>
                  </div>
                  <div className="absolute top-3 left-3"><Badge tone={m.type==="متشابه"?"gold":"green"}>{m.type}</Badge></div>
                </div>
                <div className="p-4">
                  <div className="font-medium">{m.anonymous ? "مستخدم مجهول" : m.name}</div>
                  <div className="text-[12px] text-ink-3 mt-0.5 flex items-center gap-1"><Icon name="location" size={12}/> {m.city} • <span className="numerals">{m.age}</span> سنة</div>
                  <div className="mt-3 space-y-1.5">
                    {m.reasons.slice(0,2).map(r => <div key={r} className="flex items-center gap-1.5 text-[12.5px] text-ink-2 dark:text-fog-2"><Icon name="check" size={12} className="text-green"/> {r}</div>)}
                  </div>
                  <OutlineButton className="mt-4 w-full" size="sm" onClick={()=>go("match-detail")}>عرض التفاصيل</OutlineButton>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </AppLayout>
  );
};

// ---- P24: Match Detail ----
const PageMatchDetail = ({ go, subscribed }) => {
  const cats = [
    { name: "القيم والدين", you: 85, them: 88 },
    { name: "الشخصية", you: 72, them: 68 },
    { name: "نمط الحياة", you: 82, them: 79 },
    { name: "توقعات الزواج", you: 76, them: 72 },
  ];
  return (
    <AppLayout go={go} current="matches" title="تفاصيل التوافق"
      headerRight={<button className="p-2.5 rounded-xl border border-line dark:border-edge"><Icon name="moreV" size={18}/></button>}>
      <div className="max-w-4xl space-y-5">
        <Card className="relative overflow-hidden">
          <div className="absolute inset-x-0 -top-20 h-40 bg-gold/5 blur-2xl"/>
          <div className="relative flex items-center justify-around gap-3">
            <div className="text-center">
              <ProfileAvatar name="أحمد" size={88}/>
              <div className="font-medium text-[13.5px] mt-2">أنت</div>
              <div className="text-[11px] text-ink-3">عقلاني اجتماعي</div>
            </div>
            <div className="text-center">
              <ScoreRing value={87} size={132} stroke={10}/>
              <div className="mt-2"><Badge tone="green">توافق ممتاز</Badge></div>
            </div>
            <div className="text-center">
              <ProfileAvatar name="نور الهدى" size={88} tone="green" anonymous={!subscribed}/>
              <div className="font-medium text-[13.5px] mt-2">{subscribed?"نور الهدى":"مستخدمة مجهولة"}</div>
              <div className="text-[11px] text-ink-3">عاطفي هادئ</div>
            </div>
          </div>
        </Card>

        <Card>
          <div className="font-display text-lg mb-4">المقارنة التفصيلية</div>
          <div className="space-y-5">
            {cats.map(c => (
              <div key={c.name}>
                <div className="flex items-center justify-between mb-1.5 text-[13.5px]">
                  <span>{c.name}</span>
                  <span className="text-ink-3 numerals">أنت <span className="text-gold font-serif-en">{c.you}</span> • هي <span className="text-green font-serif-en">{c.them}</span></span>
                </div>
                <div className="relative h-2 bg-line dark:bg-edge rounded-full overflow-hidden">
                  <div className="absolute inset-y-0 right-0 bg-gold/60 rounded-full" style={{width:`${c.you}%`}}/>
                  <div className="absolute inset-y-0 right-0 bg-green/60 rounded-full" style={{width:`${c.them}%`, mixBlendMode:"multiply"}}/>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <div className="grid sm:grid-cols-2 gap-5">
          <Card>
            <div className="font-display text-lg mb-3 flex items-center gap-2 text-green"><Icon name="checkCircle" size={18}/> لماذا أنتما متوافقان</div>
            <div className="space-y-2.5">
              {[
                ["قيم متقاربة", "تشترك معها في الاهتمام بالعائلة والاستقرار الديني."],
                ["تواصل متقارب", "كلاكما يفضل الحوار الصريح والمباشر."],
                ["نظرة مشتركة للحياة", "تشاركان رؤية مماثلة لطبيعة العلاقة الزوجية."],
              ].map(([t,d]) => (
                <div key={t} className="p-3 rounded-xl bg-green/5 dark:bg-green/10 border border-green/15">
                  <div className="font-medium text-[14px]">{t}</div>
                  <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-0.5">{d}</div>
                </div>
              ))}
            </div>
          </Card>
          <Card>
            <div className="font-display text-lg mb-3 flex items-center gap-2 text-amber"><Icon name="info" size={18}/> نقاط الاختلاف</div>
            <div className="space-y-2.5">
              {[
                ["مستوى التلقائية", "هي أكثر تخطيطاً، أنت أكثر تلقائية — توازن صحي."],
                ["النشاط الاجتماعي", "اختلاف بسيط يفتح بابا للتنوع في الحياة."],
              ].map(([t,d]) => (
                <div key={t} className="p-3 rounded-xl bg-amber-soft dark:bg-[#2a2010] border border-[#e9d4a8]/60 dark:border-[#5b4720]/60">
                  <div className="font-medium text-[14px] text-amber dark:text-[#e4b266]">{t}</div>
                  <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-0.5">{d}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <Card>
          <div className="font-display text-lg mb-3">انطباع الملامح المتقاطع</div>
          <div className="grid sm:grid-cols-3 gap-3 text-center">
            {[["اجتماعي ودود",82,"hand"],["هادئ متأن",74,"leaf"],["عاطفي حساس",68,"heart"]].map(([t,v,icn]) => (
              <div key={t} className="p-3 rounded-xl bg-paper-2 dark:bg-night-3">
                <ScoreRing value={v} size={64} stroke={6}/>
                <div className="text-[13px] mt-2">{t}</div>
              </div>
            ))}
          </div>
        </Card>

        <div className="sticky bottom-20 lg:bottom-6 flex gap-3">
          <OutlineButton onClick={()=>go("matches")} className="lg:flex-none">العودة</OutlineButton>
          <GoldButton disabled={!subscribed} className="flex-1" icon={<Icon name="send" size={16}/>}>{subscribed ? "طلب تواصل" : "اشترك للتواصل"}</GoldButton>
        </div>
      </div>
    </AppLayout>
  );
};

// ---- P25 & P26 share layout ----
const RequestsTabs = ({ current, go }) => (
  <div className="inline-flex bg-paper-2 dark:bg-night-3 p-1 rounded-xl text-[13px]">
    {[["req-received","المستلمة"],["req-sent","المرسلة"]].map(([id,lbl]) => (
      <button key={id} onClick={()=>go(id)} className={`px-5 py-2 rounded-lg transition ${current===id?"bg-paper-card dark:bg-night-2 shadow-soft":"text-ink-2 dark:text-fog-2"}`}>{lbl}</button>
    ))}
  </div>
);

// ---- P25: Sent Requests ----
const PageRequestsSent = ({ go }) => {
  const data = [
    { name: "نور الهدى", score: 87, status: "waiting", anonymous: false, time: "منذ ساعتين", tone: "green" },
    { name: "هند علي",   score: 82, status: "pending", anonymous: true,  time: "أمس",        tone: "gold"  },
    { name: "ليلى يوسف", score: 91, status: "accepted",anonymous: false, time: "منذ ٣ أيام",  tone: "green" },
    { name: "سارة عبدالله", score: 73, status: "rejected",anonymous: true, time: "الأسبوع الماضي", tone: "stone" },
    { name: "فاطمة سالم",  score: 79, status: "expired", anonymous: true, time: "منذ شهر",   tone: "stone" },
  ];
  return (
    <AppLayout go={go} current="req-sent" title="طلبات التواصل" sub="ما أرسلتَه وما يُنتظر">
      <div className="max-w-3xl">
        <RequestsTabs current="req-sent" go={go}/>
        <div className="space-y-3 mt-5">
          {data.map((r,i) => (
            <Card key={i} className="!p-4">
              <div className="flex items-center gap-3">
                <ProfileAvatar name={r.name} anonymous={r.anonymous} size={48} tone={r.tone}/>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium">{r.anonymous?"مستخدمة مجهولة":r.name}</span>
                    <StatusBadge status={r.status}/>
                  </div>
                  <div className="text-[12px] text-ink-3 mt-0.5">{r.time}</div>
                </div>
                <div className="text-center">
                  <div className="font-serif-en text-gold text-xl numerals">{r.score}<span className="text-[11px]">٪</span></div>
                </div>
                {r.status==="pending" && <button className="ms-2 px-3 py-1.5 rounded-lg border border-line dark:border-edge text-[12px]">إلغاء</button>}
                {r.status==="accepted" && <GoldButton size="sm" onClick={()=>go("chat-room")}>محادثة</GoldButton>}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

// ---- P26: Received Requests ----
const PageRequestsReceived = ({ go }) => {
  const data = [
    { name: "كريم حسن", score: 89, time: "منذ ساعة", reasons:["قيم متقاربة","نمط حياة متوافق"], tone:"gold" },
    { name: "زياد خالد", score: 81, time: "اليوم",   reasons:["نظرة مماثلة للعائلة","صراحة في التواصل"], tone:"green" },
    { name: "محمود طارق", score: 76, time: "أمس",    reasons:["اهتمامات مشتركة"], tone:"stone" },
  ];
  return (
    <AppLayout go={go} current="req-received" title="طلبات التواصل" sub="طلبات تنتظر ردك">
      <div className="max-w-3xl">
        <RequestsTabs current="req-received" go={go}/>
        <div className="space-y-3 mt-5">
          {data.map((r,i) => (
            <Card key={i} className="!p-4 hover:shadow-soft cursor-pointer" onClick={()=>go("req-detail")}>
              <div className="flex items-start gap-3">
                <ProfileAvatar name={r.name} anonymous size={52} tone={r.tone}/>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="font-medium">مستخدم مجهول</div>
                      <div className="text-[12px] text-ink-3">{r.time}</div>
                    </div>
                    <ScoreRing value={r.score} size={52} stroke={5}/>
                  </div>
                  <div className="mt-2.5 space-y-1.5">
                    {r.reasons.map(t => <div key={t} className="flex items-center gap-1.5 text-[12.5px] text-ink-2 dark:text-fog-2"><Icon name="check" size={12} className="text-green"/> {t}</div>)}
                  </div>
                </div>
              </div>
              <div className="mt-3 flex gap-2">
                <GreenButton size="sm" className="flex-1">قبول</GreenButton>
                <OutlineButton size="sm" className="flex-1">اعتذار</OutlineButton>
              </div>
            </Card>
          ))}
        </div>
        {data.length===0 && <EmptyState icon="inbox" title="لا توجد طلبات" sub="ستظهر هنا عندما يطلب أحد التواصل معك."/>}
      </div>
    </AppLayout>
  );
};

// ---- P27: Request Detail ----
const PageRequestDetail = ({ go }) => (
  <AppLayout go={go} current="req-received" title="طلب تواصل" sub="مستخدم مجهول">
    <div className="max-w-2xl space-y-5">
      <Card className="text-center">
        <ProfileAvatar name="ك" anonymous size={92} tone="gold" className="mx-auto"/>
        <div className="mt-3"><Badge tone="neutral">مجهول حتى القبول</Badge></div>
        <div className="mt-5"><ScoreRing value={89} size={140} stroke={10}/></div>
        <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-3 max-w-xs mx-auto">توافق ممتاز في القيم والشخصية ونمط الحياة.</div>
      </Card>

      <Card>
        <div className="font-display text-lg mb-3">رسالة تعريفية</div>
        <p className="text-[14.5px] leading-loose text-ink dark:text-fog">السلام عليكم، قرأت تقريرك ووجدت توافقاً كبيراً في القيم. أبحث عن شريكة حياة جادة، أحب القراءة والسفر الهادئ. أتطلع للتعرف عليكِ بشكل محترم.</p>
      </Card>

      <div className="grid sm:grid-cols-2 gap-4">
        <Card>
          <div className="font-display text-[15px] mb-2 flex items-center gap-2 text-green"><Icon name="checkCircle" size={16}/> ما يجمعنا</div>
          <ul className="space-y-2 text-[13.5px]">
            {["نظرة مشتركة للعائلة","اهتمام بالقراءة والمعرفة","تفضيل الحوار الصريح"].map(t => <li key={t} className="flex items-start gap-2"><Icon name="check" size={14} className="text-green mt-0.5"/> {t}</li>)}
          </ul>
        </Card>
        <Card>
          <div className="font-display text-[15px] mb-2 flex items-center gap-2 text-amber"><Icon name="info" size={16}/> اختلافات بسيطة</div>
          <ul className="space-y-2 text-[13.5px]">
            {["مستوى تخطيط أعلى لديه","يفضل النشاط الاجتماعي الأهدأ"].map(t => <li key={t} className="flex items-start gap-2 text-ink-2 dark:text-fog-2"><Icon name="arrowLeft" size={12} className="text-amber mt-1"/> {t}</li>)}
          </ul>
        </Card>
      </div>

      <Card className="bg-paper-2 dark:bg-night-3 !p-4">
        <div className="flex items-start gap-2.5 text-[13px] text-ink-2 dark:text-fog-2">
          <Icon name="info" size={16} className="text-gold shrink-0 mt-0.5"/>
          <div>بعد القبول، سيتم كشف الهوية ويمكنكما التواصل مباشرة عبر المحادثة. القرار قرارك بالكامل.</div>
        </div>
      </Card>

      <div className="flex gap-3 sticky bottom-20 lg:bottom-6">
        <OutlineButton className="flex-1" onClick={()=>go("req-received")}>اعتذار</OutlineButton>
        <GreenButton className="flex-1" onClick={()=>go("chat-room")}>قبول وبدء المحادثة</GreenButton>
      </div>
    </div>
  </AppLayout>
);

// ---- P28: Chats List ----
const PageChats = ({ go }) => {
  const chats = [
    { name: "نور الهدى", last: "إن شاء الله نتفاهم على موعد قريب", time: "١٤:٣٢", unread: 2, score: 87, online: true },
    { name: "هند علي",   last: "تمام، نتكلم بكرة الصبح", time: "أمس",  unread: 0, score: 82, online: false },
    { name: "ليلى يوسف", last: "أنت أرسلت طلب التواصل", time: "الأحد", unread: 0, score: 91, online: true, system: true },
    { name: "سارة عبدالله", last: "شكراً جزيلاً 🙏 — تم استبدالها بأيقونة", time: "السبت", unread: 0, score: 73, online: false },
  ];
  return (
    <AppLayout go={go} current="chats" title="المحادثات">
      <div className="max-w-3xl">
        <div className="mb-4 flex items-center gap-2 bg-paper-card dark:bg-night-2 border border-line dark:border-edge rounded-xl px-3.5 py-2.5">
          <Icon name="search" size={16} className="text-ink-3"/>
          <input placeholder="ابحث في المحادثات…" className="flex-1 bg-transparent outline-none text-[14px]"/>
        </div>
        <div className="bg-paper-card dark:bg-night-2 border border-line dark:border-edge rounded-2xl overflow-hidden">
          {chats.map((c,i) => (
            <button key={i} onClick={()=>go("chat-room")} className="w-full text-right p-4 flex items-center gap-3 border-b last:border-0 border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3 transition">
              <ProfileAvatar name={c.name} size={52} online={c.online}/>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-medium truncate">{c.name}</span>
                    <Badge tone="gold" className="!py-0">{c.score}٪</Badge>
                  </div>
                  <span className="text-[11.5px] text-ink-3 numerals shrink-0">{c.time}</span>
                </div>
                <div className="flex items-center justify-between gap-2 mt-1">
                  <span className={`text-[13px] truncate ${c.unread?"text-ink dark:text-fog font-medium":"text-ink-2 dark:text-fog-2"}`}>{c.last}</span>
                  {c.unread > 0 && <span className="shrink-0 min-w-[20px] h-5 px-1.5 rounded-full bg-gold text-white text-[11px] flex items-center justify-center numerals">{c.unread}</span>}
                </div>
              </div>
            </button>
          ))}
        </div>
        {/* Empty state preview */}
      </div>
    </AppLayout>
  );
};

// ---- P29: Chat Room ----
const PageChatRoom = ({ go }) => {
  const msgs = [
    { from: "system", text: "تم قبول طلب التواصل. تم كشف الأسماء.", time: "السبت ٢٠:١٠" },
    { from: "them",   text: "السلام عليكم، تشرفت بمعرفتك", time: "١٠:٠٢", seen: true },
    { from: "me",     text: "وعليكم السلام ورحمة الله، تشرفت بك أيضاً", time: "١٠:٠٤", seen: true },
    { from: "them",   text: "قرأت تقريرك وأعجبني فكرك في موضوع العائلة", time: "١٠:٠٥", seen: true },
    { from: "me",     text: "شكراً لكِ — أرى أن نظرتنا متقاربة جداً. هل تحبين الحديث عن خطط المستقبل؟", time: "١٠:٠٧", seen: true },
    { from: "them",   text: "بالتأكيد. الاستقرار العائلي أولوية بالنسبة لي", time: "١٠:٠٩", seen: false },
  ];
  return (
    <AppLayout go={go} current="chats" hideBottomNav fullBleed
      title="نور الهدى"
      sub="عاطفي هادئ • متصلة الآن"
      headerRight={<><Badge tone="gold">٨٧٪</Badge><button className="p-2 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3"><Icon name="moreV"/></button></>}>
      <div className="flex flex-col h-[calc(100vh-3.5rem)] lg:h-[calc(100vh-5.5rem)]">
        {/* Ice breaker bar */}
        <div className="px-4 lg:px-8 py-2.5 bg-gold/10 dark:bg-[#332a17] border-b border-gold/20 flex items-center gap-2 text-[12.5px]">
          <Icon name="sparkles" size={14} className="text-gold"/>
          <span className="flex-1 truncate text-ink-2 dark:text-fog-2"><span className="text-gold">اقتراح:</span> "ما هي قيمة لا تساومين عليها في حياتك؟"</span>
          <button className="text-ink-3 p-1"><Icon name="x" size={14}/></button>
        </div>
        {/* Messages */}
        <div className="flex-1 overflow-y-auto nice-scroll px-4 lg:px-8 py-5 space-y-3 bg-paper-2/60 dark:bg-night-3/40">
          <div className="text-center text-[11px] text-ink-3 numerals">السبت ٢٠ مايو</div>
          {msgs.map((m,i) => {
            if (m.from === "system") return <div key={i} className="text-center text-[11px] text-ink-3 px-3 py-1.5 inline-block mx-auto"><span className="bg-paper-2 dark:bg-night-3 rounded-full px-3 py-1">{m.text}</span></div>;
            const mine = m.from === "me";
            return (
              <div key={i} className={`flex ${mine?"justify-end":"justify-start"}`}>
                <div className={`max-w-[80%] sm:max-w-md px-4 py-2.5 rounded-2xl ${mine?"bg-gold text-white rounded-bl-md":"bg-paper-card dark:bg-night-2 border border-line dark:border-edge rounded-br-md"}`}>
                  <div className="text-[14.5px] leading-relaxed">{m.text}</div>
                  <div className={`text-[10.5px] mt-1 flex items-center gap-1 ${mine?"text-white/70 justify-end":"text-ink-3"}`}>
                    <span className="numerals">{m.time}</span>
                    {mine && (m.seen ? <span className="text-[#cfe3ff]">✓✓</span> : <span>✓✓</span>)}
                  </div>
                </div>
              </div>
            );
          })}
          {/* Tip card */}
          <Card className="!p-3.5 bg-green/5 border-green/15">
            <div className="flex items-start gap-2.5 text-[12.5px]">
              <Icon name="info" size={14} className="text-green mt-0.5 shrink-0"/>
              <div className="text-ink-2 dark:text-fog-2"><span className="text-green font-medium">نصيحة:</span> اسأل عن خطط الخمس سنوات القادمة — تكشف الكثير عن التوقعات.</div>
            </div>
          </Card>
          {/* Typing */}
          <div className="flex justify-start">
            <div className="bg-paper-card dark:bg-night-2 border border-line dark:border-edge px-4 py-3 rounded-2xl rounded-br-md">
              <div className="dots text-ink-3"><span/><span/><span/></div>
            </div>
          </div>
          {/* Red flag alert */}
          <Card className="bg-amber-soft dark:bg-[#2a2010] border-[#e9d4a8] dark:border-[#5b4720] !p-3">
            <div className="flex items-start gap-2.5 text-[12.5px] text-amber dark:text-[#e4b266]">
              <Icon name="alert" size={14} className="mt-0.5 shrink-0"/>
              <div className="flex-1">يُفضّل عدم تبادل أرقام التواصل المباشرة في بداية المحادثة.</div>
              <button className="text-ink-3"><Icon name="x" size={12}/></button>
            </div>
          </Card>
        </div>

        {/* Input */}
        <div className="border-t border-line dark:border-edge bg-paper-card dark:bg-night-2 px-3 lg:px-6 py-3 flex items-center gap-2">
          <button className="p-2 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3 text-ink-2"><Icon name="plus" size={20}/></button>
          <input placeholder="اكتب رسالتك…" className="flex-1 bg-paper-2 dark:bg-night-3 rounded-full px-4 py-2.5 outline-none text-[14px]"/>
          <button className="w-10 h-10 rounded-full bg-gold text-white flex items-center justify-center shrink-0"><Icon name="send" size={18}/></button>
        </div>
      </div>
    </AppLayout>
  );
};

// ---- P30: Notifications ----
const PageNotifs = ({ go }) => {
  const items = [
    { icon: "heart",    tone: "gold",  t: "توافق جديد!", d: "نور الهدى — توافق ٨٧٪", time: "منذ ١٠ د", unread: true, go: "match-detail" },
    { icon: "inbox",    tone: "green", t: "طلب تواصل جديد", d: "مستخدم مجهول أرسل طلباً", time: "منذ ساعة", unread: true, go: "req-detail" },
    { icon: "checkCircle", tone: "green", t: "تم قبول طلبك", d: "ليلى يوسف قبلت طلبك", time: "أمس", unread: false, go: "chat-room" },
    { icon: "chat",     tone: "gold",  t: "رسالة جديدة", d: "هند: تمام، نتكلم بكرة", time: "منذ يومين", unread: false, go: "chat-room" },
    { icon: "alert",    tone: "amber", t: "تنتهي خطتك قريباً", d: "بعد ٥ أيام — جدد قبل الانقطاع", time: "أمس", unread: false, go: "settings-sub" },
    { icon: "sparkles", tone: "gold",  t: "نصيحة اليوم", d: "أكمل ٪١٠ من ملفك لزيادة فرص التوافق", time: "اليوم", unread: false },
  ];
  return (
    <AppLayout go={go} current="notifs" title="الإشعارات" headerRight={<OutlineButton size="sm">تعليم الكل كمقروء</OutlineButton>}>
      <div className="max-w-3xl space-y-2.5">
        {items.map((n,i) => {
          const tones = { gold: "bg-gold/10 text-gold", green: "bg-green/10 text-green", amber: "bg-amber-soft text-amber" };
          return (
            <Card key={i} className={`!p-4 flex items-start gap-3 cursor-pointer hover:shadow-soft ${n.unread?"bg-gold/5 dark:bg-[#1f1a10]":""}`} onClick={()=>n.go && go(n.go)}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${tones[n.tone]}`}><Icon name={n.icon} size={18}/></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium text-[14.5px]">{n.t}</span>
                  <span className="text-[11px] text-ink-3 shrink-0">{n.time}</span>
                </div>
                <div className="text-[13px] text-ink-2 dark:text-fog-2 mt-0.5 truncate">{n.d}</div>
              </div>
              {n.unread && <span className="w-2 h-2 rounded-full bg-gold mt-2 shrink-0"/>}
            </Card>
          );
        })}
      </div>
    </AppLayout>
  );
};

window.PagesMain = { AppLayout, PageDashboard, PageReport, PageMatches, PageMatchDetail, PageRequestsSent, PageRequestsReceived, PageRequestDetail, PageChats, PageChatRoom, PageNotifs };
Object.assign(window, window.PagesMain);


// ====== src/pages-subscription.jsx ======
// =============== Subscription Pages: P31-P35 ===============

// ---- P31: Pricing ----
const PagePricing = ({ go }) => {
  const [annual, setAnnual] = useState(false);
  const plans = [
    {
      id: "starter", name: "Starter", price: 49, color: "neutral",
      tagline: "ابدأ بأمان", features: ["عرض كل التوافقات", "٣ طلبات تواصل شهرياً", "محادثة آمنة أساسية", "تحديثات أسبوعية"],
    },
    {
      id: "pro", name: "Pro", price: 99, color: "gold", popular: true,
      tagline: "الأكثر اختياراً", features: ["كل ميزات Starter", "طلبات تواصل غير محدودة", "أولوية في المطابقة", "كشف الهوية أسرع", "نصائح محادثة مخصصة"],
    },
    {
      id: "premium", name: "Premium", price: 199, color: "green",
      tagline: "تجربة كاملة", features: ["كل ميزات Pro", "تعزيز الملف (Profile Boost)", "تحليلات متقدمة", "دعم أولوية ٢٤/٧", "مستشار توافق شخصي"],
    },
  ];
  const factor = annual ? 0.8 : 1; const suffix = annual ? " /شهر — يُحسب سنوياً" : " /شهر";
  return (
    <div className="min-h-screen bg-paper dark:bg-night">
      <div className="px-5 lg:px-8 py-5 flex items-center justify-between border-b border-line/60 dark:border-edge/60">
        <button onClick={()=>go("dashboard")} className="inline-flex"><Logo/></button>
        <button onClick={()=>go("dashboard")} className="text-[13px] text-ink-2 dark:text-fog-2 hover:text-gold">العودة</button>
      </div>
      <div className="max-w-6xl mx-auto px-5 lg:px-8 py-16">
        <div className="text-center mb-10">
          <div className="text-[12px] tracking-[0.3em] text-gold mb-2 uppercase">الاشتراك</div>
          <h1 className="font-display text-4xl">اختر خطتك</h1>
          <p className="text-ink-2 dark:text-fog-2 mt-3 max-w-xl mx-auto leading-loose">التحليل مجاني تماماً. الاشتراك يفتح لك القدرة على رؤية المتوافقين معك والتواصل بأمان.</p>

          <div className="inline-flex items-center gap-3 bg-paper-2 dark:bg-night-2 p-1 rounded-full mt-7 text-[13px]">
            <button onClick={()=>setAnnual(false)} className={`px-4 py-2 rounded-full transition ${!annual?"bg-paper-card dark:bg-night-3 shadow-soft":""}`}>شهري</button>
            <button onClick={()=>setAnnual(true)}  className={`px-4 py-2 rounded-full transition flex items-center gap-2 ${annual?"bg-paper-card dark:bg-night-3 shadow-soft":""}`}>سنوي <Badge tone="green">-20%</Badge></button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-5 lg:gap-6 max-w-5xl mx-auto">
          {plans.map(p => {
            const pop = p.popular;
            return (
              <Card key={p.id} className={`relative ${pop?"ring-2 ring-gold lg:scale-105":""} !p-7`}>
                {pop && <span className="absolute -top-3.5 right-7 px-3 py-1.5 rounded-full bg-gold text-white text-[11px] tracking-wider">الأكثر شعبية</span>}
                <Badge tone={p.color==="gold"?"gold":p.color==="green"?"green":"neutral"}>{p.name}</Badge>
                <div className="font-display text-2xl mt-3">{p.tagline}</div>
                <div className="mt-5 flex items-end gap-2">
                  <div className="font-serif-en text-5xl numerals">{Math.round(p.price*factor)}</div>
                  <div className="text-[13px] text-ink-2 dark:text-fog-2 pb-2">ج.م<span className="block text-[11px] text-ink-3">{suffix}</span></div>
                </div>
                <ul className="mt-6 space-y-2.5 text-[14px]">
                  {p.features.map(f => <li key={f} className="flex items-start gap-2.5"><Icon name="check" size={16} className={p.color==="gold"?"text-gold mt-0.5":p.color==="green"?"text-green mt-0.5":"text-ink-2 mt-0.5"}/> <span>{f}</span></li>)}
                </ul>
                {pop ? (
                  <GoldButton className="w-full mt-7" onClick={()=>go("payment")}>اشترك في Pro</GoldButton>
                ) : p.color === "green" ? (
                  <GreenButton className="w-full mt-7" onClick={()=>go("payment")}>اشترك في {p.name}</GreenButton>
                ) : (
                  <OutlineButton className="w-full mt-7" onClick={()=>go("payment")}>اختر {p.name}</OutlineButton>
                )}
              </Card>
            );
          })}
        </div>

        {/* Comparison table */}
        <Card className="mt-10">
          <div className="font-display text-lg mb-4">مقارنة كاملة</div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13.5px]">
              <thead>
                <tr className="text-ink-3 text-[12px]">
                  <th className="text-right py-2.5 font-normal">الميزة</th>
                  <th className="text-center py-2.5 font-normal">Starter</th>
                  <th className="text-center py-2.5 font-normal text-gold">Pro</th>
                  <th className="text-center py-2.5 font-normal text-green">Premium</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["عرض التوافقات","✓","✓","✓"],
                  ["طلبات تواصل","٣/شهر","غير محدودة","غير محدودة"],
                  ["تنبيهات اللغة المنبهة","—","✓","✓"],
                  ["كشف الهوية أسرع","—","✓","✓"],
                  ["أولوية في المطابقة","—","✓","✓"],
                  ["تعزيز الملف","—","—","✓"],
                  ["دعم أولوية","—","ساعات العمل","٢٤/٧"],
                ].map(row => (
                  <tr key={row[0]} className="border-t border-line dark:border-edge">
                    <td className="py-3 text-ink-2 dark:text-fog-2">{row[0]}</td>
                    <td className="py-3 text-center text-ink-2">{row[1]}</td>
                    <td className="py-3 text-center font-medium text-gold">{row[2]}</td>
                    <td className="py-3 text-center font-medium text-green">{row[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="text-center mt-8">
          <a onClick={()=>go("dashboard")} className="text-[14px] text-ink-2 dark:text-fog-2 hover:text-gold cursor-pointer">أريد المتابعة مجاناً للآن</a>
        </div>
      </div>
    </div>
  );
};

// ---- P32: Payment ----
const PagePayment = ({ go }) => {
  const [method, setMethod] = useState("card");
  return (
    <div className="min-h-screen bg-paper dark:bg-night">
      <div className="px-5 lg:px-8 py-5 flex items-center justify-between border-b border-line/60 dark:border-edge/60">
        <button onClick={()=>go("pricing")} className="inline-flex"><Logo/></button>
        <button onClick={()=>go("pricing")} className="text-[13px] text-ink-2 dark:text-fog-2 hover:text-gold inline-flex items-center gap-1"><Icon name="arrowRight" size={14}/> الخطط</button>
      </div>

      <div className="max-w-3xl mx-auto px-5 lg:px-8 py-10">
        <h1 className="font-display text-3xl mb-1.5">إتمام الاشتراك</h1>
        <p className="text-ink-2 dark:text-fog-2">آمن ومحمي بالكامل</p>

        <div className="grid lg:grid-cols-5 gap-6 mt-7">
          <div className="lg:col-span-3 space-y-5">
            <Card>
              <div className="font-display text-[16px] mb-3">طريقة الدفع</div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  ["card","بطاقة","creditCard"],
                  ["fawry","فوري","tag"],
                  ["vodafone","فودافون كاش","phone"],
                ].map(([id,lbl,icn]) => (
                  <button key={id} onClick={()=>setMethod(id)} className={`p-3 rounded-2xl border-2 transition text-center ${method===id?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417]":"border-line dark:border-edge"}`}>
                    <Icon name={icn} size={22} className={`mx-auto ${method===id?"text-gold":"text-ink-3"}`}/>
                    <div className="text-[12.5px] mt-1.5">{lbl}</div>
                  </button>
                ))}
              </div>
            </Card>

            {method === "card" && (
              <Card>
                <div className="font-display text-[16px] mb-3">بيانات البطاقة</div>
                <div className="space-y-3.5">
                  <TextField label="الاسم على البطاقة" placeholder="AHMED MAHMOUD"/>
                  <TextField label="رقم البطاقة" placeholder="•••• •••• •••• ٤٢٤٢" icon={<Icon name="creditCard" size={16}/>}/>
                  <div className="grid grid-cols-2 gap-3">
                    <TextField label="انتهاء" placeholder="MM/YY"/>
                    <TextField label="CVV" placeholder="•••" icon={<Icon name="lock" size={16}/>}/>
                  </div>
                </div>
              </Card>
            )}
            {method === "fawry" && (
              <Card className="text-center">
                <div className="w-24 h-24 mx-auto rounded-2xl bg-paper-2 dark:bg-night-3 flex items-center justify-center"><Icon name="qr" size={56} className="text-ink"/></div>
                <div className="font-display text-lg mt-4">كود فوري</div>
                <div className="font-serif-en text-3xl tracking-widest mt-1 text-gold numerals">٧٨٢٣ ٤٥٩١</div>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-2">صالح لمدة ٢٤ ساعة</div>
              </Card>
            )}
            {method === "vodafone" && (
              <Card>
                <TextField label="رقم فودافون كاش" placeholder="٠١٠٠ ٠٠٠ ٠٠٠٠" icon={<span className="text-[12px]">+٢٠</span>}/>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-3">سيصلك رابط دفع برسالة نصية لاستكمال العملية.</div>
              </Card>
            )}
          </div>

          <Card className="lg:col-span-2 self-start sticky top-6">
            <Badge tone="gold">الأكثر شعبية</Badge>
            <div className="font-display text-xl mt-3">خطة Pro</div>
            <div className="text-[12.5px] text-ink-2 dark:text-fog-2">شهري — يتجدد تلقائياً</div>
            <div className="mt-5 space-y-2.5 text-[13.5px]">
              <div className="flex justify-between"><span>السعر</span><span className="numerals font-medium">٩٩.٠٠ ج.م</span></div>
              <div className="flex justify-between text-ink-2 dark:text-fog-2"><span>ضريبة (١٤٪)</span><span className="numerals">١٣.٨٦ ج.م</span></div>
              <div className="flex justify-between text-green"><span>خصم ترحيبي</span><span className="numerals">- ١٠.٠٠ ج.م</span></div>
              <div className="border-t border-line dark:border-edge pt-3 mt-3 flex justify-between font-display text-lg">
                <span>الإجمالي</span><span className="text-gold numerals">١٠٢.٨٦ ج.م</span>
              </div>
            </div>
            <GoldButton className="w-full mt-5" onClick={()=>go("sub-success")}>تأكيد الاشتراك</GoldButton>
            <div className="flex items-center justify-center gap-3 mt-4 text-[11.5px] text-ink-3">
              <span className="flex items-center gap-1"><Icon name="shield" size={12}/> 256-bit SSL</span>
              <span className="flex items-center gap-1"><Icon name="lock" size={12}/> PCI DSS</span>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

// ---- P33: Subscription Success ----
const PageSubSuccess = ({ go }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex items-center justify-center px-5 py-12">
    <div className="max-w-md w-full text-center">
      <div className="relative w-28 h-28 mx-auto mb-7">
        <div className="absolute inset-0 rounded-full bg-gold/15 animate-ping"/>
        <div className="absolute inset-2 rounded-full bg-gold flex items-center justify-center text-white shadow-card"><Icon name="check" size={56} stroke={2.6}/></div>
      </div>
      <h1 className="font-display text-3xl mb-2">تم الاشتراك بنجاح 🎉</h1>
      <p className="text-ink-2 dark:text-fog-2 leading-loose">أهلاً بك في عائلة Pro. الآن تستطيع رؤية من وافقوا معك والتواصل بأمان.</p>
      <Card className="mt-7 text-right">
        <div className="flex items-center justify-between mb-2.5"><span className="text-[13px] text-ink-2 dark:text-fog-2">الخطة</span><Badge tone="gold">Pro الشهرية</Badge></div>
        <div className="flex items-center justify-between mb-2.5"><span className="text-[13px] text-ink-2 dark:text-fog-2">تنتهي في</span><span className="numerals font-medium">٢٠ يونيو ٢٠٢٦</span></div>
        <div className="flex items-center justify-between"><span className="text-[13px] text-ink-2 dark:text-fog-2">رقم العملية</span><span className="numerals font-serif-en text-[13px]">TWFQ-984231</span></div>
      </Card>
      <GoldButton className="w-full mt-7" onClick={()=>go("matches")} icon={<Icon name="arrowLeft" size={16}/>}>اكتشف توافقاتك الآن</GoldButton>
      <button onClick={()=>go("dashboard")} className="text-[13px] text-ink-2 dark:text-fog-2 mt-3 hover:text-gold">العودة للرئيسية</button>
    </div>
  </div>
);

// ---- P34: Subscription Expired ----
const PageSubExpired = ({ go }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex items-center justify-center px-5 py-12">
    <div className="max-w-md w-full text-center">
      <div className="w-24 h-24 mx-auto rounded-3xl bg-amber-soft text-amber flex items-center justify-center mb-6"><Icon name="clock" size={44}/></div>
      <h1 className="font-display text-3xl mb-2">انتهى اشتراكك</h1>
      <p className="text-ink-2 dark:text-fog-2 leading-loose">لا داعي للقلق — ملفك وتقريرك محفوظان. جدد لتعود لرؤية المتوافقين والمحادثات.</p>

      <Card className="mt-7 text-right">
        <div className="font-display text-[15px] mb-3">ما الذي ستستعيده</div>
        <ul className="space-y-2 text-[14px]">
          {["عرض جميع التوافقات","طلبات التواصل غير المحدودة","المحادثات النشطة","الأولوية في المطابقة"].map(t => (
            <li key={t} className="flex items-center gap-2.5"><Icon name="check" size={14} className="text-gold"/> {t}</li>
          ))}
        </ul>
      </Card>

      <GoldButton className="w-full mt-7" onClick={()=>go("pricing")}>جدد اشتراكك</GoldButton>
      <button onClick={()=>go("dashboard")} className="text-[13px] text-ink-2 dark:text-fog-2 mt-3 hover:text-gold">تصفح مجاناً</button>
    </div>
  </div>
);

// ---- P35: Settings — Subscription ----
const PageSettingsSubscription = ({ go }) => {
  const remaining = 18, total = 30;
  return (
    <AppLayout go={go} current="settings-sub" title="اشتراكك" sub="إدارة الخطة والفواتير">
      <div className="max-w-3xl space-y-5">
        <Card className="ring-2 ring-gold relative overflow-hidden">
          <div className="absolute -top-10 left-10 w-40 h-40 rounded-full bg-gold/10 blur-2xl"/>
          <div className="relative flex items-start gap-4 flex-wrap">
            <div className="w-12 h-12 rounded-2xl bg-gold/15 text-gold flex items-center justify-center"><Icon name="crown" size={22}/></div>
            <div className="flex-1 min-w-0">
              <Badge tone="gold">نشط</Badge>
              <div className="font-display text-xl mt-2">خطة Pro الشهرية</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2">يتم التجديد في <span className="numerals">٢٠ يونيو ٢٠٢٦</span> — <span className="numerals">٩٩ ج.م</span>/شهر</div>
              <div className="mt-3">
                <div className="flex items-center justify-between mb-1.5 text-[12.5px] text-ink-2 dark:text-fog-2">
                  <span>متبقي <span className="font-serif-en text-gold numerals">{remaining}</span> يوماً</span>
                  <span className="numerals">{total-remaining}/{total}</span>
                </div>
                <ProgressBar value={(total-remaining)/total*100}/>
              </div>
            </div>
            <GoldButton size="sm" onClick={()=>go("pricing")}>ترقية</GoldButton>
          </div>
        </Card>

        <div className="grid sm:grid-cols-3 gap-3">
          {[
            ["طلبات هذا الشهر","12 / ∞","inbox","gold"],
            ["كشف الهوية","٣","eye","green"],
            ["محادثات نشطة","٥","chat","amber"],
          ].map(([l,v,icn,tone]) => (
            <Card key={l} className="!p-4">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${tone==="gold"?"bg-gold/10 text-gold":tone==="green"?"bg-green/10 text-green":"bg-amber-soft text-amber"}`}><Icon name={icn} size={18}/></div>
              <div className="font-serif-en text-xl numerals">{v}</div>
              <div className="text-[12px] text-ink-2 dark:text-fog-2">{l}</div>
            </Card>
          ))}
        </div>

        <Card>
          <div className="flex items-center justify-between mb-3">
            <div className="font-display text-[15px]">سجل الفواتير</div>
            <button className="text-[12.5px] text-gold">تصدير</button>
          </div>
          <div className="divide-y divide-line dark:divide-edge text-[13.5px]">
            {[
              ["٢٠ مايو ٢٠٢٦","Pro الشهرية","99.00","paid"],
              ["٢٠ أبريل ٢٠٢٦","Pro الشهرية","99.00","paid"],
              ["٢٠ مارس ٢٠٢٦","Starter","49.00","paid"],
            ].map((row,i) => (
              <div key={i} className="py-3 flex items-center justify-between gap-3">
                <div className="numerals text-ink-2 dark:text-fog-2 text-[12.5px]">{row[0]}</div>
                <div className="flex-1 truncate">{row[1]}</div>
                <div className="numerals font-medium">{row[2]} ج.م</div>
                <Badge tone="green">مدفوع</Badge>
              </div>
            ))}
          </div>
        </Card>

        <button className="text-[13px] text-ink-3 hover:text-rose mx-auto block">إلغاء الاشتراك</button>
      </div>
    </AppLayout>
  );
};

window.PagesSubscription = { PagePricing, PagePayment, PageSubSuccess, PageSubExpired, PageSettingsSubscription };
Object.assign(window, window.PagesSubscription);


// ====== src/pages-settings.jsx ======
// =============== Settings Pages: P36-P41 ===============

// ---- P36: Settings Hub ----
const PageSettings = ({ go }) => {
  const groups = [
    { title: "الحساب", items: [
      { id: "settings-edit", label: "الملف الشخصي", icon: "user", to: "settings-edit" },
      { id: "settings-password", label: "كلمة المرور", icon: "lock", to: "settings-password" },
      { id: "settings-sub", label: "الاشتراك", icon: "crown", to: "settings-sub", badge: <Badge tone="gold">Pro</Badge> },
    ]},
    { title: "الخصوصية", items: [
      { id: "settings-privacy", label: "الخصوصية والظهور", icon: "shield", to: "settings-privacy" },
      { id: "settings-privacy", label: "من يمكنه رؤيتي", icon: "eye", to: "settings-privacy" },
    ]},
    { title: "التنبيهات", items: [
      { id: "settings-notifs", label: "تخصيص الإشعارات", icon: "bell", to: "settings-notifs" },
    ]},
    { title: "المساعدة", items: [
      { id: "help", label: "الدعم الفني", icon: "info" },
      { id: "about", label: "عن التطبيق", icon: "book" },
      { id: "terms", label: "الشروط والأحكام", icon: "shield" },
    ]},
    { title: "إدارة الحساب", items: [
      { id: "settings-account", label: "تعطيل/حذف الحساب", icon: "alert", to: "settings-account" },
      { id: "logout", label: "تسجيل الخروج", icon: "logout", danger: true, to: "login" },
    ]},
  ];
  return (
    <AppLayout go={go} current="settings" title="الإعدادات">
      <div className="max-w-3xl space-y-6">
        <Card className="!p-5">
          <div className="flex items-center gap-4">
            <ProfileAvatar name="أحمد محمود" size={64}/>
            <div className="flex-1 min-w-0">
              <div className="font-display text-lg">أحمد محمود</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2">ahmed.mahmoud@tawafuq.app</div>
              <div className="flex items-center gap-2 mt-1.5"><Badge tone="gold">Pro</Badge><Badge tone="green">موثّق</Badge></div>
            </div>
            <button onClick={()=>go("settings-edit")} className="p-2.5 rounded-xl border border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3"><Icon name="edit" size={16}/></button>
          </div>
        </Card>

        {groups.map(g => (
          <div key={g.title}>
            <div className="text-[11.5px] font-medium tracking-wider text-ink-3 uppercase px-2 mb-2">{g.title}</div>
            <Card padded={false} className="overflow-hidden">
              {g.items.map((it,i) => (
                <button key={i} onClick={() => it.to && go(it.to)} className="w-full text-right px-4 py-4 flex items-center gap-3 border-b last:border-0 border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3 transition">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${it.danger?"bg-rose-soft text-rose dark:bg-[#3a1f1f] dark:text-[#e89090]":"bg-paper-2 dark:bg-night-3 text-ink-2 dark:text-fog-2"}`}><Icon name={it.icon} size={18}/></div>
                  <span className={`flex-1 text-[14.5px] ${it.danger?"text-rose dark:text-[#e89090]":""}`}>{it.label}</span>
                  {it.badge}
                  <Icon name="chevronLeft" size={16} className="text-ink-3"/>
                </button>
              ))}
            </Card>
          </div>
        ))}

        <div className="text-center text-[12px] text-ink-3 numerals py-3">تَوَافُق v1.0.0 (2026.05)</div>
      </div>
    </AppLayout>
  );
};

// ---- P37: Edit Profile ----
const PageSettingsEdit = ({ go }) => (
  <AppLayout go={go} current="settings-edit" title="تعديل الملف الشخصي">
    <div className="max-w-2xl space-y-5">
      <Card>
        <div className="flex items-center gap-5">
          <div className="relative">
            <ProfileAvatar name="أحمد محمود" size={88}/>
            <button className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-gold text-white flex items-center justify-center shadow-card"><Icon name="camera" size={14}/></button>
          </div>
          <div>
            <div className="font-display text-lg">صورة الملف</div>
            <div className="text-[13px] text-ink-2 dark:text-fog-2 mt-0.5">JPG أو PNG، حتى 5MB</div>
            <button className="text-[12.5px] text-gold mt-1.5">تغيير الصورة</button>
          </div>
        </div>
      </Card>

      <Card className="space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <TextField label="الاسم" defaultValue="أحمد محمود"/>
          <TextField label="العمر" type="number" defaultValue="28"/>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <Select label="المدينة" options={sampleCities} defaultValue="القاهرة"/>
          <Select label="المؤهل" options={["ثانوي","دبلوم","بكالوريوس","ماجستير","دكتوراه"]} defaultValue="بكالوريوس"/>
        </div>
        <TextField label="المهنة" defaultValue="مهندس برمجيات"/>
        <TextArea label="نبذة" maxLength={150} defaultValue="مهندس برمجيات. أحب القراءة والسفر الهادئ. أبحث عن شريكة حياة متفاهمة."/>
      </Card>

      <div className="flex gap-3">
        <OutlineButton className="flex-1" onClick={()=>go("settings")}>إلغاء</OutlineButton>
        <GoldButton className="flex-1" onClick={()=>go("settings")}>حفظ التعديلات</GoldButton>
      </div>
    </div>
  </AppLayout>
);

// ---- P38: Password ----
const PageSettingsPassword = ({ go }) => (
  <AppLayout go={go} current="settings-password" title="كلمة المرور">
    <div className="max-w-md space-y-5">
      <Card className="space-y-4">
        <TextField label="كلمة المرور الحالية" type="password" icon={<Icon name="lock" size={16}/>}/>
        <TextField label="كلمة المرور الجديدة" type="password" icon={<Icon name="lock" size={16}/>}/>
        <TextField label="تأكيد كلمة المرور" type="password" icon={<Icon name="lock" size={16}/>}/>
      </Card>
      <Card className="bg-paper-2 dark:bg-night-3 !p-4 text-[12.5px] text-ink-2 dark:text-fog-2 space-y-1.5">
        <div className="flex items-center gap-1.5"><Icon name="check" size={12} className="text-green"/> ٨ أحرف على الأقل</div>
        <div className="flex items-center gap-1.5"><Icon name="check" size={12} className="text-green"/> حرف كبير وصغير</div>
        <div className="flex items-center gap-1.5"><Icon name="check" size={12} className="text-green"/> رقم واحد على الأقل</div>
      </Card>
      <div className="flex gap-3">
        <OutlineButton className="flex-1" onClick={()=>go("settings")}>إلغاء</OutlineButton>
        <GoldButton className="flex-1" onClick={()=>go("settings")}>حفظ</GoldButton>
      </div>
    </div>
  </AppLayout>
);

// ---- P39: Privacy ----
const PageSettingsPrivacy = ({ go }) => {
  const [anon, setAnon] = useState(true);
  const [showAge, setShowAge] = useState(true);
  const [showCity, setShowCity] = useState(true);
  const [whoSees, setWhoSees] = useState("matched");
  return (
    <AppLayout go={go} current="settings-privacy" title="الخصوصية" sub="تحكم في من يراك وكيف">
      <div className="max-w-2xl space-y-5">
        <Card>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="font-display text-[16px]">الوضع المجهول</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2 mt-1.5 leading-loose">اسمك وصورتك مخفيان حتى يتم قبول طلب التواصل بينكما. هذا الوضع مُفضّل في بداية رحلتك.</div>
            </div>
            <Toggle checked={anon} onChange={setAnon}/>
          </div>
        </Card>

        <Card>
          <div className="font-display text-[16px] mb-3">من يمكنه رؤية ملفي</div>
          <div className="space-y-2">
            {[
              ["all","الجميع","أي شخص في تَوَافُق"],
              ["matched","المتوافقون فقط","من يتجاوز توافقه ٧٠٪"],
              ["accepted","بعد قبول الطلب","الأكثر خصوصية"],
            ].map(([id,t,d]) => (
              <RadioCard key={id} checked={whoSees===id} onClick={()=>setWhoSees(id)}>
                <div className="font-medium text-[14px]">{t}</div>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-0.5">{d}</div>
              </RadioCard>
            ))}
          </div>
        </Card>

        <Card padded={false}>
          {[
            ["إظهار سني", showAge, setShowAge],
            ["إظهار مدينتي", showCity, setShowCity],
          ].map(([t, val, setVal]) => (
            <div key={t} className="px-5 py-4 flex items-center justify-between border-b last:border-0 border-line dark:border-edge">
              <div className="text-[14.5px]">{t}</div>
              <Toggle checked={val} onChange={setVal}/>
            </div>
          ))}
        </Card>

        <div className="flex justify-end gap-3">
          <GoldButton onClick={()=>go("settings")}>حفظ الإعدادات</GoldButton>
        </div>
      </div>
    </AppLayout>
  );
};

// ---- P40: Notifications ----
const PageSettingsNotifs = ({ go }) => {
  const [state, setState] = useState({
    newMatch: true, newReq: true, reqStatus: true, newMsg: true, tips: false, email: true,
  });
  const items = [
    ["newMatch","توافق جديد","تنبيه عند ظهور توافق عالٍ"],
    ["newReq","طلب تواصل جديد","عندما يطلب أحد التواصل معك"],
    ["reqStatus","تغيير حالة الطلب","قبول/اعتذار طلباتك المرسلة"],
    ["newMsg","رسالة جديدة","رسائل المحادثات النشطة"],
    ["tips","تذكيرات ونصائح","نصائح أسبوعية لتحسين ملفك"],
  ];
  return (
    <AppLayout go={go} current="settings-notifs" title="الإشعارات">
      <div className="max-w-2xl space-y-5">
        <Card padded={false}>
          {items.map(([k,t,d],i) => (
            <div key={k} className="px-5 py-4 flex items-start justify-between gap-4 border-b last:border-0 border-line dark:border-edge">
              <div className="flex-1">
                <div className="text-[14.5px]">{t}</div>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-0.5">{d}</div>
              </div>
              <Toggle checked={state[k]} onChange={v => setState(s=>({...s,[k]:v}))}/>
            </div>
          ))}
        </Card>

        <Card>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="font-medium text-[15px]">إشعارات البريد الإلكتروني</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2 mt-0.5 leading-loose">نخبرك بالأمور المهمة على بريدك أيضاً.</div>
            </div>
            <Toggle checked={state.email} onChange={v=>setState(s=>({...s, email:v}))}/>
          </div>
        </Card>

        <div className="flex justify-end">
          <GoldButton onClick={()=>go("settings")}>حفظ</GoldButton>
        </div>
      </div>
    </AppLayout>
  );
};

// ---- P41: Account (deactivate/delete) ----
const PageSettingsAccount = ({ go }) => {
  const [showConfirm, setShowConfirm] = useState(false);
  return (
    <AppLayout go={go} current="settings-account" title="إدارة الحساب">
      <div className="max-w-2xl space-y-5">
        <Card>
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-soft text-amber flex items-center justify-center shrink-0"><Icon name="pause" size={20}/></div>
            <div className="flex-1">
              <div className="font-display text-[16px]">تعطيل الحساب مؤقتاً</div>
              <p className="text-[13px] text-ink-2 dark:text-fog-2 mt-1.5 leading-loose">يخفي ملفك من جميع المستخدمين ويُوقِف ظهورك في المطابقات. يمكنك العودة في أي وقت بتسجيل الدخول.</p>
              <OutlineButton size="sm" className="mt-3">تعطيل مؤقت</OutlineButton>
            </div>
          </div>
        </Card>

        <Card className="border-rose/30">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-soft text-rose dark:bg-[#3a1f1f] dark:text-[#e89090] flex items-center justify-center shrink-0"><Icon name="trash" size={20}/></div>
            <div className="flex-1">
              <div className="font-display text-[16px] text-rose dark:text-[#e89090]">حذف الحساب نهائياً</div>
              <p className="text-[13px] text-ink-2 dark:text-fog-2 mt-1.5 leading-loose">سيتم حذف ملفك وجميع بياناتك (الاستبيان، تحليل الوجه، المحادثات) بشكل نهائي ولا يمكن استعادتها.</p>
              <button onClick={()=>setShowConfirm(true)} className="mt-3 px-4 py-2 rounded-xl border-2 border-rose text-rose dark:border-[#7a3a3a] dark:text-[#e89090] text-[13px]">حذف الحساب نهائياً</button>
            </div>
          </div>
        </Card>
      </div>

      <Modal open={showConfirm} onClose={()=>setShowConfirm(false)} title="تأكيد حذف الحساب"
        footer={<><OutlineButton onClick={()=>setShowConfirm(false)}>إلغاء</OutlineButton><button onClick={()=>{ setShowConfirm(false); go("login"); }} className="px-5 py-3 rounded-xl bg-rose text-white text-[14px]">حذف نهائياً</button></>}>
        <p className="text-[14px] leading-loose text-ink-2 dark:text-fog-2">هذا الإجراء <span className="text-rose font-medium">نهائي</span> ولا يمكن التراجع عنه. سيتم حذف:</p>
        <ul className="mt-3 space-y-1.5 text-[13.5px]">
          <li className="flex items-center gap-2"><Icon name="x" size={14} className="text-rose"/> ملفك الشخصي</li>
          <li className="flex items-center gap-2"><Icon name="x" size={14} className="text-rose"/> إجابات الاستبيان وتقريرك</li>
          <li className="flex items-center gap-2"><Icon name="x" size={14} className="text-rose"/> صور تحليل الوجه</li>
          <li className="flex items-center gap-2"><Icon name="x" size={14} className="text-rose"/> سجل المحادثات</li>
        </ul>
        <div className="mt-4"><TextField label="اكتب 'حذف' للتأكيد" placeholder="حذف"/></div>
      </Modal>
    </AppLayout>
  );
};

window.PagesSettings = { PageSettings, PageSettingsEdit, PageSettingsPassword, PageSettingsPrivacy, PageSettingsNotifs, PageSettingsAccount };
Object.assign(window, window.PagesSettings);


// ====== src/pages-admin.jsx ======
// =============== Admin Panel: P42-P63 ===============
const RC = window.Recharts || {};
const { ResponsiveContainer, LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, Tooltip, XAxis, YAxis, CartesianGrid, AreaChart, Area, Legend } = RC;

// Admin shell
const AdminShell = ({ go, current, title, sub, right, children, padded = true }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex">
    <AdminSidebar current={current} onGo={go}/>
    <main className="flex-1 min-w-0">
      <AdminTopBar title={title} sub={sub} right={right}/>
      <div className={padded ? "p-6 lg:p-8" : ""}>{children}</div>
    </main>
  </div>
);

// Empty fallback for charts when Recharts is not loaded
const ChartFallback = ({ height=160, label }) => (
  <div className="rounded-xl border border-dashed border-line dark:border-edge bg-paper-2 dark:bg-night-3 flex items-center justify-center text-[12px] text-ink-3" style={{height}}>{label||"رسم بياني"}</div>
);

// ---- P42: Admin Dashboard ----
const PageAdminDashboard = ({ go }) => {
  const stats = [
    { l: "إجمالي المستخدمين", v: "12,486", d: "+184 اليوم", tone: "gold", icon: "users" },
    { l: "جدد اليوم", v: "184", d: "+12% عن أمس", tone: "green", icon: "sparkles" },
    { l: "طلبات معلّقة", v: "37", d: "تنتظر مراجعة", tone: "amber", icon: "inbox" },
    { l: "محادثات نشطة", v: "1,243", d: "+8% أسبوعياً", tone: "blue", icon: "chat" },
    { l: "إيرادات الشهر", v: "284K", d: "ج.م — +14%", tone: "gold", icon: "coin" },
    { l: "علامات حمراء", v: "12", d: "خطورة عالية: 2", tone: "rose", icon: "flag" },
  ];
  const reg = [
    {d:"١",v:42},{d:"٥",v:58},{d:"١٠",v:71},{d:"١٥",v:65},{d:"٢٠",v:88},{d:"٢٥",v:102},{d:"٣٠",v:124},
  ];
  const sub = [{n:"Pro", v:62, c:"#B8975A"},{n:"Starter", v:24, c:"#9B9B9B"},{n:"Premium", v:14, c:"#2C5F4A"}];
  const funnel = [{n:"تسجيل", v:1000},{n:"موافقة", v:920},{n:"ملف",v:782},{n:"استبيان",v:564},{n:"تحليل وجه",v:413}];

  return (
    <AdminShell go={go} current="admin-dashboard" title="لوحة الإدارة" sub="نظرة شاملة على نشاط المنصة"
      right={<Select options={["آخر ٣٠ يوماً","الأسبوع","اليوم","السنة"]} defaultValue="آخر ٣٠ يوماً" className="!w-44"/>}>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 mb-6">
        {stats.map(s => {
          const tones = { gold:"text-gold bg-gold/10", green:"text-green bg-green/10", amber:"text-amber bg-amber-soft", rose:"text-rose bg-rose-soft", blue:"text-[#2e548a] bg-[#E8EEF5] dark:text-[#8fb1e3] dark:bg-[#1a253a]" };
          return (
            <Card key={s.l} className="!p-4">
              <div className="flex items-center justify-between mb-2"><div className={`w-9 h-9 rounded-xl flex items-center justify-center ${tones[s.tone]}`}><Icon name={s.icon} size={16}/></div></div>
              <div className="font-serif-en text-2xl numerals">{s.v}</div>
              <div className="text-[11.5px] text-ink-2 dark:text-fog-2">{s.l}</div>
              <div className="text-[11px] text-ink-3 mt-1">{s.d}</div>
            </Card>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-6">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <div><div className="font-display text-[16px]">التسجيلات (٣٠ يوم)</div><div className="text-[11.5px] text-ink-3">٢,٦٤٢ تسجيل</div></div>
            <Badge tone="green">+18%</Badge>
          </div>
          {LineChart ? (
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={reg}>
                <defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#B8975A" stopOpacity={0.5}/><stop offset="1" stopColor="#B8975A" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" strokeOpacity={0.4}/>
                <XAxis dataKey="d" stroke="#9B9B9B" fontSize={11}/>
                <YAxis stroke="#9B9B9B" fontSize={11}/>
                <Tooltip contentStyle={{fontSize:12, borderRadius:12, border:"1px solid #E8E4DC"}}/>
                <Area type="monotone" dataKey="v" stroke="#B8975A" strokeWidth={2.5} fill="url(#g1)"/>
              </AreaChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={220}/>}
        </Card>
        <Card>
          <div className="font-display text-[16px] mb-1">الاشتراكات</div>
          <div className="text-[11.5px] text-ink-3 mb-3">توزيع الخطط</div>
          {PieChart ? (
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={sub} dataKey="v" nameKey="n" innerRadius={45} outerRadius={70} paddingAngle={3}>
                  {sub.map((d,i) => <Cell key={i} fill={d.c}/>)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={180}/>}
          <div className="mt-3 space-y-1.5">
            {sub.map(s => (
              <div key={s.n} className="flex items-center justify-between text-[12.5px]">
                <span className="flex items-center gap-2"><span className="w-2 h-2 rounded-full" style={{background:s.c}}/> {s.n}</span>
                <span className="numerals">{s.v}٪</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <Card>
          <div className="font-display text-[16px] mb-3">مسار الإنجاز</div>
          {BarChart ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={funnel} layout="vertical" margin={{top:5,right:10,left:10,bottom:5}}>
                <XAxis type="number" hide/>
                <YAxis type="category" dataKey="n" stroke="#9B9B9B" fontSize={11} width={64}/>
                <Bar dataKey="v" fill="#B8975A" radius={[0,6,6,0]}/>
              </BarChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={200}/>}
        </Card>
        <Card>
          <div className="flex items-center justify-between mb-3">
            <div className="font-display text-[16px]">عاجل</div>
            <Badge tone="rose">٥ بنود</Badge>
          </div>
          <div className="space-y-3 text-[13px]">
            {[
              ["طلبات تنتظر الموافقة","٣٧","admin-requests","inbox","amber"],
              ["علامات حمراء عالية","٢","admin-flags","flag","rose"],
              ["بلاغات معلّقة","٤","admin-reports","alert","amber"],
              ["مدفوعات فاشلة","١","admin-revenue","creditCard","rose"],
            ].map(([t,n,p,icn,tone]) => (
              <button key={t} onClick={()=>go(p)} className="w-full text-right flex items-center gap-3 p-2.5 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tone==="rose"?"bg-rose-soft text-rose":"bg-amber-soft text-amber"}`}><Icon name={icn} size={14}/></div>
                <span className="flex-1">{t}</span>
                <span className="numerals font-serif-en text-gold">{n}</span>
                <Icon name="chevronLeft" size={14} className="text-ink-3"/>
              </button>
            ))}
          </div>
        </Card>
        <Card>
          <div className="font-display text-[16px] mb-3">آخر النشاط</div>
          <div className="space-y-3 text-[12.5px]">
            {[
              ["نشر مستخدم جديد ملفه","أحمد م.","منذ ٣ د"],
              ["تم الموافقة على طلب","#9821","منذ ١٠ د"],
              ["اشتراك Pro جديد","سارة ع.","منذ ٢٠ د"],
              ["محادثة معلّمة","#chat-451","منذ نصف ساعة"],
              ["بلاغ جديد","#REP-128","قبل ساعة"],
            ].map((row,i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-gold shrink-0"/>
                <div className="flex-1 truncate">{row[0]} <span className="text-ink-3">— {row[1]}</span></div>
                <div className="text-ink-3 numerals">{row[2]}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AdminShell>
  );
};

// ---- P43: Admin Users List ----
const PageAdminUsers = ({ go }) => {
  const rows = Array.from({length:10}, (_, i) => ({
    name: sampleNames[i%sampleNames.length], city: sampleCities[i%sampleCities.length],
    age: 22+(i*3)%18, completion: 60+(i*7)%41, subscribed: i%3!==2 ? (i%3===0?"Pro":"Starter") : null,
    status: i===4?"warned":i===7?"blocked":"active",
  }));
  return (
    <AdminShell go={go} current="admin-users" title="المستخدمون" sub={`${rows.length} عرض من ١٢,٤٨٦`}
      right={<OutlineButton size="sm" icon={<Icon name="download" size={14}/>}>تصدير CSV</OutlineButton>}>
      <Card className="mb-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 bg-paper-2 dark:bg-night-3 rounded-xl px-3 py-2 flex-1 min-w-[200px]">
            <Icon name="search" size={16} className="text-ink-3"/>
            <input placeholder="ابحث بالاسم أو الإيميل أو الجوال…" className="flex-1 bg-transparent outline-none text-[13.5px]"/>
          </div>
          <Select options={["جميع المدن", ...sampleCities]} defaultValue="جميع المدن" className="!w-40"/>
          <Select options={["كل الحالات","نشط","تحذير","محظور"]} defaultValue="كل الحالات" className="!w-32"/>
          <Select options={["كل الاكتمال","أقل من ٥٠٪","٥٠-٨٠٪","فوق ٨٠٪"]} defaultValue="كل الاكتمال" className="!w-36"/>
          <Select options={["الكل","مشترك","غير مشترك"]} defaultValue="الكل" className="!w-28"/>
        </div>
      </Card>

      <Card padded={false} className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[13.5px]">
            <thead className="bg-paper-2 dark:bg-night-3 text-[12px] text-ink-2 dark:text-fog-2">
              <tr>
                {["","المستخدم","المدينة","العمر","الاكتمال","الاشتراك","الحالة","إجراءات"].map(h => <th key={h} className="text-right px-4 py-3 font-normal">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {rows.map((r,i) => (
                <tr key={i} className="border-t border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3 cursor-pointer" onClick={()=>go("admin-user-detail")}>
                  <td className="px-4 py-3 w-8"><input type="checkbox"/></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <ProfileAvatar name={r.name} size={36}/>
                      <div>
                        <div className="font-medium">{r.name}</div>
                        <div className="text-[11.5px] text-ink-3">{r.name.split(" ")[0].toLowerCase()}@tawafuq.app</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-ink-2 dark:text-fog-2">{r.city}</td>
                  <td className="px-4 py-3 numerals">{r.age}</td>
                  <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="flex-1 max-w-24"><ProgressBar value={r.completion}/></div><span className="numerals text-[12px]">{r.completion}٪</span></div></td>
                  <td className="px-4 py-3">{r.subscribed ? <Badge tone="gold">{r.subscribed}</Badge> : <span className="text-ink-3 text-[12px]">مجاني</span>}</td>
                  <td className="px-4 py-3"><StatusBadge status={r.status==="active"?"active":r.status==="warned"?"warned":"blocked"}/></td>
                  <td className="px-4 py-3"><button onClick={e=>e.stopPropagation()} className="p-1.5 rounded-lg hover:bg-paper-card dark:hover:bg-night-2"><Icon name="moreH" size={14}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-line dark:border-edge text-[12px] text-ink-2 dark:text-fog-2">
          <span>عرض ١-١٠ من ١٢,٤٨٦</span>
          <div className="flex items-center gap-1">
            <button className="px-2.5 py-1.5 rounded-lg border border-line dark:border-edge">«</button>
            <button className="px-3 py-1.5 rounded-lg bg-gold text-white numerals">1</button>
            <button className="px-3 py-1.5 rounded-lg numerals hover:bg-paper-2 dark:hover:bg-night-3">2</button>
            <button className="px-3 py-1.5 rounded-lg numerals hover:bg-paper-2 dark:hover:bg-night-3">3</button>
            <button className="px-2.5 py-1.5 rounded-lg border border-line dark:border-edge">»</button>
          </div>
        </div>
      </Card>
    </AdminShell>
  );
};

// ---- P44: Admin User Detail ----
const PageAdminUserDetail = ({ go }) => {
  const [tab, setTab] = useState("profile");
  const tabs = [["profile","الملف"],["questionnaire","الاستبيان"],["face","تحليل الوجه"],["matches","التوافقات"],["sub","الاشتراك"],["logs","السجل"]];
  return (
    <AdminShell go={go} current="admin-users" title="ملف المستخدم" sub="فاطمة سالم — fatma@tawafuq.app"
      right={<><OutlineButton size="sm">تحذير</OutlineButton><button className="px-4 py-2 rounded-xl border-2 border-rose text-rose text-[13px]">حظر</button></>}>
      <div className="grid lg:grid-cols-4 gap-5 mb-5">
        <Card className="lg:col-span-1 text-center">
          <ProfileAvatar name="فاطمة سالم" size={88} className="mx-auto"/>
          <div className="font-display text-lg mt-3">فاطمة سالم</div>
          <div className="text-[12.5px] text-ink-2 dark:text-fog-2">الإسكندرية • ٢٧ سنة</div>
          <div className="mt-3 flex items-center justify-center gap-2"><Badge tone="gold">Pro</Badge><Badge tone="green">موثّقة</Badge></div>
          <div className="mt-4 grid grid-cols-2 gap-2 text-[11.5px] text-right">
            <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">انضمت</div><div className="numerals">١٢ مارس ٢٠٢٦</div></div>
            <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">آخر دخول</div><div>اليوم</div></div>
          </div>
        </Card>
        <Card className="lg:col-span-3">
          <div className="flex items-center gap-2 overflow-x-auto nice-scroll mb-5 border-b border-line dark:border-edge -m-1 p-1">
            {tabs.map(([id,lbl]) => (
              <button key={id} onClick={()=>setTab(id)} className={`shrink-0 px-4 py-2.5 -mb-px text-[13.5px] transition border-b-2 ${tab===id?"border-gold text-gold":"border-transparent text-ink-2 dark:text-fog-2"}`}>{lbl}</button>
            ))}
          </div>
          {tab==="profile" && (
            <div className="grid sm:grid-cols-2 gap-x-6 gap-y-3 text-[13.5px]">
              {[
                ["الاسم","فاطمة سالم محمد"],["البريد","fatma@tawafuq.app"],
                ["الجوال","+٢٠ ١٠٠ ٠٠٠ ٠٠٤٧"],["المدينة","الإسكندرية"],
                ["العمر","٢٧"],["النوع","أنثى"],
                ["المؤهل","ماجستير"],["المهنة","طبيبة أسنان"],
                ["الهدف","الزواج"],["الوضع المجهول","مفعّل"],
              ].map(([k,v],i) => <div key={i} className="flex justify-between py-2 border-b border-line dark:border-edge"><span className="text-ink-3">{k}</span><span className="font-medium">{v}</span></div>)}
              <div className="sm:col-span-2 pt-2">
                <div className="text-ink-3 text-[12px] mb-1.5">النبذة</div>
                <div className="text-[13.5px] leading-loose">طبيبة أسنان. أحب القراءة والسفر وأعمل تطوعياً مع الأطفال. أبحث عن شريك حياة بقيم متقاربة.</div>
              </div>
            </div>
          )}
          {tab==="questionnaire" && (
            <div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-4">اكتمل ١٠٠٪ — ٤٠ من ٤٠</div>
              <div className="space-y-3">
                {[["القيم والدين",82],["الشخصية",75],["نمط الحياة",88],["توقعات الزواج",79]].map(([n,v]) => (
                  <div key={n}><div className="flex justify-between mb-1.5 text-[13px]"><span>{n}</span><span className="text-gold numerals font-serif-en">{v}٪</span></div><ProgressBar value={v}/></div>
                ))}
              </div>
            </div>
          )}
          {tab==="face" && (
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-3">الصور</div>
                <div className="grid grid-cols-3 gap-2">
                  {[0,1,2].map(i => <div key={i} className="aspect-square rounded-xl bg-paper-2 dark:bg-night-3 flex items-center justify-center"><Icon name="image" size={24} className="text-ink-3"/></div>)}
                </div>
              </div>
              <div>
                <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-3">الصفات المستخرجة</div>
                <div className="space-y-2">
                  {[["اجتماعية ودودة",82],["هادئة متأنية",71],["عاطفية حساسة",65]].map(([n,v]) => (
                    <div key={n} className="flex items-center justify-between bg-paper-2 dark:bg-night-3 rounded-lg px-3 py-2 text-[13px]">
                      <span>{n}</span><span className="text-gold numerals font-serif-en">{v}٪</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          {tab==="matches" && (
            <div className="text-[13px] text-ink-2 dark:text-fog-2">شاهدتها مع ١٢ توافقاً عالياً (>٧٠٪). أرسلت ٤ طلبات، استلمت ٧.</div>
          )}
          {tab==="sub" && (
            <div className="text-[13px] text-ink-2 dark:text-fog-2">Pro نشط — يجدد في ١٢ يونيو ٢٠٢٦. إجمالي المدفوع: ٤٩٥ ج.م.</div>
          )}
          {tab==="logs" && (
            <div className="space-y-2 text-[13px]">
              {[["تسجيل دخول","١٤:٣٢"],["تحديث ملف","١٢:٠٥"],["إرسال طلب تواصل","الأمس"],["اشتراك Pro","الأسبوع الماضي"]].map((r,i) => (
                <div key={i} className="flex items-center justify-between bg-paper-2 dark:bg-night-3 rounded-lg px-3 py-2"><span>{r[0]}</span><span className="text-ink-3 numerals">{r[1]}</span></div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </AdminShell>
  );
};

// ---- P45: Questions list ----
const PageAdminQuestions = ({ go }) => {
  const cats = [
    { id:1, name:"القيم والدين", weight:40, qs:[
      ["دور الالتزام الديني في الحياة الزوجية","single",5,true],
      ["تربية الأبناء","single",4,true],
      ["العلاقة بالعائلة الممتدة","rating",3,true],
    ]},
    { id:2, name:"الشخصية", weight:25, qs:[
      ["كيف تتعامل مع الخلاف","single",5,true],
      ["مستوى الانبساط","rating",3,true],
      ["تنظيم الوقت","multi",2,false],
    ]},
    { id:3, name:"نمط الحياة", weight:20, qs:[["السفر والترفيه","multi",2,true],["العمل والمشاركة المنزلية","single",4,true]]},
    { id:4, name:"توقعات الزواج", weight:15, qs:[["الإنجاب","single",5,true],["الأدوار العائلية","single",4,true]]},
  ];
  const sum = cats.reduce((a,c)=>a+c.weight,0);
  return (
    <AdminShell go={go} current="admin-questions" title="الأسئلة" sub="إدارة بنك الأسئلة والأوزان"
      right={<><OutlineButton size="sm">تعطيل المعاينة</OutlineButton><GoldButton size="sm" iconLeft={<Icon name="plus" size={14}/>} onClick={()=>go("admin-question-edit")}>إضافة سؤال</GoldButton></>}>
      <Card className="mb-5">
        <div className="flex items-center justify-between mb-2">
          <div>
            <div className="font-display text-[15px]">أوزان الأقسام</div>
            <div className="text-[12px] text-ink-3 mt-0.5">يجب أن يكون المجموع <span className="font-serif-en">١٠٠</span>٪</div>
          </div>
          <Badge tone={sum===100?"green":"rose"}>المجموع: <span className="font-serif-en numerals">{sum}</span>٪</Badge>
        </div>
        <div className="grid sm:grid-cols-4 gap-3 mt-3">
          {cats.map(c => (
            <div key={c.id} className="p-3 rounded-xl border border-line dark:border-edge">
              <div className="text-[13px]">{c.name}</div>
              <div className="font-serif-en text-2xl text-gold numerals mt-1">{c.weight}<span className="text-base">٪</span></div>
            </div>
          ))}
        </div>
      </Card>

      <div className="space-y-4">
        {cats.map(c => (
          <Card key={c.id} padded={false}>
            <div className="px-5 py-4 flex items-center justify-between border-b border-line dark:border-edge">
              <div className="flex items-center gap-3">
                <Icon name="chevronDown" size={16} className="text-ink-2"/>
                <div className="font-display text-[15px]">{c.name}</div>
                <Badge tone="neutral">{c.qs.length} أسئلة</Badge>
                <Badge tone="gold">{c.weight}٪</Badge>
              </div>
              <button className="text-[12.5px] text-gold">+ سؤال</button>
            </div>
            <div className="divide-y divide-line dark:divide-edge">
              {c.qs.map(([t,type,w,active],i) => (
                <div key={i} className="px-5 py-3.5 flex items-center gap-3 hover:bg-paper-2 dark:hover:bg-night-3">
                  <button className="text-ink-3 cursor-grab"><Icon name="drag" size={16}/></button>
                  <div className="flex-1 text-[14px]">{t}</div>
                  <Badge tone={type==="single"?"gold":type==="multi"?"green":"neutral"}>{type==="single"?"اختياري":type==="multi"?"متعدد":"تقييم"}</Badge>
                  <span className="text-[12px] text-ink-3 numerals">وزن: <span className="font-serif-en text-gold">{w}</span></span>
                  <Toggle checked={active} onChange={()=>{}} size="sm"/>
                  <button onClick={()=>go("admin-question-edit")} className="p-1.5 rounded-lg hover:bg-paper-card dark:hover:bg-night-2"><Icon name="edit" size={14}/></button>
                  <button className="p-1.5 rounded-lg hover:bg-paper-card dark:hover:bg-night-2 text-rose"><Icon name="trash" size={14}/></button>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </AdminShell>
  );
};

// ---- P46: Question Edit ----
const PageAdminQuestionEdit = ({ go }) => {
  const [type, setType] = useState("single");
  return (
    <AdminShell go={go} current="admin-questions" title="تعديل سؤال" sub="القيم والدين • سؤال #٣"
      right={<><OutlineButton size="sm" onClick={()=>go("admin-questions")}>إلغاء</OutlineButton><GoldButton size="sm" onClick={()=>go("admin-questions")}>حفظ التغييرات</GoldButton></>}>
      <div className="grid lg:grid-cols-3 gap-5 max-w-6xl">
        <div className="lg:col-span-2 space-y-5">
          <Card className="space-y-4">
            <Select label="القسم" options={["القيم والدين","الشخصية","نمط الحياة","توقعات الزواج"]} defaultValue="القيم والدين"/>
            <TextArea label="نص السؤال (بالعربية)" defaultValue="إلى أي مدى يؤثر الالتزام الديني في اختيارك لشريك الحياة؟" maxLength={200}/>
            <div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-2">نوع السؤال</div>
              <div className="grid grid-cols-4 gap-2">
                {[["single","اختياري واحد","list"],["multi","متعدد","grid"],["rating","تقييم ١-٥","star"],["text","نصي","edit"]].map(([id,lbl,icn]) => (
                  <button key={id} onClick={()=>setType(id)} className={`p-3 rounded-xl border-2 transition text-center ${type===id?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417] text-gold":"border-line dark:border-edge"}`}>
                    <Icon name={icn} size={18} className="mx-auto"/>
                    <div className="text-[12px] mt-1">{lbl}</div>
                  </button>
                ))}
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-3">
              <div className="font-display text-[15px]">الخيارات</div>
              <button className="text-[12.5px] text-gold inline-flex items-center gap-1"><Icon name="plus" size={12}/> إضافة خيار</button>
            </div>
            <div className="space-y-2.5">
              {[
                ["أرى الالتزام الديني أساساً مهماً جداً", 5],
                ["مهم لكن مع مرونة في التفاصيل", 4],
                ["أؤمن بالقيم العامة دون التمسك بالتفاصيل", 3],
                ["أؤمن بالأخلاق أكثر من الطقوس", 2],
              ].map(([t,v],i) => (
                <div key={i} className="flex items-center gap-2 bg-paper-2 dark:bg-night-3 rounded-xl px-3 py-2">
                  <Icon name="drag" size={14} className="text-ink-3 cursor-grab"/>
                  <span className="font-serif-en text-ink-3 text-[12px] numerals w-5">{i+1}</span>
                  <input defaultValue={t} className="flex-1 bg-transparent outline-none text-[14px]"/>
                  <span className="text-[11px] text-ink-3">قيمة:</span>
                  <input type="number" min={1} max={10} defaultValue={v} className="w-14 bg-paper-card dark:bg-night-2 rounded-lg px-2 py-1 outline-none text-center font-serif-en numerals border border-line dark:border-edge"/>
                  <button className="text-rose p-1"><Icon name="trash" size={14}/></button>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <div className="font-display text-[15px] mb-3">الإعدادات</div>
            <div className="space-y-4">
              <div>
                <div className="text-[13px] text-ink-2 dark:text-fog-2 mb-1.5">الوزن في القسم</div>
                <input type="number" min={1} max={10} defaultValue={5} className="w-full bg-paper-2 dark:bg-night-3 rounded-xl px-3 py-2.5 outline-none border border-line dark:border-edge font-serif-en numerals"/>
              </div>
              <div className="flex items-center justify-between"><div className="text-[13px]">سؤال إجباري</div><Toggle checked={true} onChange={()=>{}}/></div>
              <div className="flex items-center justify-between"><div className="text-[13px]">نشط</div><Toggle checked={true} onChange={()=>{}}/></div>
              <div className="flex items-center justify-between"><div className="text-[13px]">يُحسب في النتيجة</div><Toggle checked={true} onChange={()=>{}}/></div>
            </div>
          </Card>
          <Card className="bg-paper-2 dark:bg-night-3">
            <div className="flex items-start gap-2 text-[12.5px] text-ink-2 dark:text-fog-2">
              <Icon name="info" size={14} className="text-gold mt-0.5"/>
              <span>التغييرات تطبَّق على المستخدمين الجدد فقط. إعادة الحساب اختيارية.</span>
            </div>
          </Card>
        </div>
      </div>
    </AdminShell>
  );
};

// ---- P47: Matching Weights ----
const PageAdminWeights = ({ go }) => {
  const [w, setW] = useState([40,25,20,15]);
  const labels = ["القيم والدين","الشخصية","نمط الحياة","المظهر والتفضيلات"];
  const colors = ["#B8975A","#2C5F4A","#A87528","#9B9B9B"];
  const sum = w.reduce((a,b)=>a+b,0);
  const [confirm, setConfirm] = useState(false);
  return (
    <AdminShell go={go} current="admin-weights" title="أوزان المطابقة" sub="تحكم في كيفية حساب نسبة التوافق"
      right={<GoldButton size="sm" onClick={()=>setConfirm(true)}>إعادة حساب كل التوافقات</GoldButton>}>
      <div className="grid lg:grid-cols-3 gap-5 max-w-6xl">
        <Card className="lg:col-span-2">
          <div className="flex items-center justify-between mb-5">
            <div className="font-display text-[16px]">الأوزان</div>
            <Badge tone={sum===100?"green":"rose"}>المجموع: <span className="font-serif-en numerals">{sum}</span>٪</Badge>
          </div>
          <div className="space-y-5">
            {labels.map((lbl, i) => (
              <div key={lbl}>
                <div className="flex items-center justify-between mb-2 text-[14px]">
                  <span className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{background:colors[i]}}/> {lbl}</span>
                  <span className="numerals font-serif-en text-xl text-gold">{w[i]}<span className="text-sm">٪</span></span>
                </div>
                <input type="range" min={0} max={100} value={w[i]} onChange={e => setW(arr => arr.map((x,idx)=>idx===i?+e.target.value:x))} className="w-full"/>
                <div className="mt-2"><Select options={["تشابه","تكامل","كلاهما"]} defaultValue={i===0?"تشابه":i===1?"كلاهما":"تشابه"} className="!text-[12px]"/></div>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div className="font-display text-[16px] mb-3">المعاينة</div>
          {PieChart ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={labels.map((n,i)=>({n,v:w[i]}))} dataKey="v" nameKey="n" innerRadius={50} outerRadius={80} paddingAngle={2}>
                  {labels.map((_,i)=><Cell key={i} fill={colors[i]}/>)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={200}/>}
          <div className="text-[11.5px] text-ink-3 mt-2 leading-loose">الأوزان تُحدد كيفية حساب نتيجة التوافق النهائية. تأكد من المجموع قبل الحفظ.</div>
        </Card>
      </div>
      <Modal open={confirm} onClose={()=>setConfirm(false)} title="إعادة حساب كل التوافقات"
        footer={<><OutlineButton onClick={()=>setConfirm(false)}>إلغاء</OutlineButton><GoldButton onClick={()=>setConfirm(false)}>تأكيد الإعادة</GoldButton></>}>
        <p className="text-[14px] leading-loose">هذه العملية ستعيد حساب نسب التوافق لجميع المستخدمين (١٢,٤٨٦). قد تستغرق ١٠-١٥ دقيقة وتستهلك موارد السيرفر.</p>
        <Card className="mt-3 bg-amber-soft dark:bg-[#2a2010] border-[#e9d4a8]/60 !p-3">
          <div className="flex items-start gap-2 text-[12.5px] text-amber dark:text-[#e4b266]">
            <Icon name="alert" size={14} className="mt-0.5"/> سيتم إرسال إشعارات تحديث لجميع المستخدمين.
          </div>
        </Card>
      </Modal>
    </AdminShell>
  );
};

// ---- P48: Trait Rules ----
const PageAdminTraits = ({ go }) => {
  const traits = [
    { name: "اجتماعي ودود", icon: "smile", features: ["انفتاح في تعابير الوجه","ابتسامة طبيعية متكررة","تناسق ملامح متوسط لعالٍ"], active: true },
    { name: "هادئ متأن", icon: "leaf", features: ["تعبير وجه ثابت","عينان متناسقتان","عدم وجود تجاعيد توتر"], active: true },
    { name: "عملي منظم", icon: "briefcase", features: ["ملامح حادة معتدلة","تماثل عالٍ بين الجانبين"], active: true },
    { name: "عاطفي حساس", icon: "heart", features: ["عينان واسعتان نسبياً","ملامح ناعمة","تعبير دافئ"], active: false },
    { name: "انطوائي تأملي", icon: "book", features: ["تعبير محايد","ملامح هادئة"], active: true },
  ];
  return (
    <AdminShell go={go} current="admin-traits" title="قواعد الصفات" sub="معايير استخراج الصفات من تحليل الوجه"
      right={<GoldButton size="sm" iconLeft={<Icon name="plus" size={14}/>}>إضافة قاعدة</GoldButton>}>
      <div className="grid md:grid-cols-2 gap-4 max-w-6xl">
        {traits.map(t => (
          <Card key={t.name}>
            <div className="flex items-start justify-between gap-3 mb-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gold/10 text-gold flex items-center justify-center"><Icon name={t.icon} size={20}/></div>
                <div>
                  <div className="font-display text-[15px]">{t.name}</div>
                  <div className="text-[11.5px] text-ink-3 numerals">{t.features.length} ميزات</div>
                </div>
              </div>
              <Toggle checked={t.active} onChange={()=>{}}/>
            </div>
            <div className="space-y-1.5">
              {t.features.map(f => (
                <div key={f} className="text-[13px] bg-paper-2 dark:bg-night-3 rounded-lg px-3 py-2 flex items-center justify-between">
                  <span className="text-ink-2 dark:text-fog-2">{f}</span>
                  <span className="numerals font-serif-en text-gold text-[11.5px]">×0.8</span>
                </div>
              ))}
            </div>
            <div className="mt-3 flex justify-end"><button className="text-[12.5px] text-gold">تعديل القاعدة</button></div>
          </Card>
        ))}
      </div>
    </AdminShell>
  );
};

// ---- P49: Requests Queue ----
const PageAdminRequests = ({ go }) => {
  const [tab, setTab] = useState("pending");
  const tabs = [["pending","معلّقة",37],["approved","موافق عليها",1284],["rejected","مرفوضة",112]];
  const reqs = Array.from({length:5}, (_, i) => ({
    a: sampleNames[i%sampleNames.length], aCity: sampleCities[i%sampleCities.length],
    b: sampleNames[(i+3)%sampleNames.length], bCity: sampleCities[(i+1)%sampleCities.length],
    score: 78 + (i*4) % 20, when: `منذ ${i+1} ساعة`, id: `REQ-${1840+i}`,
  }));
  return (
    <AdminShell go={go} current="admin-requests" title="طابور طلبات التواصل" sub="مراجعة الطلبات قبل إرسالها للمستلمين">
      <div className="flex items-center gap-2 mb-5">
        {tabs.map(([id,lbl,n]) => (
          <button key={id} onClick={()=>setTab(id)} className={`px-4 py-2 rounded-xl text-[13.5px] inline-flex items-center gap-2 ${tab===id?"bg-gold text-white":"bg-paper-card dark:bg-night-2 border border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>{lbl} <span className={`numerals text-[11px] px-1.5 py-0.5 rounded-full ${tab===id?"bg-white/20":"bg-paper-2 dark:bg-night-3"}`}>{n}</span></button>
        ))}
      </div>

      <div className="space-y-3">
        {reqs.map((r,i) => (
          <Card key={i} className="!p-4">
            <div className="flex items-center gap-3 mb-3">
              <span className="font-serif-en text-[12px] text-ink-3 numerals">#{r.id}</span>
              <span className="text-[12px] text-ink-3">•</span>
              <span className="text-[12px] text-ink-3">{r.when}</span>
              <Badge tone="amber" className="ms-auto">معلّق</Badge>
            </div>
            <div className="grid sm:grid-cols-[1fr_auto_1fr] items-center gap-4">
              <div className="flex items-center gap-3">
                <ProfileAvatar name={r.a} size={48}/>
                <div className="min-w-0">
                  <div className="font-medium truncate">{r.a}</div>
                  <div className="text-[11.5px] text-ink-3">{r.aCity} <span className="text-ink-3">— المرسل</span></div>
                </div>
              </div>
              <div className="text-center">
                <ScoreRing value={r.score} size={64} stroke={6}/>
                <div className="text-[10.5px] text-ink-3 mt-1">توافق</div>
              </div>
              <div className="flex items-center gap-3 sm:flex-row-reverse">
                <ProfileAvatar name={r.b} size={48} tone="green"/>
                <div className="min-w-0 sm:text-left">
                  <div className="font-medium truncate">{r.b}</div>
                  <div className="text-[11.5px] text-ink-3">{r.bCity} <span className="text-ink-3">— المستلم</span></div>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-4 pt-4 border-t border-line dark:border-edge">
              <button className="text-[12.5px] text-gold underline">عرض الرسالة</button>
              <div className="me-auto"/>
              <OutlineButton size="sm">رفض</OutlineButton>
              <GreenButton size="sm">موافقة وإرسال</GreenButton>
            </div>
          </Card>
        ))}
      </div>
    </AdminShell>
  );
};

// ---- P50: Flagged Chats ----
const PageAdminFlags = ({ go }) => {
  const rows = [
    { users:["كريم ح.","نور ا."], flags:3, severity:"high",  time:"منذ ١٠ د", type:"تبادل أرقام" },
    { users:["محمود ط.","سارة ع."], flags:1, severity:"medium", time:"منذ ساعة", type:"لغة غير لائقة" },
    { users:["زياد خ.","ليلى ي."],   flags:2, severity:"high", time:"اليوم", type:"ضغط للقاء" },
    { users:["يوسف ع.","هند ع."],    flags:1, severity:"low",  time:"أمس", type:"خروج عن السياق" },
    { users:["أحمد م.","فاطمة س."],   flags:1, severity:"medium", time:"الأسبوع", type:"كلمة محظورة" },
  ];
  return (
    <AdminShell go={go} current="admin-flags" title="محادثات معلّمة" sub="مرتبة حسب الخطورة">
      <Card padded={false}>
        <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-4 px-5 py-3 border-b border-line dark:border-edge bg-paper-2 dark:bg-night-3 text-[12px] text-ink-2 dark:text-fog-2">
          <div className="w-6"></div>
          <div>المشاركون</div>
          <div>النوع</div>
          <div>العلامات</div>
          <div>الخطورة</div>
          <div></div>
        </div>
        {rows.map((r,i) => {
          const sev = r.severity;
          const sevTone = sev==="high"?"rose":sev==="medium"?"amber":"neutral";
          const sevLbl = sev==="high"?"عالية":sev==="medium"?"متوسطة":"منخفضة";
          return (
            <div key={i} className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-4 px-5 py-4 items-center border-b last:border-0 border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3 cursor-pointer" onClick={()=>go("admin-chat-view")}>
              <div className="flex -space-x-2 rtl:space-x-reverse">
                <ProfileAvatar name={r.users[0]} size={32}/>
                <ProfileAvatar name={r.users[1]} size={32} tone="green"/>
              </div>
              <div>
                <div className="text-[13.5px]">{r.users.join(" ↔ ")}</div>
                <div className="text-[11px] text-ink-3 numerals">{r.time}</div>
              </div>
              <div className="text-[12.5px]"><Badge tone="neutral">{r.type}</Badge></div>
              <div className="text-[13px] numerals font-serif-en">{r.flags}</div>
              <div><Badge tone={sevTone}>{sevLbl}</Badge></div>
              <button className="text-[12.5px] text-gold">عرض</button>
            </div>
          );
        })}
      </Card>
    </AdminShell>
  );
};

// ---- P51: Admin Chat View ----
const PageAdminChatView = ({ go }) => {
  const msgs = [
    { from:"a", text:"السلام عليكم، تشرفت بك", time:"١٠:٠٢" },
    { from:"b", text:"وعليكم السلام، تشرفنا", time:"١٠:٠٣" },
    { from:"a", text:"ممكن نتبادل الواتساب نسرع التواصل؟", time:"١٠:٠٥", flag:{sev:"high", type:"تبادل أرقام", id:1} },
    { from:"b", text:"الأفضل نكمل هنا حالياً", time:"١٠:٠٦" },
    { from:"a", text:"تمام، لكن نتقابل بكرة الصبح؟", time:"١٠:٠٨", flag:{sev:"medium", type:"ضغط للقاء", id:2} },
  ];
  return (
    <AdminShell go={go} current="admin-flags" title="محادثة معلّمة" sub="كريم ح. ↔ نور ا. — للقراءة فقط"
      right={<><Badge tone="rose">٣ علامات</Badge><button className="px-4 py-2 rounded-xl border-2 border-rose text-rose text-[12.5px]">حظر المحادثة</button></>}>
      <div className="grid lg:grid-cols-3 gap-5 max-w-6xl">
        <Card className="lg:col-span-2 !p-0 overflow-hidden">
          <div className="h-[28rem] overflow-y-auto nice-scroll p-5 bg-paper-2/60 dark:bg-night-3/40 space-y-3">
            {msgs.map((m,i) => {
              const mine = m.from === "a";
              return (
                <div key={i} className={`flex ${mine?"justify-end":"justify-start"}`}>
                  <div className="max-w-[85%]">
                    <div className={`px-4 py-2.5 rounded-2xl ${m.flag ? m.flag.sev==="high" ? "bg-rose-soft dark:bg-[#3a1f1f] ring-1 ring-rose/40":"bg-amber-soft dark:bg-[#2a2010] ring-1 ring-amber/40" : mine ? "bg-gold/15 dark:bg-[#332a17]" : "bg-paper-card dark:bg-night-2 border border-line dark:border-edge"}`}>
                      <div className="text-[14px]">{m.text}</div>
                      <div className="text-[10.5px] text-ink-3 mt-1 numerals">{m.time}</div>
                    </div>
                    {m.flag && <div className="mt-1 inline-flex items-center gap-1.5 text-[10.5px]"><Icon name="flag" size={10} className="text-rose"/> <span className="text-rose">{m.flag.type}</span></div>}
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card>
          <div className="font-display text-[15px] mb-3">العلامات (٢)</div>
          <div className="space-y-3">
            {[
              ["تبادل أرقام","عالية","رسالة #٣","rose"],
              ["ضغط للقاء","متوسطة","رسالة #٥","amber"],
            ].map(([t,s,r,tone],i) => (
              <div key={i} className="rounded-xl border border-line dark:border-edge p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[13.5px] font-medium">{t}</div>
                  <Badge tone={tone}>{s}</Badge>
                </div>
                <div className="text-[11.5px] text-ink-3 mb-3">{r}</div>
                <div className="flex gap-2">
                  <button className="flex-1 text-[12px] px-2.5 py-1.5 rounded-lg bg-paper-2 dark:bg-night-3">تجاهل</button>
                  <button className="flex-1 text-[12px] px-2.5 py-1.5 rounded-lg bg-amber text-white">تحذير</button>
                  <button className="flex-1 text-[12px] px-2.5 py-1.5 rounded-lg bg-rose text-white">حظر</button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AdminShell>
  );
};

// ---- P52: Reports Queue ----
const PageAdminReports = ({ go }) => {
  const [tab, setTab] = useState("pending");
  const rows = Array.from({length:5},(_,i) => ({
    reporter: sampleNames[i%sampleNames.length],
    reported: sampleNames[(i+2)%sampleNames.length],
    reason: ["لغة غير لائقة","انتحال شخصية","ضغط للقاء","معلومات كاذبة","مضايقة"][i],
    time: ["منذ ١٠ د","منذ ساعة","اليوم","الأمس","الأسبوع"][i],
    id: `REP-${120+i}`,
  }));
  return (
    <AdminShell go={go} current="admin-reports" title="البلاغات" sub="مراجعة وفصل بلاغات المستخدمين">
      <div className="flex items-center gap-2 mb-5">
        {[["pending","معلّقة",rows.length],["review","قيد المراجعة",3],["resolved","تم الحل",148]].map(([id,lbl,n]) => (
          <button key={id} onClick={()=>setTab(id)} className={`px-4 py-2 rounded-xl text-[13.5px] inline-flex items-center gap-2 ${tab===id?"bg-gold text-white":"bg-paper-card dark:bg-night-2 border border-line dark:border-edge text-ink-2 dark:text-fog-2"}`}>{lbl} <span className={`numerals text-[11px] px-1.5 py-0.5 rounded-full ${tab===id?"bg-white/20":"bg-paper-2 dark:bg-night-3"}`}>{n}</span></button>
        ))}
      </div>

      <Card padded={false}>
        <table className="w-full text-[13.5px]">
          <thead className="bg-paper-2 dark:bg-night-3 text-[12px] text-ink-2 dark:text-fog-2">
            <tr>{["#","المُبلِّغ","المُبلَّغ عنه","السبب","الوقت",""].map(h => <th key={h} className="text-right px-4 py-3 font-normal">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r,i) => (
              <tr key={i} className="border-t border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3 cursor-pointer" onClick={()=>go("admin-report-detail")}>
                <td className="px-4 py-3 font-serif-en text-[12px] text-ink-3 numerals">{r.id}</td>
                <td className="px-4 py-3"><div className="flex items-center gap-2"><ProfileAvatar name={r.reporter} size={28}/><span>{r.reporter}</span></div></td>
                <td className="px-4 py-3"><div className="flex items-center gap-2"><ProfileAvatar name={r.reported} size={28} tone="stone"/><span>{r.reported}</span></div></td>
                <td className="px-4 py-3"><Badge tone="amber">{r.reason}</Badge></td>
                <td className="px-4 py-3 text-ink-2 dark:text-fog-2 text-[12.5px]">{r.time}</td>
                <td className="px-4 py-3"><button className="text-gold text-[12.5px]">عرض</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AdminShell>
  );
};

// ---- P53: Report Detail ----
const PageAdminReportDetail = ({ go }) => (
  <AdminShell go={go} current="admin-reports" title="تفاصيل البلاغ" sub="REP-124 — قيد المراجعة"
    right={<><OutlineButton size="sm" onClick={()=>go("admin-reports")}>العودة</OutlineButton></>}>
    <div className="grid lg:grid-cols-3 gap-5 max-w-6xl">
      <Card>
        <div className="text-[11.5px] text-ink-3 mb-2">المُبلِّغ</div>
        <ProfileAvatar name="أحمد محمود" size={56}/>
        <div className="font-display text-[15.5px] mt-2">أحمد محمود</div>
        <div className="text-[12.5px] text-ink-3">القاهرة • ٢٨ سنة</div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-center">
          <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">بلاغات سابقة</div><div className="font-serif-en numerals">٠</div></div>
          <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">منذ</div><div className="numerals">٢٠٢٤</div></div>
        </div>
      </Card>
      <Card>
        <div className="text-[11.5px] text-ink-3 mb-2">المُبلَّغ عنه</div>
        <ProfileAvatar name="زياد خالد" size={56} tone="stone"/>
        <div className="font-display text-[15.5px] mt-2">زياد خالد</div>
        <div className="text-[12.5px] text-ink-3">الجيزة • ٣٢ سنة</div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-center">
          <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">بلاغات سابقة</div><div className="font-serif-en numerals text-amber">٢</div></div>
          <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">تحذيرات</div><div className="font-serif-en numerals">١</div></div>
        </div>
      </Card>
      <Card className="lg:col-span-3">
        <div className="font-display text-[16px] mb-2">سبب البلاغ</div>
        <Badge tone="amber">لغة غير لائقة</Badge>
        <p className="mt-3 text-[14px] leading-loose">"المستخدم تجاوز في كلامه واستخدم ألفاظاً غير محترمة بعد رفض طلب التواصل."</p>
        <div className="mt-5">
          <div className="text-[12px] text-ink-3 mb-2">الرسالة المرتبطة</div>
          <div className="rounded-xl bg-rose-soft dark:bg-[#3a1f1f] p-3 text-[13.5px]">"كان لازم تردي بطريقة أحسن..."</div>
        </div>
      </Card>
      <Card className="lg:col-span-3">
        <div className="font-display text-[16px] mb-3">الإجراء</div>
        <TextArea label="ملاحظة الإدارة" placeholder="سبب القرار…" rows={3}/>
        <div className="flex flex-wrap items-center gap-2 mt-4">
          <OutlineButton size="sm">رفض البلاغ</OutlineButton>
          <button className="px-4 py-2 rounded-xl bg-amber text-white text-[13px]">إرسال تحذير</button>
          <button className="px-4 py-2 rounded-xl bg-rose text-white text-[13px]">حظر المستخدم</button>
        </div>
      </Card>
    </div>
  </AdminShell>
);

// ---- P54: Banned Words ----
const PageAdminWords = ({ go }) => {
  const rows = [
    { w: "كلمة ١", sev: "high", repl: "***", active: true },
    { w: "كلمة ٢", sev: "medium", repl: "—", active: true },
    { w: "كلمة ٣", sev: "low", repl: "تحذير", active: true },
    { w: "كلمة ٤", sev: "high", repl: "***", active: false },
    { w: "كلمة ٥", sev: "medium", repl: "—", active: true },
  ];
  return (
    <AdminShell go={go} current="admin-words" title="الكلمات المحظورة" sub="ترشيح المحتوى في المحادثات"
      right={<><OutlineButton size="sm" icon={<Icon name="upload" size={14}/>}>استيراد</OutlineButton><OutlineButton size="sm" icon={<Icon name="download" size={14}/>}>تصدير</OutlineButton></>}>
      <Card className="mb-4">
        <div className="flex items-center gap-2 bg-paper-2 dark:bg-night-3 rounded-xl px-3 py-2 mb-3">
          <Icon name="search" size={16} className="text-ink-3"/>
          <input placeholder="ابحث عن كلمة…" className="flex-1 bg-transparent outline-none text-[13.5px]"/>
        </div>
        <div className="flex items-center gap-2">
          <TextField placeholder="أضف كلمة جديدة…" className="flex-1"/>
          <Select options={["خطورة عالية","متوسطة","منخفضة"]} defaultValue="خطورة عالية" className="!w-32"/>
          <GoldButton size="sm">إضافة</GoldButton>
        </div>
      </Card>

      <Card padded={false}>
        <table className="w-full text-[13.5px]">
          <thead className="bg-paper-2 dark:bg-night-3 text-[12px] text-ink-2 dark:text-fog-2">
            <tr>{["الكلمة","الخطورة","الاستبدال","نشط",""].map(h => <th key={h} className="text-right px-4 py-3 font-normal">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r,i) => (
              <tr key={i} className="border-t border-line dark:border-edge">
                <td className="px-4 py-3 font-medium">{r.w}</td>
                <td className="px-4 py-3"><Badge tone={r.sev==="high"?"rose":r.sev==="medium"?"amber":"neutral"}>{r.sev==="high"?"عالية":r.sev==="medium"?"متوسطة":"منخفضة"}</Badge></td>
                <td className="px-4 py-3 text-ink-2 dark:text-fog-2">{r.repl}</td>
                <td className="px-4 py-3"><Toggle checked={r.active} onChange={()=>{}} size="sm"/></td>
                <td className="px-4 py-3"><button className="p-1.5 rounded-lg hover:bg-paper-2 dark:hover:bg-night-3 text-rose"><Icon name="trash" size={14}/></button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AdminShell>
  );
};

// ---- P55: Ice Breakers ----
const PageAdminIceBreakers = ({ go }) => {
  const [tab, setTab] = useState("general");
  const tabs = [["general","عام"],["values","قيم"],["personality","شخصية"],["fun","مرح"],["deep","عميق"]];
  const items = [
    ["ما هي قيمة لا تساومين عليها في حياتك؟", true],
    ["ما الكتاب الذي غيّر طريقتك في التفكير مؤخراً؟", true],
    ["كيف تتخيل يوم جمعة مثالياً؟", true],
    ["ما الصفة التي تتمنى لو يمتلكها شريك حياتك؟", false],
    ["لو رحلت للأبد لمكان واحد، أين سيكون؟", true],
  ];
  return (
    <AdminShell go={go} current="admin-icebreakers" title="محفّزات الحوار" sub="أسئلة بدء المحادثة المقترحة"
      right={<GoldButton size="sm" iconLeft={<Icon name="plus" size={14}/>}>إضافة محفّز</GoldButton>}>
      <div className="flex items-center gap-2 mb-5 overflow-x-auto">
        {tabs.map(([id,lbl]) => (
          <button key={id} onClick={()=>setTab(id)} className={`shrink-0 px-4 py-2 rounded-full text-[13px] border transition ${tab===id?"bg-gold text-white border-gold":"border-line dark:border-edge"}`}>{lbl}</button>
        ))}
      </div>
      <Card padded={false}>
        <div className="divide-y divide-line dark:divide-edge">
          {items.map(([t,active],i) => (
            <div key={i} className="px-5 py-3.5 flex items-center gap-3">
              <button className="text-ink-3 cursor-grab"><Icon name="drag" size={14}/></button>
              <div className="flex-1 text-[14px]">{t}</div>
              <Toggle checked={active} onChange={()=>{}} size="sm"/>
              <button className="p-1.5 hover:bg-paper-2 dark:hover:bg-night-3 rounded-lg"><Icon name="edit" size={14}/></button>
              <button className="p-1.5 hover:bg-paper-2 dark:hover:bg-night-3 rounded-lg text-rose"><Icon name="trash" size={14}/></button>
            </div>
          ))}
        </div>
      </Card>
      <Card className="mt-4">
        <div className="font-display text-[15px] mb-3">إضافة محفّز جديد</div>
        <TextArea label="نص المحفّز" placeholder="اكتب سؤالاً يبدأ حواراً صادقاً…" rows={3}/>
        <div className="flex justify-end mt-3"><GoldButton size="sm">إضافة</GoldButton></div>
      </Card>
    </AdminShell>
  );
};

// ---- P56: Conversation Tips ----
const PageAdminTips = ({ go }) => {
  const groups = [
    { trigger: "في بداية المحادثة", tips: ["ابدأ بسؤال يكشف القيم لا الشكليات","تجنّب تبادل الأرقام في البداية"] },
    { trigger: "عند الاختلاف", tips: ["استمع قبل أن تردّ","فرّق بين الاختلاف في الرأي والاختلاف في القيم"] },
    { trigger: "بعد ٧ أيام بدون رسالة", tips: ["تواصل بسؤال بسيط — لا تستعجل"] },
    { trigger: "قبل اللقاء الأول", tips: ["أبلغ شخصاً موثوقاً بالمكان والوقت","اختر مكاناً عاماً ومريحاً"] },
  ];
  return (
    <AdminShell go={go} current="admin-tips" title="نصائح المحادثة" sub="تظهر للمستخدمين داخل المحادثة"
      right={<GoldButton size="sm" iconLeft={<Icon name="plus" size={14}/>}>إضافة نصيحة</GoldButton>}>
      <div className="space-y-4 max-w-4xl">
        {groups.map(g => (
          <Card key={g.trigger}>
            <div className="flex items-center gap-2 mb-3">
              <Icon name="info" size={16} className="text-gold"/>
              <div className="font-display text-[14.5px]">{g.trigger}</div>
              <Badge tone="neutral">{g.tips.length} نصائح</Badge>
            </div>
            <div className="space-y-2">
              {g.tips.map((t,i) => (
                <div key={i} className="flex items-center gap-2 bg-paper-2 dark:bg-night-3 rounded-xl px-3 py-2.5">
                  <div className="flex-1 text-[13.5px]">{t}</div>
                  <button className="p-1.5 hover:bg-paper-card dark:hover:bg-night-2 rounded-lg"><Icon name="edit" size={13}/></button>
                  <button className="p-1.5 hover:bg-paper-card dark:hover:bg-night-2 rounded-lg text-rose"><Icon name="trash" size={13}/></button>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </AdminShell>
  );
};

// ---- P57: Platform Settings ----
const PageAdminSettings = ({ go }) => {
  const groups = [
    { title:"الطلبات", icon:"inbox", items:[
      ["الحد اليومي للطلبات","٥","number"],
      ["الحد الأسبوعي","٢٠","number"],
      ["مدة انتهاء الطلب (أيام)","٧","number"],
    ]},
    { title:"المحادثات", icon:"chat", items:[
      ["حد طول الرسالة","١٠٠٠ حرف","number"],
      ["حد الحظر التلقائي (علامات)","٣","number"],
      ["تنبيهات في الوقت الفعلي","مفعّل","toggle", true],
    ]},
    { title:"المطابقة", icon:"layers", items:[
      ["أقل نسبة للعرض","٦٥٪","number"],
      ["أقصى عدد توافقات/مستخدم","٥٠","number"],
      ["تحديث يومي للنتائج","مفعّل","toggle", true],
    ]},
    { title:"الأمان", icon:"shield", items:[
      ["فلتر الكلمات","مفعّل","toggle", true],
      ["فلتر الأرقام والروابط","مفعّل","toggle", true],
      ["مراجعة بشرية للطلبات","مفعّل","toggle", true],
      ["التحقق من الوجه","إجباري","toggle", true],
    ]},
  ];
  return (
    <AdminShell go={go} current="admin-settings" title="إعدادات المنصة" sub="الإعدادات العامة لتشغيل تَوَافُق">
      <div className="grid lg:grid-cols-2 gap-5 max-w-6xl">
        {groups.map(g => (
          <Card key={g.title}>
            <div className="flex items-center gap-2 mb-4 pb-4 border-b border-line dark:border-edge">
              <div className="w-10 h-10 rounded-xl bg-gold/10 text-gold flex items-center justify-center"><Icon name={g.icon} size={18}/></div>
              <div className="font-display text-[16px]">{g.title}</div>
              <button className="ms-auto text-[12.5px] text-gold">حفظ</button>
            </div>
            <div className="space-y-3">
              {g.items.map((row, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="text-[14px]">{row[0]}</div>
                  {row[2]==="toggle" ? <Toggle checked={row[3]} onChange={()=>{}}/> : <div className="font-serif-en numerals text-gold text-[15px]">{row[1]}</div>}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </AdminShell>
  );
};

// ---- P58: Statistics ----
const PageAdminStats = ({ go }) => {
  const reg = Array.from({length:12},(_,i)=>({m:`ش${i+1}`,v:120+Math.round(Math.sin(i)*60)+i*8}));
  const dist = [{n:"٦٠-٧٠٪",v:120},{n:"٧٠-٨٠٪",v:280},{n:"٨٠-٩٠٪",v:420},{n:"٩٠٪+",v:180}];
  const rev = Array.from({length:12},(_,i)=>({m:`ش${i+1}`,v:18000+Math.round(Math.cos(i)*4000)+i*1500}));
  return (
    <AdminShell go={go} current="admin-stats" title="الإحصائيات" sub="رؤى شاملة عن نشاط المنصة"
      right={<Select options={["كل الوقت","السنة","الشهر","الأسبوع","اليوم"]} defaultValue="السنة" className="!w-36"/>}>
      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        <Card className="lg:col-span-2">
          <SectionHead title="المستخدمون الجدد" sub="عبر السنة"/>
          {LineChart ? (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={reg}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" strokeOpacity={0.4}/>
                <XAxis dataKey="m" stroke="#9B9B9B" fontSize={11}/>
                <YAxis stroke="#9B9B9B" fontSize={11}/>
                <Tooltip contentStyle={{fontSize:12, borderRadius:12, border:"1px solid #E8E4DC"}}/>
                <Line type="monotone" dataKey="v" stroke="#B8975A" strokeWidth={2.5} dot={{r:3, fill:"#B8975A"}}/>
              </LineChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={220}/>}
        </Card>
        <Card>
          <SectionHead title="إكمال الاستبيان"/>
          <div className="space-y-3">
            {[["لم يبدأ",12],["جزئي",24],["مكتمل ٧٥٪",18],["مكتمل ١٠٠٪",46]].map(([n,v]) => (
              <div key={n}><div className="flex justify-between mb-1 text-[12.5px]"><span>{n}</span><span className="numerals text-gold">{v}٪</span></div><ProgressBar value={v}/></div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        <Card>
          <SectionHead title="توزيع نسب التوافق"/>
          {BarChart ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={dist}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" strokeOpacity={0.4}/>
                <XAxis dataKey="n" stroke="#9B9B9B" fontSize={11}/>
                <YAxis stroke="#9B9B9B" fontSize={11}/>
                <Bar dataKey="v" fill="#B8975A" radius={[6,6,0,0]}/>
              </BarChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={200}/>}
        </Card>
        <Card>
          <SectionHead title="معدل قبول الطلبات"/>
          <div className="flex items-center justify-center py-4"><ScoreRing value={64} size={140} stroke={10}/></div>
          <div className="text-center text-[12.5px] text-ink-2 dark:text-fog-2">٦٤٪ من الطلبات تنتهي بالقبول</div>
        </Card>
        <Card>
          <SectionHead title="أنواع العلامات الحمراء"/>
          <div className="space-y-2.5 text-[13px]">
            {[["تبادل أرقام",42,"rose"],["لغة غير لائقة",24,"amber"],["ضغط للقاء",18,"amber"],["خروج عن السياق",16,"neutral"]].map(([n,v,t]) => (
              <div key={n} className="flex items-center justify-between bg-paper-2 dark:bg-night-3 rounded-lg px-3 py-2">
                <span>{n}</span>
                <Badge tone={t}><span className="numerals">{v}</span></Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <Card className="lg:col-span-2">
          <SectionHead title="الإيرادات الشهرية" sub="ج.م"/>
          {AreaChart ? (
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={rev}>
                <defs><linearGradient id="rev" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#2C5F4A" stopOpacity={0.5}/><stop offset="1" stopColor="#2C5F4A" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" strokeOpacity={0.4}/>
                <XAxis dataKey="m" stroke="#9B9B9B" fontSize={11}/>
                <YAxis stroke="#9B9B9B" fontSize={11}/>
                <Tooltip contentStyle={{fontSize:12, borderRadius:12, border:"1px solid #E8E4DC"}}/>
                <Area type="monotone" dataKey="v" stroke="#2C5F4A" strokeWidth={2.5} fill="url(#rev)"/>
              </AreaChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={220}/>}
        </Card>
        <Card>
          <SectionHead title="السلامة"/>
          <div className="space-y-3 text-[13px]">
            {[["محادثات معلّمة",112,"amber"],["محظورة آلياً",38,"rose"],["بلاغات مفتوحة",4,"amber"],["حسابات محظورة",26,"rose"]].map(([n,v,t]) => (
              <div key={n} className="flex justify-between items-center">
                <span>{n}</span>
                <Badge tone={t}><span className="numerals font-serif-en">{v}</span></Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </AdminShell>
  );
};

// ---- P59: ML Insights ----
const PageAdminML = ({ go }) => {
  const insights = [
    { t: "زيادة وزن الشخصية إلى ٣٠٪", conf: 87, d: "تحليل ٢٠٠٠ زواج ناجح يشير إلى توافق شخصية أهم من نمط الحياة." },
    { t: "تعديل خوارزمية الكشف عن 'الهدوء'", conf: 74, d: "النتائج الحالية متحيزة قليلاً لصور الإضاءة العالية." },
    { t: "إضافة سؤال جديد لتوقعات الإنجاب", conf: 68, d: "هذه نقطة خلاف أساسية بعد القبول، يستحسن استكشافها مبكراً." },
  ];
  return (
    <AdminShell go={go} current="admin-ml" title="رؤى الذكاء الاصطناعي" sub="اقتراحات تحسين مبنية على بيانات المنصة"
      right={<Badge tone="gold">٣ معلّقة</Badge>}>
      <div className="flex items-center gap-2 mb-4">
        <button className="px-3 py-1.5 rounded-full bg-gold text-white text-[12.5px]">معلّقة (٣)</button>
        <button className="px-3 py-1.5 rounded-full border border-line dark:border-edge text-[12.5px]">مطبّقة (١٢)</button>
        <button className="px-3 py-1.5 rounded-full border border-line dark:border-edge text-[12.5px]">مرفوضة (٤)</button>
      </div>

      <div className="grid lg:grid-cols-3 gap-4 mb-5">
        {insights.map(ins => (
          <Card key={ins.t}>
            <div className="flex items-start justify-between gap-2 mb-2">
              <Icon name="sparkles" size={20} className="text-gold"/>
              <Badge tone="green">ثقة <span className="numerals">{ins.conf}</span>٪</Badge>
            </div>
            <div className="font-display text-[15px] leading-relaxed">{ins.t}</div>
            <p className="text-[13px] text-ink-2 dark:text-fog-2 mt-2.5 leading-loose">{ins.d}</p>
            <div className="flex items-center gap-2 mt-4 pt-4 border-t border-line dark:border-edge">
              <OutlineButton size="sm" className="flex-1">رفض</OutlineButton>
              <GoldButton size="sm" className="flex-1">تطبيق</GoldButton>
            </div>
          </Card>
        ))}
      </div>

      <Card>
        <SectionHead title="دقة النموذج عبر الزمن"/>
        {LineChart ? (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={Array.from({length:8},(_,i)=>({m:`ش${i+1}`,v:78+Math.round(Math.sin(i)*5)+i}))}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" strokeOpacity={0.4}/>
              <XAxis dataKey="m" stroke="#9B9B9B" fontSize={11}/>
              <YAxis stroke="#9B9B9B" fontSize={11} domain={[70, 100]}/>
              <Tooltip contentStyle={{fontSize:12, borderRadius:12, border:"1px solid #E8E4DC"}}/>
              <Line type="monotone" dataKey="v" stroke="#2C5F4A" strokeWidth={2.5} dot={{r:3, fill:"#2C5F4A"}}/>
            </LineChart>
          </ResponsiveContainer>
        ) : <ChartFallback height={220}/>}
      </Card>
    </AdminShell>
  );
};

// ---- P60: Activity Logs ----
const PageAdminLogs = ({ go }) => {
  const rows = [
    ["عمر فؤاد","موافقة على طلب","REQ-1842","١٤:٣٢","156.220.x.x"],
    ["مريم خ.","حظر مستخدم","USR-1248","١٣:١٥","156.220.x.x"],
    ["عمر فؤاد","تعديل وزن المطابقة","الشخصية ٢٥→٣٠","١٢:٤٠","156.220.x.x"],
    ["خالد ع.","إضافة كلمة محظورة","كلمة #٢٤","الأمس","156.220.x.x"],
    ["عمر فؤاد","إرسال تحذير","USR-998","الأمس","156.220.x.x"],
    ["مريم خ.","تعديل سؤال","Q-12","منذ يومين","156.220.x.x"],
  ];
  return (
    <AdminShell go={go} current="admin-logs" title="سجل النشاط" sub="عمليات الإدارة عبر النظام"
      right={<OutlineButton size="sm" icon={<Icon name="download" size={14}/>}>تصدير</OutlineButton>}>
      <Card className="mb-4">
        <div className="flex flex-wrap gap-2">
          <Select options={["كل المدراء","عمر فؤاد","مريم خ.","خالد ع."]} defaultValue="كل المدراء" className="!w-40"/>
          <Select options={["كل الأنواع","موافقة","حظر","تعديل","حذف"]} defaultValue="كل الأنواع" className="!w-32"/>
          <Select options={["آخر شهر","الأسبوع","اليوم"]} defaultValue="آخر شهر" className="!w-32"/>
        </div>
      </Card>
      <Card padded={false}>
        <table className="w-full text-[13.5px]">
          <thead className="bg-paper-2 dark:bg-night-3 text-[12px] text-ink-2 dark:text-fog-2">
            <tr>{["المدير","الإجراء","الهدف","الوقت","IP"].map(h => <th key={h} className="text-right px-4 py-3 font-normal">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r,i) => (
              <tr key={i} className="border-t border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3">
                <td className="px-4 py-3"><div className="flex items-center gap-2"><ProfileAvatar name={r[0]} size={28} tone="night"/>{r[0]}</div></td>
                <td className="px-4 py-3"><Badge tone={r[1].includes("حظر")?"rose":r[1].includes("موافقة")?"green":"neutral"}>{r[1]}</Badge></td>
                <td className="px-4 py-3 font-serif-en numerals text-[12px] text-ink-2">{r[2]}</td>
                <td className="px-4 py-3 text-ink-2 dark:text-fog-2 numerals text-[12.5px]">{r[3]}</td>
                <td className="px-4 py-3 font-serif-en numerals text-[12px] text-ink-3">{r[4]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AdminShell>
  );
};

// ---- P61: Subscription Plans ----
const PageAdminPlans = ({ go }) => {
  const plans = [
    { id:"starter", n:"Starter", p:49, color:"neutral", active:true, features:["عرض المتوافقين","٣ طلبات/شهر","محادثة آمنة"] },
    { id:"pro", n:"Pro", p:99, color:"gold", active:true, popular:true, features:["طلبات غير محدودة","أولوية المطابقة","كشف هوية أسرع"] },
    { id:"premium", n:"Premium", p:199, color:"green", active:true, features:["Profile Boost","تحليلات متقدمة","مستشار شخصي"] },
  ];
  const [edit, setEdit] = useState(null);
  return (
    <AdminShell go={go} current="admin-plans" title="خطط الاشتراك" sub="إدارة خطط Tawafuq المتاحة"
      right={<GoldButton size="sm" iconLeft={<Icon name="plus" size={14}/>}>إضافة خطة</GoldButton>}>
      <div className="grid lg:grid-cols-3 gap-5 max-w-6xl">
        {plans.map(p => (
          <Card key={p.id} className={p.popular?"ring-2 ring-gold":""}>
            <div className="flex items-center justify-between mb-3">
              <Badge tone={p.color}>{p.n}</Badge>
              <Toggle checked={p.active} onChange={()=>{}}/>
            </div>
            <div className="font-serif-en text-4xl numerals">{p.p} <span className="text-base text-ink-2">ج.م</span></div>
            <div className="text-[12px] text-ink-3">شهرياً</div>
            <ul className="mt-4 space-y-1.5 text-[13px]">
              {p.features.map(f => <li key={f} className="flex items-center gap-2"><Icon name="check" size={12} className="text-green"/> {f}</li>)}
            </ul>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center text-[11px]">
              <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">مشتركون</div><div className="font-serif-en numerals">{p.id==="pro"?842:p.id==="starter"?326:184}</div></div>
              <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">إيراد/شهر</div><div className="font-serif-en numerals">{Math.round(p.p*(p.id==="pro"?842:p.id==="starter"?326:184)/1000)}K</div></div>
              <div className="bg-paper-2 dark:bg-night-3 rounded-lg p-2"><div className="text-ink-3">معدل البقاء</div><div className="font-serif-en numerals">{p.id==="premium"?92:84}٪</div></div>
            </div>
            <button onClick={()=>setEdit(p)} className="mt-4 w-full px-4 py-2.5 rounded-xl border border-line dark:border-edge text-[13px] hover:bg-paper-2 dark:hover:bg-night-3 inline-flex items-center justify-center gap-2"><Icon name="edit" size={14}/> تعديل الخطة</button>
          </Card>
        ))}
      </div>

      <Modal open={!!edit} onClose={()=>setEdit(null)} title={`تعديل خطة ${edit?.n||""}`}
        footer={<><OutlineButton onClick={()=>setEdit(null)}>إلغاء</OutlineButton><GoldButton onClick={()=>setEdit(null)}>حفظ</GoldButton></>}>
        <div className="space-y-3">
          <TextField label="اسم الخطة" defaultValue={edit?.n}/>
          <TextField label="السعر (ج.م/شهر)" type="number" defaultValue={edit?.p}/>
          <TextArea label="الميزات (سطر لكل ميزة)" defaultValue={edit?.features?.join("\n")}/>
          <div className="flex items-center justify-between"><span className="text-[14px]">الأكثر شعبية</span><Toggle checked={edit?.popular||false} onChange={()=>{}}/></div>
          <div className="flex items-center justify-between"><span className="text-[14px]">نشطة</span><Toggle checked={edit?.active||false} onChange={()=>{}}/></div>
        </div>
      </Modal>
    </AdminShell>
  );
};

// ---- P62: Subscribers ----
const PageAdminSubs = ({ go }) => {
  const rows = Array.from({length:8},(_,i)=>({
    name: sampleNames[i%sampleNames.length], plan: ["Pro","Starter","Premium"][i%3], start:"١٢ مارس", expiry:"١٢ يونيو",
    status: i===5?"expired":"active", rev: [99,49,199][i%3],
  }));
  return (
    <AdminShell go={go} current="admin-subs" title="المشتركون" sub="١,٣٥٢ مشترك نشط"
      right={<OutlineButton size="sm" icon={<Icon name="download" size={14}/>}>تصدير</OutlineButton>}>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        {[
          ["مشتركون نشطون","1,352","users","gold"],
          ["Pro","842","crown","gold"],
          ["Premium","184","diamond","green"],
          ["إيراد متكرر شهري","138K","coin","amber"],
        ].map(([l,v,icn,tone]) => (
          <Card key={l} className="!p-4">
            <div className={`w-9 h-9 rounded-xl mb-2 flex items-center justify-center ${tone==="gold"?"bg-gold/10 text-gold":tone==="green"?"bg-green/10 text-green":"bg-amber-soft text-amber"}`}><Icon name={icn} size={16}/></div>
            <div className="font-serif-en text-2xl numerals">{v}</div>
            <div className="text-[11.5px] text-ink-2 dark:text-fog-2">{l}</div>
          </Card>
        ))}
      </div>
      <Card padded={false}>
        <table className="w-full text-[13.5px]">
          <thead className="bg-paper-2 dark:bg-night-3 text-[12px] text-ink-2 dark:text-fog-2">
            <tr>{["المستخدم","الخطة","البداية","الانتهاء","الحالة","الإيراد"].map(h => <th key={h} className="text-right px-4 py-3 font-normal">{h}</th>)}</tr>
          </thead>
          <tbody>
            {rows.map((r,i) => (
              <tr key={i} className="border-t border-line dark:border-edge hover:bg-paper-2 dark:hover:bg-night-3">
                <td className="px-4 py-3"><div className="flex items-center gap-2"><ProfileAvatar name={r.name} size={28}/>{r.name}</div></td>
                <td className="px-4 py-3"><Badge tone={r.plan==="Pro"?"gold":r.plan==="Premium"?"green":"neutral"}>{r.plan}</Badge></td>
                <td className="px-4 py-3 numerals text-ink-2 dark:text-fog-2">{r.start}</td>
                <td className="px-4 py-3 numerals text-ink-2 dark:text-fog-2">{r.expiry}</td>
                <td className="px-4 py-3"><StatusBadge status={r.status==="active"?"active":"expired"}/></td>
                <td className="px-4 py-3 font-serif-en numerals">{r.rev} ج.م</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AdminShell>
  );
};

// ---- P63: Revenue ----
const PageAdminRevenue = ({ go }) => {
  const data = Array.from({length:30},(_,i)=>({d:i+1, v:6000+Math.round(Math.sin(i/3)*1500)+i*120}));
  const dist = [{n:"Pro",v:62,c:"#B8975A"},{n:"Starter",v:24,c:"#9B9B9B"},{n:"Premium",v:14,c:"#2C5F4A"}];
  const failed = [
    ["أحمد م.","Pro","99 ج.م","Card declined","اليوم"],
    ["سارة ع.","Premium","199 ج.م","Insufficient funds","الأمس"],
  ];
  return (
    <AdminShell go={go} current="admin-revenue" title="الإيرادات" sub="مالية المنصة">
      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        <Card>
          <div className="text-[12.5px] text-ink-2 dark:text-fog-2">MRR — الإيراد الشهري المتكرر</div>
          <div className="font-serif-en text-3xl numerals mt-1.5">138,420 <span className="text-base text-ink-2">ج.م</span></div>
          <div className="text-[12px] text-green mt-1.5 inline-flex items-center gap-1"><Icon name="arrowLeft" size={12} className="rotate-45"/> +14٪ شهرياً</div>
        </Card>
        <Card>
          <div className="text-[12.5px] text-ink-2 dark:text-fog-2">ARR — الإيراد السنوي المتوقع</div>
          <div className="font-serif-en text-3xl numerals mt-1.5">1,661,040 <span className="text-base text-ink-2">ج.م</span></div>
          <div className="text-[12px] text-ink-3 mt-1.5">مبني على معدل الاحتفاظ ٨٤٪</div>
        </Card>
        <Card>
          <div className="text-[12.5px] text-ink-2 dark:text-fog-2">إيراد اليوم</div>
          <div className="font-serif-en text-3xl numerals mt-1.5">9,840 <span className="text-base text-ink-2">ج.م</span></div>
          <div className="text-[12px] text-green mt-1.5">+ ٢١ اشتراك جديد</div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        <Card className="lg:col-span-2">
          <SectionHead title="إيرادات آخر ٣٠ يوماً"/>
          {AreaChart ? (
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={data}>
                <defs><linearGradient id="rev2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#B8975A" stopOpacity={0.4}/><stop offset="1" stopColor="#B8975A" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8E4DC" strokeOpacity={0.4}/>
                <XAxis dataKey="d" stroke="#9B9B9B" fontSize={11}/>
                <YAxis stroke="#9B9B9B" fontSize={11}/>
                <Tooltip contentStyle={{fontSize:12, borderRadius:12, border:"1px solid #E8E4DC"}}/>
                <Area type="monotone" dataKey="v" stroke="#B8975A" strokeWidth={2.5} fill="url(#rev2)"/>
              </AreaChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={240}/>}
        </Card>
        <Card>
          <SectionHead title="توزيع الخطط"/>
          {PieChart ? (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={dist} dataKey="v" nameKey="n" innerRadius={50} outerRadius={80} paddingAngle={2}>
                  {dist.map((d,i)=><Cell key={i} fill={d.c}/>)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          ) : <ChartFallback height={200}/>}
        </Card>
      </div>

      <Card>
        <SectionHead title="مدفوعات فاشلة" sub="تحتاج إعادة محاولة"/>
        <table className="w-full text-[13.5px]">
          <thead className="text-[12px] text-ink-2 dark:text-fog-2">
            <tr>{["المستخدم","الخطة","المبلغ","السبب","الوقت"].map(h => <th key={h} className="text-right py-2 font-normal">{h}</th>)}</tr>
          </thead>
          <tbody>
            {failed.map((r,i) => (
              <tr key={i} className="border-t border-line dark:border-edge">
                <td className="py-3">{r[0]}</td>
                <td className="py-3"><Badge tone="gold">{r[1]}</Badge></td>
                <td className="py-3 font-serif-en numerals">{r[2]}</td>
                <td className="py-3"><Badge tone="rose">{r[3]}</Badge></td>
                <td className="py-3 text-ink-3">{r[4]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </AdminShell>
  );
};

window.PagesAdmin = {
  PageAdminDashboard, PageAdminUsers, PageAdminUserDetail, PageAdminQuestions, PageAdminQuestionEdit,
  PageAdminWeights, PageAdminTraits, PageAdminRequests, PageAdminFlags, PageAdminChatView, PageAdminReports,
  PageAdminReportDetail, PageAdminWords, PageAdminIceBreakers, PageAdminTips, PageAdminSettings,
  PageAdminStats, PageAdminML, PageAdminLogs, PageAdminPlans, PageAdminSubs, PageAdminRevenue,
};
Object.assign(window, window.PagesAdmin);


// ====== src/pages-errors.jsx ======
// =============== Error Pages: P64-P68 ===============

const ErrorShell = ({ code, title, sub, illo, actions }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex flex-col">
    <div className="px-5 lg:px-8 py-5"><Logo/></div>
    <div className="flex-1 flex items-center justify-center px-5">
      <div className="text-center max-w-md py-10">
        <div className="w-32 h-32 mx-auto mb-7 relative">{illo}</div>
        {code && <div className="font-serif-en text-6xl text-gold/30 numerals mb-2">{code}</div>}
        <h1 className="font-display text-3xl mb-3">{title}</h1>
        <p className="text-ink-2 dark:text-fog-2 leading-loose">{sub}</p>
        <div className="mt-7 flex flex-col sm:flex-row items-center justify-center gap-3">{actions}</div>
      </div>
    </div>
    <div className="px-5 lg:px-8 py-5 text-center text-[12px] text-ink-3">© ٢٠٢٦ تَوَافُق</div>
  </div>
);

// Soft illustration helpers
const FloatingShape = ({ children, className }) => <div className={`absolute ${className}`}>{children}</div>;

const Illo404 = () => (
  <div className="w-32 h-32 relative">
    <FloatingShape className="inset-0 rounded-3xl bg-gold/10 rotate-12"><span/></FloatingShape>
    <FloatingShape className="inset-3 rounded-3xl bg-gold/20 -rotate-6"><span/></FloatingShape>
    <div className="absolute inset-0 flex items-center justify-center"><Icon name="search" size={56} className="text-gold"/></div>
  </div>
);
const Illo403 = () => (
  <div className="w-32 h-32 relative">
    <div className="absolute inset-0 rounded-full bg-rose-soft dark:bg-[#3a1f1f]"/>
    <div className="absolute inset-0 flex items-center justify-center"><Icon name="lock" size={56} className="text-rose"/></div>
  </div>
);
const Illo500 = () => (
  <div className="w-32 h-32 relative">
    <div className="absolute inset-0 rounded-3xl bg-amber-soft dark:bg-[#2a2010]"/>
    <div className="absolute inset-0 flex items-center justify-center"><Icon name="alert" size={60} className="text-amber"/></div>
  </div>
);
const IlloSession = () => (
  <div className="w-32 h-32 relative">
    <div className="absolute inset-0 rounded-full bg-paper-2 dark:bg-night-3"/>
    <div className="absolute inset-0 flex items-center justify-center"><Icon name="clock" size={56} className="text-ink-2"/></div>
  </div>
);
const IlloMaint = () => (
  <div className="w-32 h-32 relative">
    <div className="absolute inset-0 rounded-3xl bg-gold/10"/>
    <div className="absolute inset-0 flex items-center justify-center"><Icon name="settings" size={56} className="text-gold animate-[spin_4s_linear_infinite]"/></div>
  </div>
);

// ---- P64: 404 ----
const Page404 = ({ go }) => (
  <ErrorShell code="404" title="الصفحة غير موجودة"
    sub="لا تقلق — قد تكون الصفحة قد نُقلت أو لم تعد متوفرة. لنعدك للطريق الصحيح."
    illo={<Illo404/>}
    actions={<><GoldButton onClick={()=>go("landing")} iconLeft={<Icon name="home" size={16}/>}>الصفحة الرئيسية</GoldButton><OutlineButton onClick={()=>go("dashboard")}>لوحة التحكم</OutlineButton></>}
  />
);

// ---- P65: 403 ----
const Page403 = ({ go }) => (
  <ErrorShell code="403" title="غير مصرّح لك بالدخول"
    sub="هذا المحتوى متاح فقط لمستخدمين محددين. إن كنت تظن أنه خطأ، تواصل معنا."
    illo={<Illo403/>}
    actions={<><OutlineButton onClick={()=>go("dashboard")} iconLeft={<Icon name="arrowRight" size={16}/>}>العودة</OutlineButton><GoldButton onClick={()=>go("landing")}>الصفحة الرئيسية</GoldButton></>}
  />
);

// ---- P66: 500 ----
const Page500 = ({ go }) => (
  <ErrorShell code="500" title="حصل خطأ — نعمل على الإصلاح"
    sub="هذا من جانبنا. سجلنا الحدث وفريقنا يعمل عليه. حاول مجدداً بعد لحظات."
    illo={<Illo500/>}
    actions={<><GoldButton iconLeft={<Icon name="refresh" size={16}/>}>إعادة المحاولة</GoldButton><OutlineButton onClick={()=>go("landing")}>الرئيسية</OutlineButton></>}
  />
);

// ---- P67: Session Expired ----
const PageSessionExpired = ({ go }) => (
  <ErrorShell title="انتهت جلستك"
    sub="حفاظاً على أمان حسابك سجّلنا خروجك تلقائياً بعد فترة من عدم النشاط. أهلاً بعودتك."
    illo={<IlloSession/>}
    actions={<GoldButton onClick={()=>go("login")} iconLeft={<Icon name="logout" size={16} className="rotate-180"/>}>تسجيل الدخول</GoldButton>}
  />
);

// ---- P68: Maintenance ----
const PageMaintenance = ({ go }) => (
  <ErrorShell title="نحن نتحسّن لأجلك"
    sub="الموقع تحت الصيانة لتحديث سريع. نتوقع عودتنا خلال أقل من ساعة. شكراً لصبرك."
    illo={<IlloMaint/>}
    actions={<>
      <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-paper-2 dark:bg-night-3 text-[13px]">
        <Icon name="clock" size={14} className="text-gold"/>
        <span>العودة المتوقعة: <span className="numerals font-serif-en">١٤:٣٠</span></span>
      </div>
    </>}
  />
);

window.PagesErrors = { Page404, Page403, Page500, PageSessionExpired, PageMaintenance };
Object.assign(window, window.PagesErrors);


// ====== src/app.jsx ======
// =============== App Router ===============

const PAGE_REGISTRY = {
  // Public
  landing: PageLanding, register: PageRegister, login: PageLogin, otp: PageOTP, forgot: PageForgot, reset: PageReset,
  // Onboarding
  consent: PageConsent, "profile-setup": PageProfileSetup,
  "q-overview": PageQuestionnaireOverview, "q-question": PageQuestion, "q-category-done": PageCategoryDone, "q-all-done": PageQuestionnaireDone,
  "face-intro": PageFaceIntro, "face-liveness": PageLiveness, "face-capture": PagePhotoCapture, "face-processing": PageFaceProcessing, "face-traits": PageTraits,
  "self-physical": PageSelfPhysical, "self-prefs": PageSelfPrefs, "onboard-done": PageOnboardDone,
  // Main
  dashboard: PageDashboard, report: PageReport, matches: PageMatches, "match-detail": PageMatchDetail,
  "req-sent": PageRequestsSent, "req-received": PageRequestsReceived, "req-detail": PageRequestDetail,
  chats: PageChats, "chat-room": PageChatRoom, notifs: PageNotifs,
  // Subscription
  pricing: PagePricing, payment: PagePayment, "sub-success": PageSubSuccess, "sub-expired": PageSubExpired, "settings-sub": PageSettingsSubscription,
  // Settings
  settings: PageSettings, "settings-edit": PageSettingsEdit, "settings-password": PageSettingsPassword,
  "settings-privacy": PageSettingsPrivacy, "settings-notifs": PageSettingsNotifs, "settings-account": PageSettingsAccount,
  // Admin
  "admin-dashboard": PageAdminDashboard, "admin-users": PageAdminUsers, "admin-user-detail": PageAdminUserDetail,
  "admin-questions": PageAdminQuestions, "admin-question-edit": PageAdminQuestionEdit,
  "admin-weights": PageAdminWeights, "admin-traits": PageAdminTraits,
  "admin-requests": PageAdminRequests, "admin-flags": PageAdminFlags, "admin-chat-view": PageAdminChatView,
  "admin-reports": PageAdminReports, "admin-report-detail": PageAdminReportDetail,
  "admin-words": PageAdminWords, "admin-icebreakers": PageAdminIceBreakers, "admin-tips": PageAdminTips,
  "admin-settings": PageAdminSettings, "admin-stats": PageAdminStats, "admin-ml": PageAdminML, "admin-logs": PageAdminLogs,
  "admin-plans": PageAdminPlans, "admin-subs": PageAdminSubs, "admin-revenue": PageAdminRevenue,
  // Errors
  "404": Page404, "403": Page403, "500": Page500, session: PageSessionExpired, maintenance: PageMaintenance,
};

function App() {
  const [page, setPage] = useState(() => {
    try {
      const hash = window.location.hash.replace("#","");
      return hash && PAGE_REGISTRY[hash] ? hash : "landing";
    } catch { return "landing"; }
  });
  const [dark, setDark] = useState(() => {
    try { return localStorage.getItem("tw-dark") === "1"; } catch { return false; }
  });
  const [userType, setUserType] = useState(() => {
    try { return localStorage.getItem("tw-utype") || "guest"; } catch { return "guest"; }
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try { localStorage.setItem("tw-dark", dark?"1":"0"); } catch {}
  }, [dark]);

  useEffect(() => {
    try { localStorage.setItem("tw-utype", userType); } catch {}
  }, [userType]);

  useEffect(() => {
    try {
      window.location.hash = page;
      window.scrollTo({top:0, behavior:"instant"});
    } catch {}
  }, [page]);

  // Listen to hash changes (back button)
  useEffect(() => {
    const onHash = () => {
      const h = window.location.hash.replace("#","");
      if (h && PAGE_REGISTRY[h] && h !== page) setPage(h);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [page]);

  const go = useCallback((id) => {
    if (PAGE_REGISTRY[id]) setPage(id);
    else { console.warn("Unknown page:", id); setPage("404"); }
  }, []);

  const subscribed = userType === "subscribed" || userType === "admin";

  const Cmp = PAGE_REGISTRY[page] || PageLanding;
  return (
    <div className="min-h-screen bg-paper dark:bg-night text-ink dark:text-fog font-body">
      <div key={page} className="page-enter">
        <Cmp go={go} subscribed={subscribed} userType={userType} setUserType={setUserType}/>
      </div>
      <PageNavigator
        current={page}
        onGo={go}
        dark={dark}
        onToggleDark={() => setDark(d=>!d)}
        userType={userType}
        onToggleUserType={setUserType}
      />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);

