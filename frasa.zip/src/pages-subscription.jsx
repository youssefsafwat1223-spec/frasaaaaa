// =============== Subscription Pages: P31-P35 ===============

// ---- P31: Pricing ----
const PagePricing = ({ go }) => {
  const [annual, setAnnual] = useState(false);
  const plans = [
    {
      id: "starter", name: "Starter", price: 49, color: "neutral",
      tagline: "ابدأ بأمان", features: ["عرض كل التوافقات", "٣ طلبات تواصل شهرياً", "محادثة آمنة أساسية", "تحديثات أسبوعية"],
    },
    {
      id: "pro", name: "Pro", price: 99, color: "gold", popular: true,
      tagline: "الأكثر اختياراً", features: ["كل ميزات Starter", "طلبات تواصل غير محدودة", "أولوية في المطابقة", "كشف الهوية أسرع", "نصائح محادثة مخصصة"],
    },
    {
      id: "premium", name: "Premium", price: 199, color: "green",
      tagline: "تجربة كاملة", features: ["كل ميزات Pro", "تعزيز الملف (Profile Boost)", "تحليلات متقدمة", "دعم أولوية ٢٤/٧", "مستشار توافق شخصي"],
    },
  ];
  const factor = annual ? 0.8 : 1; const suffix = annual ? " /شهر — يُحسب سنوياً" : " /شهر";
  return (
    <div className="min-h-screen bg-paper dark:bg-night">
      <div className="px-5 lg:px-8 py-5 flex items-center justify-between border-b border-line/60 dark:border-edge/60">
        <button onClick={()=>go("dashboard")} className="inline-flex"><Logo/></button>
        <button onClick={()=>go("dashboard")} className="text-[13px] text-ink-2 dark:text-fog-2 hover:text-gold">العودة</button>
      </div>
      <div className="max-w-6xl mx-auto px-5 lg:px-8 py-16">
        <div className="text-center mb-10">
          <div className="text-[12px] tracking-[0.3em] text-gold mb-2 uppercase">الاشتراك</div>
          <h1 className="font-display text-4xl">اختر خطتك</h1>
          <p className="text-ink-2 dark:text-fog-2 mt-3 max-w-xl mx-auto leading-loose">التحليل مجاني تماماً. الاشتراك يفتح لك القدرة على رؤية المتوافقين معك والتواصل بأمان.</p>

          <div className="inline-flex items-center gap-3 bg-paper-2 dark:bg-night-2 p-1 rounded-full mt-7 text-[13px]">
            <button onClick={()=>setAnnual(false)} className={`px-4 py-2 rounded-full transition ${!annual?"bg-paper-card dark:bg-night-3 shadow-soft":""}`}>شهري</button>
            <button onClick={()=>setAnnual(true)}  className={`px-4 py-2 rounded-full transition flex items-center gap-2 ${annual?"bg-paper-card dark:bg-night-3 shadow-soft":""}`}>سنوي <Badge tone="green">-20%</Badge></button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-5 lg:gap-6 max-w-5xl mx-auto">
          {plans.map(p => {
            const pop = p.popular;
            return (
              <Card key={p.id} className={`relative ${pop?"ring-2 ring-gold lg:scale-105":""} !p-7`}>
                {pop && <span className="absolute -top-3.5 right-7 px-3 py-1.5 rounded-full bg-gold text-white text-[11px] tracking-wider">الأكثر شعبية</span>}
                <Badge tone={p.color==="gold"?"gold":p.color==="green"?"green":"neutral"}>{p.name}</Badge>
                <div className="font-display text-2xl mt-3">{p.tagline}</div>
                <div className="mt-5 flex items-end gap-2">
                  <div className="font-serif-en text-5xl numerals">{Math.round(p.price*factor)}</div>
                  <div className="text-[13px] text-ink-2 dark:text-fog-2 pb-2">ج.م<span className="block text-[11px] text-ink-3">{suffix}</span></div>
                </div>
                <ul className="mt-6 space-y-2.5 text-[14px]">
                  {p.features.map(f => <li key={f} className="flex items-start gap-2.5"><Icon name="check" size={16} className={p.color==="gold"?"text-gold mt-0.5":p.color==="green"?"text-green mt-0.5":"text-ink-2 mt-0.5"}/> <span>{f}</span></li>)}
                </ul>
                {pop ? (
                  <GoldButton className="w-full mt-7" onClick={()=>go("payment")}>اشترك في Pro</GoldButton>
                ) : p.color === "green" ? (
                  <GreenButton className="w-full mt-7" onClick={()=>go("payment")}>اشترك في {p.name}</GreenButton>
                ) : (
                  <OutlineButton className="w-full mt-7" onClick={()=>go("payment")}>اختر {p.name}</OutlineButton>
                )}
              </Card>
            );
          })}
        </div>

        {/* Comparison table */}
        <Card className="mt-10">
          <div className="font-display text-lg mb-4">مقارنة كاملة</div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13.5px]">
              <thead>
                <tr className="text-ink-3 text-[12px]">
                  <th className="text-right py-2.5 font-normal">الميزة</th>
                  <th className="text-center py-2.5 font-normal">Starter</th>
                  <th className="text-center py-2.5 font-normal text-gold">Pro</th>
                  <th className="text-center py-2.5 font-normal text-green">Premium</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["عرض التوافقات","✓","✓","✓"],
                  ["طلبات تواصل","٣/شهر","غير محدودة","غير محدودة"],
                  ["تنبيهات اللغة المنبهة","—","✓","✓"],
                  ["كشف الهوية أسرع","—","✓","✓"],
                  ["أولوية في المطابقة","—","✓","✓"],
                  ["تعزيز الملف","—","—","✓"],
                  ["دعم أولوية","—","ساعات العمل","٢٤/٧"],
                ].map(row => (
                  <tr key={row[0]} className="border-t border-line dark:border-edge">
                    <td className="py-3 text-ink-2 dark:text-fog-2">{row[0]}</td>
                    <td className="py-3 text-center text-ink-2">{row[1]}</td>
                    <td className="py-3 text-center font-medium text-gold">{row[2]}</td>
                    <td className="py-3 text-center font-medium text-green">{row[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <div className="text-center mt-8">
          <a onClick={()=>go("dashboard")} className="text-[14px] text-ink-2 dark:text-fog-2 hover:text-gold cursor-pointer">أريد المتابعة مجاناً للآن</a>
        </div>
      </div>
    </div>
  );
};

// ---- P32: Payment ----
const PagePayment = ({ go }) => {
  const [method, setMethod] = useState("card");
  return (
    <div className="min-h-screen bg-paper dark:bg-night">
      <div className="px-5 lg:px-8 py-5 flex items-center justify-between border-b border-line/60 dark:border-edge/60">
        <button onClick={()=>go("pricing")} className="inline-flex"><Logo/></button>
        <button onClick={()=>go("pricing")} className="text-[13px] text-ink-2 dark:text-fog-2 hover:text-gold inline-flex items-center gap-1"><Icon name="arrowRight" size={14}/> الخطط</button>
      </div>

      <div className="max-w-3xl mx-auto px-5 lg:px-8 py-10">
        <h1 className="font-display text-3xl mb-1.5">إتمام الاشتراك</h1>
        <p className="text-ink-2 dark:text-fog-2">آمن ومحمي بالكامل</p>

        <div className="grid lg:grid-cols-5 gap-6 mt-7">
          <div className="lg:col-span-3 space-y-5">
            <Card>
              <div className="font-display text-[16px] mb-3">طريقة الدفع</div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  ["card","بطاقة","creditCard"],
                  ["fawry","فوري","tag"],
                  ["vodafone","فودافون كاش","phone"],
                ].map(([id,lbl,icn]) => (
                  <button key={id} onClick={()=>setMethod(id)} className={`p-3 rounded-2xl border-2 transition text-center ${method===id?"border-gold bg-[#FBF6E9] dark:bg-[#2a2417]":"border-line dark:border-edge"}`}>
                    <Icon name={icn} size={22} className={`mx-auto ${method===id?"text-gold":"text-ink-3"}`}/>
                    <div className="text-[12.5px] mt-1.5">{lbl}</div>
                  </button>
                ))}
              </div>
            </Card>

            {method === "card" && (
              <Card>
                <div className="font-display text-[16px] mb-3">بيانات البطاقة</div>
                <div className="space-y-3.5">
                  <TextField label="الاسم على البطاقة" placeholder="AHMED MAHMOUD"/>
                  <TextField label="رقم البطاقة" placeholder="•••• •••• •••• ٤٢٤٢" icon={<Icon name="creditCard" size={16}/>}/>
                  <div className="grid grid-cols-2 gap-3">
                    <TextField label="انتهاء" placeholder="MM/YY"/>
                    <TextField label="CVV" placeholder="•••" icon={<Icon name="lock" size={16}/>}/>
                  </div>
                </div>
              </Card>
            )}
            {method === "fawry" && (
              <Card className="text-center">
                <div className="w-24 h-24 mx-auto rounded-2xl bg-paper-2 dark:bg-night-3 flex items-center justify-center"><Icon name="qr" size={56} className="text-ink"/></div>
                <div className="font-display text-lg mt-4">كود فوري</div>
                <div className="font-serif-en text-3xl tracking-widest mt-1 text-gold numerals">٧٨٢٣ ٤٥٩١</div>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-2">صالح لمدة ٢٤ ساعة</div>
              </Card>
            )}
            {method === "vodafone" && (
              <Card>
                <TextField label="رقم فودافون كاش" placeholder="٠١٠٠ ٠٠٠ ٠٠٠٠" icon={<span className="text-[12px]">+٢٠</span>}/>
                <div className="text-[12.5px] text-ink-2 dark:text-fog-2 mt-3">سيصلك رابط دفع برسالة نصية لاستكمال العملية.</div>
              </Card>
            )}
          </div>

          <Card className="lg:col-span-2 self-start sticky top-6">
            <Badge tone="gold">الأكثر شعبية</Badge>
            <div className="font-display text-xl mt-3">خطة Pro</div>
            <div className="text-[12.5px] text-ink-2 dark:text-fog-2">شهري — يتجدد تلقائياً</div>
            <div className="mt-5 space-y-2.5 text-[13.5px]">
              <div className="flex justify-between"><span>السعر</span><span className="numerals font-medium">٩٩.٠٠ ج.م</span></div>
              <div className="flex justify-between text-ink-2 dark:text-fog-2"><span>ضريبة (١٤٪)</span><span className="numerals">١٣.٨٦ ج.م</span></div>
              <div className="flex justify-between text-green"><span>خصم ترحيبي</span><span className="numerals">- ١٠.٠٠ ج.م</span></div>
              <div className="border-t border-line dark:border-edge pt-3 mt-3 flex justify-between font-display text-lg">
                <span>الإجمالي</span><span className="text-gold numerals">١٠٢.٨٦ ج.م</span>
              </div>
            </div>
            <GoldButton className="w-full mt-5" onClick={()=>go("sub-success")}>تأكيد الاشتراك</GoldButton>
            <div className="flex items-center justify-center gap-3 mt-4 text-[11.5px] text-ink-3">
              <span className="flex items-center gap-1"><Icon name="shield" size={12}/> 256-bit SSL</span>
              <span className="flex items-center gap-1"><Icon name="lock" size={12}/> PCI DSS</span>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

// ---- P33: Subscription Success ----
const PageSubSuccess = ({ go }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex items-center justify-center px-5 py-12">
    <div className="max-w-md w-full text-center">
      <div className="relative w-28 h-28 mx-auto mb-7">
        <div className="absolute inset-0 rounded-full bg-gold/15 animate-ping"/>
        <div className="absolute inset-2 rounded-full bg-gold flex items-center justify-center text-white shadow-card"><Icon name="check" size={56} stroke={2.6}/></div>
      </div>
      <h1 className="font-display text-3xl mb-2">تم الاشتراك بنجاح 🎉</h1>
      <p className="text-ink-2 dark:text-fog-2 leading-loose">أهلاً بك في عائلة Pro. الآن تستطيع رؤية من وافقوا معك والتواصل بأمان.</p>
      <Card className="mt-7 text-right">
        <div className="flex items-center justify-between mb-2.5"><span className="text-[13px] text-ink-2 dark:text-fog-2">الخطة</span><Badge tone="gold">Pro الشهرية</Badge></div>
        <div className="flex items-center justify-between mb-2.5"><span className="text-[13px] text-ink-2 dark:text-fog-2">تنتهي في</span><span className="numerals font-medium">٢٠ يونيو ٢٠٢٦</span></div>
        <div className="flex items-center justify-between"><span className="text-[13px] text-ink-2 dark:text-fog-2">رقم العملية</span><span className="numerals font-serif-en text-[13px]">TWFQ-984231</span></div>
      </Card>
      <GoldButton className="w-full mt-7" onClick={()=>go("matches")} icon={<Icon name="arrowLeft" size={16}/>}>اكتشف توافقاتك الآن</GoldButton>
      <button onClick={()=>go("dashboard")} className="text-[13px] text-ink-2 dark:text-fog-2 mt-3 hover:text-gold">العودة للرئيسية</button>
    </div>
  </div>
);

// ---- P34: Subscription Expired ----
const PageSubExpired = ({ go }) => (
  <div className="min-h-screen bg-paper dark:bg-night flex items-center justify-center px-5 py-12">
    <div className="max-w-md w-full text-center">
      <div className="w-24 h-24 mx-auto rounded-3xl bg-amber-soft text-amber flex items-center justify-center mb-6"><Icon name="clock" size={44}/></div>
      <h1 className="font-display text-3xl mb-2">انتهى اشتراكك</h1>
      <p className="text-ink-2 dark:text-fog-2 leading-loose">لا داعي للقلق — ملفك وتقريرك محفوظان. جدد لتعود لرؤية المتوافقين والمحادثات.</p>

      <Card className="mt-7 text-right">
        <div className="font-display text-[15px] mb-3">ما الذي ستستعيده</div>
        <ul className="space-y-2 text-[14px]">
          {["عرض جميع التوافقات","طلبات التواصل غير المحدودة","المحادثات النشطة","الأولوية في المطابقة"].map(t => (
            <li key={t} className="flex items-center gap-2.5"><Icon name="check" size={14} className="text-gold"/> {t}</li>
          ))}
        </ul>
      </Card>

      <GoldButton className="w-full mt-7" onClick={()=>go("pricing")}>جدد اشتراكك</GoldButton>
      <button onClick={()=>go("dashboard")} className="text-[13px] text-ink-2 dark:text-fog-2 mt-3 hover:text-gold">تصفح مجاناً</button>
    </div>
  </div>
);

// ---- P35: Settings — Subscription ----
const PageSettingsSubscription = ({ go }) => {
  const remaining = 18, total = 30;
  return (
    <AppLayout go={go} current="settings-sub" title="اشتراكك" sub="إدارة الخطة والفواتير">
      <div className="max-w-3xl space-y-5">
        <Card className="ring-2 ring-gold relative overflow-hidden">
          <div className="absolute -top-10 left-10 w-40 h-40 rounded-full bg-gold/10 blur-2xl"/>
          <div className="relative flex items-start gap-4 flex-wrap">
            <div className="w-12 h-12 rounded-2xl bg-gold/15 text-gold flex items-center justify-center"><Icon name="crown" size={22}/></div>
            <div className="flex-1 min-w-0">
              <Badge tone="gold">نشط</Badge>
              <div className="font-display text-xl mt-2">خطة Pro الشهرية</div>
              <div className="text-[13px] text-ink-2 dark:text-fog-2">يتم التجديد في <span className="numerals">٢٠ يونيو ٢٠٢٦</span> — <span className="numerals">٩٩ ج.م</span>/شهر</div>
              <div className="mt-3">
                <div className="flex items-center justify-between mb-1.5 text-[12.5px] text-ink-2 dark:text-fog-2">
                  <span>متبقي <span className="font-serif-en text-gold numerals">{remaining}</span> يوماً</span>
                  <span className="numerals">{total-remaining}/{total}</span>
                </div>
                <ProgressBar value={(total-remaining)/total*100}/>
              </div>
            </div>
            <GoldButton size="sm" onClick={()=>go("pricing")}>ترقية</GoldButton>
          </div>
        </Card>

        <div className="grid sm:grid-cols-3 gap-3">
          {[
            ["طلبات هذا الشهر","12 / ∞","inbox","gold"],
            ["كشف الهوية","٣","eye","green"],
            ["محادثات نشطة","٥","chat","amber"],
          ].map(([l,v,icn,tone]) => (
            <Card key={l} className="!p-4">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-2 ${tone==="gold"?"bg-gold/10 text-gold":tone==="green"?"bg-green/10 text-green":"bg-amber-soft text-amber"}`}><Icon name={icn} size={18}/></div>
              <div className="font-serif-en text-xl numerals">{v}</div>
              <div className="text-[12px] text-ink-2 dark:text-fog-2">{l}</div>
            </Card>
          ))}
        </div>

        <Card>
          <div className="flex items-center justify-between mb-3">
            <div className="font-display text-[15px]">سجل الفواتير</div>
            <button className="text-[12.5px] text-gold">تصدير</button>
          </div>
          <div className="divide-y divide-line dark:divide-edge text-[13.5px]">
            {[
              ["٢٠ مايو ٢٠٢٦","Pro الشهرية","99.00","paid"],
              ["٢٠ أبريل ٢٠٢٦","Pro الشهرية","99.00","paid"],
              ["٢٠ مارس ٢٠٢٦","Starter","49.00","paid"],
            ].map((row,i) => (
              <div key={i} className="py-3 flex items-center justify-between gap-3">
                <div className="numerals text-ink-2 dark:text-fog-2 text-[12.5px]">{row[0]}</div>
                <div className="flex-1 truncate">{row[1]}</div>
                <div className="numerals font-medium">{row[2]} ج.م</div>
                <Badge tone="green">مدفوع</Badge>
              </div>
            ))}
          </div>
        </Card>

        <button className="text-[13px] text-ink-3 hover:text-rose mx-auto block">إلغاء الاشتراك</button>
      </div>
    </AppLayout>
  );
};

window.PagesSubscription = { PagePricing, PagePayment, PageSubSuccess, PageSubExpired, PageSettingsSubscription };
Object.assign(window, window.PagesSubscription);
